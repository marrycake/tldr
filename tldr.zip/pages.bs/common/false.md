# false

> Vrati izlazni kod od 1.
> Više informacija: <https://www.gnu.org/software/coreutils/manual/html_node/false-invocation.html>.

- Vrati izlazni kod od 1:

`false`
