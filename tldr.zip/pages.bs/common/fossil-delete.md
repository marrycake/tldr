# fossil delete

> Ova komanda je pseudonim za `fossil rm`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr fossil rm`
