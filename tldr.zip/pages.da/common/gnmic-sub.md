# gnmic sub

> Denne kommando er et alias af `gnmic subscribe`.

- Se dokumentation for den oprindelige kommando:

`tldr gnmic subscribe`
