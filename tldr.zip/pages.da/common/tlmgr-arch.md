# tlmgr arch

> Denne kommando er et alias af `tlmgr platform`.

- Se dokumentation for den oprindelige kommando:

`tldr tlmgr platform`
