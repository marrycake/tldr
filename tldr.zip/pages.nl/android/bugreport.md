# bugreport

> Toon een Android-bugrapport.
> Dit commando kan alleen worden gebruikt via `adb shell`.
> Meer informatie: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- Geef een compleet bugrapport van een Android-apparaat weer:

`bugreport`
