# dalvikvm

> Machine virtuelle Java pour Android.
> Plus d'informations : <https://source.android.com/docs/core/runtime>.

- Démarre un programme Java :

`dalvikvm -classpath {{chemin/vers/fichier.jar}} {{nom_de_la_classe}}`
