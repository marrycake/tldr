# dalvikvm

> ஆண்ட்ராய்டு ஜாவா மெய்நிகர் இயந்திரம்.
> மேலும் விவரத்திற்கு: <https://source.android.com/docs/core/runtime>.

- ஒரு குறிப்பிட்ட ஜாவா நிரலைத் தொடங்கவும்:

`dalvikvm -classpath {{கோப்பு.jar/பாதை}} {{வகுப்புப்பெயர்}}`
