# arch

> Vis navnet på systemarkitekturen.
> Se også `uname`.
> Mer informasjon: <https://www.gnu.org/software/coreutils/manual/html_node/arch-invocation.html>.

- Vis systemets arkitektur:

`arch`
