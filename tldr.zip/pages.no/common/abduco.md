# abduco

> Terminal økt behandler.
> Mer informasjon: <https://manned.org/abduco>.

- List opp økter:

`abduco`

- Legg ved en økt, opprett den hvis den ikke eksisterer:

`abduco -A {{navn}} {{bash}}`

- Legg ved en økt med `dvtm`, opprett den hvis den ikke eksisterer:

`abduco -A {{navn}}`

- Koble fra en økt:

`<Ctrl \>`

- Legg ved en økt i skrivebeskyttet modus:

`abduco -Ar {{navn}}`
