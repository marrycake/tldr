# fossil ci

> Denne kommandoen er et alias for `fossil commit`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr fossil commit`
