# screencap

> मोबाइल डिस्प्ले का स्क्रीनशॉट लें।
> इस कमांड का उपयोग केवल `adb shell` के माध्यम से किया जा सकता है।
> अधिक जानकारी: <https://developer.android.com/tools/adb#screencap>।

- कोई स्क्रीनशॉट लें:

`screencap {{फ़ाइल/का/पथ}}`
