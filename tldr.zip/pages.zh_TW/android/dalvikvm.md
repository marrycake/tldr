# dalvikvm

> Android Java 虛擬機。
> 更多資訊：<https://source.android.com/docs/core/runtime>.

- 啟動一個 Java 程序：

`dalvikvm -classpath {{檔案.jar}} {{類別名稱}}`
