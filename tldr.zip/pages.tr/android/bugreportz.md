# bugreportz

> Ziplenmiş bir Android bug raporu oluştur.
> Bu komut yalnızca `adb shell` ile kullanılabilir.
> Daha fazla bilgi için: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreportz>.

- Bir Android cihazı için ziplenmiş şekilde eksizsiz bir bug raporu oluşturGenerate a complete zipped bug report of an Android device:

`bugreportz`

- Çalışan `bugreportz` işleminin durumunu göster:

`bugreportz -p`

- Yardım görüntüle:

`bugreportz -h`

- `bugreportz` sürümünü göster:

`bugreportz -v`
