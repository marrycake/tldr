# fossil delete

> Det här kommandot är ett alias för `fossil rm`.

- Se dokumentationen för orginalkommandot:

`tldr fossil rm`
