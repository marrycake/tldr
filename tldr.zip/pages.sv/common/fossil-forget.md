# fossil forget

> Det här kommandot är ett alias för `fossil rm`.
> Mer information: <https://fossil-scm.org/home/help/forget>.

- Se dokumentationen för orginalkommandot:

`tldr fossil rm`
