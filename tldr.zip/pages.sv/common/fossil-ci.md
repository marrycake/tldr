# fossil ci

> Det här kommandot är ett alias för `fossil commit`.

- Se dokumentationen för orginalkommandot:

`tldr fossil commit`
