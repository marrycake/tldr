# bugreport

> Androidのバグレポートを表示します。
> このコマンドは `adb shell` 経由でのみ実行できます。
> もっと詳しく: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>。

- Androidデバイスの完全なバグレポートを表示します:

`bugreport`
