# dalvikvm

> Android Java 仮想環境。
> もっと詳しく: <https://source.android.com/docs/core/runtime>。

- 指定したJavaプログラムを開始します:

`dalvikvm -classpath {{path/to/file.jar}} {{classname}}`
