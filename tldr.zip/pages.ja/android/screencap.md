# screencap

> モバイルディスプレイのスクリーンショットを撮影します。
> このコマンドは `adb shell` 経由でのみ実行できます。
> もっと詳しく: <https://developer.android.com/tools/adb#screencap>。

- スクリーンショットを撮影します:

`screencap {{path/to/file}}`
