# fossil forget

> यो आदेश `fossil rm` को उपनाम हो |
> थप जानकारी: <https://fossil-scm.org/home/help/forget>।

- मौलिक आदेशको लागि कागजात हेर्नुहोस्:

`tldr fossil rm`
