# gsha384sum

> This command is an alias of GNU `sha384sum`.

- View documentation for the original command:

`tldr -p linux sha384sum`
