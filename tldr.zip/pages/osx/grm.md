# grm

> This command is an alias of GNU `rm`.

- View documentation for the original command:

`tldr -p linux rm`
