# whatis

> Search a set of database files for short descriptions of system commands for keywords.
> More information: <https://www.linfo.org/whatis.html>.

- Search for information about keyword:

`whatis {{keyword}}`

- Search for information about multiple keywords:

`whatis {{keyword1}} {{keyword2}}`
