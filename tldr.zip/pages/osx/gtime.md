# gtime

> This command is an alias of GNU `time`.

- View documentation for the original command:

`tldr -p linux time`
