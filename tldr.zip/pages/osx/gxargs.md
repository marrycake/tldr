# gxargs

> This command is an alias of GNU `xargs`.

- View documentation for the original command:

`tldr -p linux xargs`
