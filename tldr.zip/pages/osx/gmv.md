# gmv

> This command is an alias of GNU `mv`.

- View documentation for the original command:

`tldr -p linux mv`
