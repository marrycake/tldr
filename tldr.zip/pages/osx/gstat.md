# gstat

> This command is an alias of GNU `stat`.

- View documentation for the original command:

`tldr -p linux stat`
