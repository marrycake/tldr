# gnohup

> This command is an alias of GNU `nohup`.

- View documentation for the original command:

`tldr -p linux nohup`
