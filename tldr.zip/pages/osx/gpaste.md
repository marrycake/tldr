# gpaste

> This command is an alias of GNU `paste`.

- View documentation for the original command:

`tldr -p linux paste`
