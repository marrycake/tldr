# lookandfeeltool

> This command is an alias of `plasma-apply-lookandfeel`.

- View documentation for the original command:

`tldr plasma-apply-lookandfeel`
