# qm move_disk

> This command is an alias of `qm disk move`.

- View documentation for the original command:

`tldr qm disk move`
