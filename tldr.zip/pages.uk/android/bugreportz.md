# bugreportz

> Згенерувати зіпований звіт багів.
> Ця команда може бути виконана тільки за допомогою `adb shell`.
> Більше інформації: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreportz>.

- Згенерувати повний зіпований звіт багів Android девайсу:

`bugreportz`

- Вивести прогрес виконуваної `bugreportz` операції:

`bugreportz -p`

- Показати допомогу:

`bugreportz -h`

- Вивести версію `bugreportz`:

`bugreportz -v`
