# wm

> Показати інформацію про екран Android девайсу.
> Ця команда може бути виконана тільки за допомогою `adb shell`.
> Більше інформації: <https://web.archive.org/web/20240420064706/https://adbinstaller.com/commands/adb-shell-wm-5b672b17e7958178a2955538>.

- Вивести фізичний розмір екрану Android девайсу:

`wm size`

- Вивести фізичну щільність екрану Android девайсу:

`wm density`
