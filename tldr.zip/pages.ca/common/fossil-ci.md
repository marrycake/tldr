# fossil ci

> Aquest comandament es un àlies de `fossil commit`.

- Veure documentació per el comandament original:

`tldr fossil commit`
