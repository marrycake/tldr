# exit

> Surt del shell.
> Més informació: <https://manned.org/exit.1posix>.

- Surt amb l'estat de sortida de l'ordre executada més recent :

`exit`

- Surt amb un estat de sortida específic:

`exit {{codi_de_sortida}}`
