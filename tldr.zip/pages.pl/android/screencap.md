# screencap

> Zrób zrzut ekranu wyświetlacza urządzenia przenośnego.
> To polecenie może być używane tylko przez `adb shell`.
> Więcej informacji: <https://developer.android.com/tools/adb#screencap>.

- Zrób zrzut ekranu:

`screencap {{ścieżka/do/pliku}}`
