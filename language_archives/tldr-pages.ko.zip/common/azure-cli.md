# azure-cli

> 이 명령은 `az`의 별칭.

- 원래 명령에 대한 문서를 보기:

`tldr az`
