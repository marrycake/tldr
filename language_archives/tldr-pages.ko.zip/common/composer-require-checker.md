# composer-require-checker

> 소프트 종속성에 대한 Composer 종속성을 분석.
> 더 많은 정보: <https://github.com/maglnet/ComposerRequireChecker>.

- Composer JSON 파일 분석:

`composer-require-checker check {{path/to/composer.json}}`

- 특정 구성으로 Composer JSON 파일을 분석:

`composer-require-checker check --config-file {{path/to/config.json}} {{path/to/composer.json}}`
