# convert

> 이 명령어는 `magick convert`의 별칭.
> 참고: ImageMagick 7부터 이 별칭은 사용되지 않음. `magick`으로 대체됨.
> 7 이상 버전에서 이전 도구를 사용해야 하는 경우, `magick convert`를 사용해야 함.

- 원래 명령에 대한 문서 보기:

`tldr magick convert`
