# cargo new

> 새로운 Cargo 패키지를 생성.
> `cargo init`과 동일하지만, 디렉터리를 지정해야 함.
> 더 많은 정보: <https://doc.rust-lang.org/cargo/commands/cargo-new.html>.

- 바이너리 타겟으로 새로운 Rust 프로젝트를 생성:

`cargo new {{경로/대상/디렉터리}}`
