# Colon

> 성공적인 종료 상태 코드 0을 반환.
> 더 많은 정보: <https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#colon>.

- 성공적인 종료 코드를 반환:

`:`

- 명령이 항상 0으로 종료되도록 함:

`{{명령어}} || :`
