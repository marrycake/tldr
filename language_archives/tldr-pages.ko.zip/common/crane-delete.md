# crane delete

> 레지스트리에서 이미지 참조를 삭제.
> 더 많은 정보: <https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_delete.md>.

- 레지스트리에서 이미지 참조를 삭제:

`crane delete {{이미지_이름}}`

- 도움말 표시:

`crane delete {{[-h|--help]}}`
