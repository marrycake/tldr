# crane cp

> 이 명령은 `crane copy`의 별칭이다.

- 원본 명령어에 대한 설명서 보기:

`tldr crane copy`
