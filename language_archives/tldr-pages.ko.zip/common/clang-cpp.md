# clang-cpp

> 이 명령어는 `clang++`의 별칭입니다.

- 원본 명령어의 문서 확인:

`tldr clang++`
