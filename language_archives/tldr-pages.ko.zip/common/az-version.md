# az version

> Azure CLI 모듈 및 확장의 현재 버전을 표시.
> `azure-cli`의 일부 (`az`라고도 함).
> 더 많은 정보: <https://learn.microsoft.com/cli/azure/reference-index?view=azure-cli-latest#az-version>.

- Azure CLI 모듈 및 확장의 현재 버전을 JSON 형식으로 표시:

`az version`

- Azure CLI 모듈 및 확장의 현재 버전을 지정된 형식으로 표시:

`az version --output {{json|table|tsv}}`
