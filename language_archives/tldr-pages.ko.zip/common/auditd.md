# auditd

> 감사 유틸리티의 요청과 커널의 알림에 응답합니다.
> 수동으로 호출해서는 안 됩니다.
> 더 많은 정보: <https://manned.org/auditd>.

- 데몬 시작:

`auditd`

- 디버그 모드에서 데몬 시작:

`auditd -d`

- launchd에서 주문형 데몬 시작:

`auditd -l`
