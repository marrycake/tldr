# compopt

> 명령어 완성 옵션을 출력하거나 변경.
> 더 많은 정보: <https://manned.org/compopt>.

- 현재 실행 중인 완성에 대한 옵션을 출력:

`compopt`

- 주어진 명령에 대한 완성 옵션을 출력:

`compopt {{명령어}}`
