# ClamAV

> 오픈 소스 안티 바이러스 프로그램.
> ClamAV는 명령이 아니라 명령 집합.
> 더 많은 정보: <https://www.clamav.net>.

- `clamd` 데몬을 사용하여 파일을 스캔하는 방법에 대한 문서 보기:

`tldr clamdscan`

- `clamd` 데몬을 실행하지 않고 파일을 검색하는 방법에 대한 문서 보기:

`tldr clamscan`

- 바이러스 정의 업데이트에 대한 문서 보기:

`tldr freshclam`
