# atktopbm

> Andrew Toolkit 래스터 객체를 PBM 이미지로 변환.
> `pbmtoatk` 명령어를 참고하세요.
> 더 많은 정보: <https://netpbm.sourceforge.net/doc/atktopbm.html>.

- Andrew Toolkit 래스터 객체를 PBM 이미지로 변환:

`atktopbm {{경로/대상/image.atk}} > {{경로/대상/output.pbm}}`
