# calligraflow

> Calligra의 흐름도 및 다이어그램 응용 프로그램.
> 참고: `calligrastage`, `calligrawords`, `calligrasheets`.
> 더 많은 정보: <https://manned.org/calligraflow>.

- 순서도 및 다이어그램 애플리케이션을 시작:

`calligraflow`

- 특정 파일 열기:

`calligraflow {{경로/대상/파일}}`

- 도움말 또는 버전 표시:

`calligraflow --{{도움말|버전}}`
