# crane config

> 이미지 구성 가져오기.
> 더 많은 정보: <https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_config.md>.

- 이미지 구성 가져오기:

`crane config {{이미지_이름}}`

- 도움말 표시:

`crane config {{[-h|--help]}}`
