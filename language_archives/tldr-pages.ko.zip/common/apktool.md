# apktool

> APK 파일 리버스 엔지니어링.
> 더 많은 정보: <https://ibotpeaches.github.io/Apktool/>.

- APK 파일 디코딩:

`apktool d {{경로/대상/파일.apk}}`

- 디렉토리로부터 APK 파일 빌드:

`apktool b {{경로/대상/폴더}}`

- 프레임워크 설치 및 저장:

`apktool if {{경로/대상/프레임워크.apk}}`
