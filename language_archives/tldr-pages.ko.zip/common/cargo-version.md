# cargo version

> `cargo` 버전 정보를 표시.
> 더 많은 정보: <https://doc.rust-lang.org/cargo/commands/cargo-version.html>.

- 버전 정보 표시:

`cargo version`

- 추가 빌드 정보 표시:

`cargo version --verbose`
