# bundler

> Ruby 프로그래밍 언어의 의존성 관리자.
> `bundler`는 `bundle` 명령의 일반적인 이름이지만, 명령어 자체는 아님.
> 더 많은 정보: <https://bundler.io/man/bundle.1.html>.

- 원래 명령에 대한 문서 보기:

`tldr bundle`
