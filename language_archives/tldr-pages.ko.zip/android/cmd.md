# cmd

> Android 서비스 매니저.
> 더 많은 정보: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/cmd/>.

- 실행 중인 모든 서비스 나열:

`cmd -l`

- 특정 서비스 호출:

`cmd {{서비스}}`

- 특정 인자를 사용해 서비스 호출:

`cmd {{서비스}} {{인자1 인자2 ...}}`
