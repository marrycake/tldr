# git credential-store

> Git 凭证存储助手，用于将密码存储在磁盘上。
> 更多信息：<https://git-scm.com/docs/git-credential-store>.

- ​​指定凭证存储文件路径​​：

`git config credential.helper 'store --file={{路径/到/文件}}'`
