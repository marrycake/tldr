# git brv

> 按最后提交日期排序显示分支列表。
> 属于 `git-extras`的一部分。
> 更多信息：<https://github.com/tj/git-extras/blob/master/Commands.md#git-brv>.

- 列出所有分支，显示日期、最新提交哈希和提交信息：

`git brv`
