# imgcat

> 直接在命令行上显示图像的实用程序。
> 需要兼容的终端软件，如 iTerm2.
> 更多信息：<https://github.com/danielgatis/imgcat>.

- 在命令行上显示图像：

`imgcat {{文件名}}`
