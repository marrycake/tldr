# git clear-soft

> 将 Git 工作目录清理至如同刚克隆时的状态（不包含 `.gitignore` 中的文件）。
> 属于 `git-extras` 一部分。
> 更多信息：<https://github.com/tj/git-extras/blob/master/Commands.md#git-clear-soft>.

- 重置所有已跟踪文件并删除所有未跟踪文件：

`git clear-soft`
