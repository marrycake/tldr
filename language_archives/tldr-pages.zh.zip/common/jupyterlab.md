# jupyterlab

> 这是 `jupyter lab` 命令的一个别名。

- 查看原命令的文档：

`tldr jupyter lab`
