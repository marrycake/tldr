# git archive-file

> 将当前 Git 分支的所有文件导出为 Zip 压缩包。
> 属于 `git-extras`的一部分。
> 更多信息：<https://github.com/tj/git-extras/blob/master/Commands.md#git-archive-file>.

- 将当前检出的提交打包成 Zip 压缩包：

`git archive-file`
