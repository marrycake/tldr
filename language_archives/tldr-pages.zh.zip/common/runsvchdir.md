# runsvchdir

> 更改默认使用的 `runsvdir` 目录。
> 更多信息：<https://manned.org/runsvchdir.8>.

- 切换 `runsvdir` 目录：

`sudo runsvchdir {{路径/到/目录}}`
