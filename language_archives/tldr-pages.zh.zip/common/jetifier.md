# jetifier

> 一个以 npm 格式提供的 Jetifier AndroidX 迁移工具，适用于 react-native。
> 更多信息：<https://github.com/mikehardy/jetifier>.

- 将项目依赖迁移到 AndroidX 格式：

`jetifier`

- 将项目依赖从 AndroidX 格式迁移回来：

`jetifier reverse`
