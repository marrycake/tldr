# git contrib

> 显示指定作者的提交记录。
> 属于 `git-extras` 一部分。
> 更多信息：<https://github.com/tj/git-extras/blob/master/Commands.md#git-contrib>.

- 显示指定作者的所有提交哈希及对应提交信息：

`git contrib {{作者名}}`
