# git check-mailmap

> 显示联系人的规范名称和电子邮件地址。
> 更多信息：<https://git-scm.com/docs/git-check-mailmap>.

- 查找与电子邮件地址关联的规范名称：

`git check-mailmap "<{{邮箱@example.com}}>"`
