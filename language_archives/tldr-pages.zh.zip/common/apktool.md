# apktool

> APK 文件反编译工具。
> 更多信息：<https://ibotpeaches.github.io/Apktool/>.

- 反编译：

`apktool d {{应用.apk}}`

- 将一个文件夹打包为 apk 文件：

`apktool b {{路径/到/目录}}`

- 安装并存储框架：

`apktool if {{框架.apk}}`
