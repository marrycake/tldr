# git credential-cache

> Git 凭证缓存助手，用于在内存中临时存储密码。
> 更多信息：<https://git-scm.com/docs/git-credential-cache>.

- Git 凭证缓存助手，用于在内存中临时存储密码。

`git config credential.helper 'cache --timeout={{秒数}}'`
