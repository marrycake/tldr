# jobs

> 显示当前会话中作业的状态。
> 更多信息：<https://manned.org/jobs>.

- 显示所有作业的状态：

`jobs`

- 显示特定作业的状态：

`jobs %{{作业_id}}`

- 显示所有作业的状态和进程 ID：

`jobs -l`

- 显示所有作业的进程 ID：

`jobs -p`
