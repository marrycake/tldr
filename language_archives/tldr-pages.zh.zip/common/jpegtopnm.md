# jpegtopnm

> 将 JPEG/JFIF 文件转换为 PPM 或 PGM 格式。
> 更多信息：<https://netpbm.sourceforge.net/doc/jpegtopnm.html>.

- 将 JPEG/JFIF 图像转换为 PPM 或 PGM 图像：

`jpegtopnm {{路径/到/文件.jpg}} > {{路径/到/文件.pnm}}`

- 显示版本信息：

`jpegtopnm -version`
