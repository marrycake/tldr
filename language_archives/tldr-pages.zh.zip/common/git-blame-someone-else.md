# git blame-someone-else

> 将你的糟糕代码归咎于其他人。
> 更多信息：<https://github.com/jayphelps/git-blame-someone-else>.

- 更改提交的提交者和作者：

`git blame-someone-else "{{作者 <someone@example.com>}}" {{提交}}`
