# unclutter

> 隐藏鼠标光标。
> 更多信息：<https://manned.org/unclutter.1x>.

- 在 3 秒后隐藏鼠标光标：

`unclutter -idle {{3}}`
