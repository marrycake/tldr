# just

> 保存并运行项目特定的命令。
> 更多信息：<https://github.com/casey/just>.

- 运行在 justfile 中指定的配方：

`just {{配方}}`

- 在项目根目录初始化新的 justfile：

`just --init`

- 在默认编辑器中编辑 justfile：

`just -e`

- 列出 justfile 中可用的配方：

`just -l`

- 打印 justfile：

`just --dump`
