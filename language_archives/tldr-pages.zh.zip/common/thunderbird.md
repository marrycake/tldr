# thunderbird

> 电子邮件客户端和 RSS 阅读器。
> 更多信息：<https://manned.org/thunderbird>.

- 打开 Thunderbird:

`thunderbird`

- 使用特定用户配置文件：

`thunderbird -P {{配置文件名称}}`

- 使用特定用户配置文件夹：

`thunderbird --profile {{路径/到/配置文件/文件夹}}`
