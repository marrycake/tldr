# git coauthor

> 为最新提交添加共同作者（会重写 Git 历史，下次推送需使用 `--force` 选项）。
> 属于 `git-extras`一部分。
> 更多信息：<https://github.com/tj/git-extras/blob/master/Commands.md#git-coauthor>.

- 为最新提交添加共同作者：

`git coauthor {{作者姓名}} {{作者邮箱}}`
