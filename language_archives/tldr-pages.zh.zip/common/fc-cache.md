# fc-cache

> 扫描字体目录，以便建立字体缓存文件。
> 更多信息：<https://manned.org/fc-cache>.

- 生成字体缓存文件：

`fc-cache`

- 强制重建所有字体缓存文件，而不检查缓存是否为最新版本：

`fc-cache -f`

- 删除字体缓存文件，然后生成新的字体缓存文件：

`fc-cache -r`
