# just

> `just` 可以指代多个具有相同名称的命令。

- 查看命令运行器的文档：

`tldr just.1`

- 查看 V8 JavaScript 运行时的文档：

`tldr just.js`
