# fossil delete

> 这是 `fossil rm` 命令的一个别名。

- 原命令的文档在：

`tldr fossil rm`
