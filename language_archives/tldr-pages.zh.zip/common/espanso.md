# espanso

> 用 Rust 编写的跨平台文本扩展器。
> 更多信息：<https://espanso.org>.

- 检查状态：

`espanso status`

- 编辑配置：

`espanso edit config`

- 从 hub 商店（<https://hub.espanso.org/>）安装一个软件包：

`espanso install {{软件包的名字}}`

- 重新启动（安装软件包后需要，在失败的情况下很有用）：

`espanso restart`
