# git browse

> 在默认浏览器中查看上游代码库
> 属于 `git-extras` 工具集的一部分。
> 更多信息：<https://github.com/tj/git-extras/blob/master/Commands.md#git-browse>.

- 在默认浏览器中打开第一个上游代码库：

`git browse`

- 在默认浏览器中打开指定的上游代码库：

`git browse {{上游名称}}`
