# jadx

> Dex 到 Java 的反编译器。
> 将 Android Dex 和 APK 文件生成 Java 源代码。
> 更多信息：<https://github.com/skylot/jadx>.

- 将一个 Dex 文件反编译到一个目录中：

`jadx {{路径/到/文件}}`

- 将一个 Dex 文件反编译到一个特定目录中：

`jadx --output-dir {{路径/到/目录}} {{路径/到/文件}}`
