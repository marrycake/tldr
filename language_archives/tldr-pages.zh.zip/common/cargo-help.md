# cargo help

> 显示有关 cargo 及其子命令的帮助信息。
> 更多信息：<https://doc.rust-lang.org/cargo/commands/cargo-help.html>.

- 显示一般帮助：

`cargo help`

- 显示子命令的帮助信息：

`cargo help {{子命令}}`
