# logger

> 向系统日志增加记录。
> 更多信息：<https://manned.org/logger.1p>.

- 向系统日志增加记录：

`logger {{消息内容}}`
