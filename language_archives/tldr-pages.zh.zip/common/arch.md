# arch

> 展示系统架构的名称。
> 另见`uname`.
> 更多信息：<https://www.gnu.org/software/coreutils/manual/html_node/arch-invocation.html>.

- 展示系统架构：

`arch`
