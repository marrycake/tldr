# wm

> Android デバイスのスクリーンに関する情報を表示します。
> このコマンドは `adb shell` 経由でのみ実行できます。
> もっと詳しく: <https://web.archive.org/web/20240420064706/https://adbinstaller.com/commands/adb-shell-wm-5b672b17e7958178a2955538>。

- Android デバイスの物理サイズを表示します:

`wm size`

- Android デバイスの画面の物理的密度を表示します:

`wm density`
