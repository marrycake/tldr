# fossil new

> このコマンドは `fossil init`.のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr fossil init`
