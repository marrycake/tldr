# tlmgr arch

> このコマンドは `tlmgr platform` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr tlmgr platform`
