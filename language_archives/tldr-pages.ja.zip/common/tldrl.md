# tldrl

> このコマンドは `tldr-lint` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr tldr-lint`
