# gnmic sub

> このコマンドは `gnmic subscribe` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr gnmic subscribe`
