# arch

> システムアーキテクチャ名前を示する。
> 'uname' も参照してください。
> もっと詳しく: <https://www.gnu.org/software/coreutils/manual/html_node/arch-invocation.html>。

- システムアーキテクチャを示する:

`arch`
