# fossil forget

> このコマンドは `fossil rm` のエイリアスです。
> もっと詳しく: <https://fossil-scm.org/home/help/forget>。

- オリジナルのコマンドのドキュメントを表示する:

`tldr fossil rm`
