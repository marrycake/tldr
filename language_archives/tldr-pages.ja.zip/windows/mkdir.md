# mkdir

> ディレクトリを作成します。
> もっと詳しく: <https://learn.microsoft.com/windows-server/administration/windows-commands/mkdir>。

- ディレクトリを作成します:

`mkdir {{ディレクトリ名}}`

- ネストされたディレクトリツリーを再帰的に作成します:

`mkdir {{サブディレクトリ名のパス}}`
