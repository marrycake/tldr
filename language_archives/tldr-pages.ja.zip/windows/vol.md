# vol

> ボリュームに関する情報を表示します。
> もっと詳しく: <https://learn.microsoft.com/windows-server/administration/windows-commands/vol>。

- 現在のドライブのラベルとシリアル番号を表示する:

`vol`

- 特定のボリュームのラベルとシリアル番号を表示する:

`vol {{D:}}`
