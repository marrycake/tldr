# cinst

> このコマンドは `choco install` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr choco install`
