# pwsh where

> このコマンドは `Where-Object` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr Where-Object`
