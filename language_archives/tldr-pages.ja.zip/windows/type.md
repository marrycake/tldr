# type

> ファイルの内容を表示します。
> もっと詳しく: <https://learn.microsoft.com/windows-server/administration/windows-commands/type>。

- 特定のファイルの内容を表示する:

`type {{path\to\file}}`
