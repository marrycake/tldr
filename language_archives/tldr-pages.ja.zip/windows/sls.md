# sls

> このコマンドは `Select-String` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr select-string`
