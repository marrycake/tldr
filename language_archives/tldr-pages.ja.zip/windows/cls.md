# cls

> 画面をクリアします。
> もっと詳しく: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>。

- 画面をクリアします:

`cls`
