# clist

> このコマンドは `choco list` のエイリアスです。

- オリジナルのコマンドのドキュメントを表示する:

`tldr choco list`
