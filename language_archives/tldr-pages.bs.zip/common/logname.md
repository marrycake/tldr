# logname

> Prikazuje ime prijevljenog korisnika.
> Više informacija: <https://www.gnu.org/software/coreutils/manual/html_node/logname-invocation.html>.

- Prikaži ime trenutno prijavljenog korisnika:

`logname`
