# tty

> Vraća ime terminala.
> Više informacija: <https://www.gnu.org/software/coreutils/manual/html_node/tty-invocation.html>.

- Ispiši ime fajla ovog terminala:

`tty`
