# tldrl

> Ova komanda je pseudonim za `tldr-lint`.

- Pregledaj dokumentaciju za izvornu komandu:

`tldr tldr-lint`
