# unclutter

> Skriva kursor miša.
> Više informacija: <https://manned.org/unclutter.1x>.

- Sakrij kursor miša nakon 3 sekunde:

`unclutter -idle {{3}}`
