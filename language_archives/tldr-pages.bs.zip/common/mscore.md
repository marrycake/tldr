# mscore

> Ova komanda je pseudonim za `musescore`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr musescore`
