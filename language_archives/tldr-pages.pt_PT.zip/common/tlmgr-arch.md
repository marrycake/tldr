# tlmgr arch

> Este comando é um alias de `tlmgr platform`.

- Exibe documentação do comando original:

`tldr tlmgr platform`
