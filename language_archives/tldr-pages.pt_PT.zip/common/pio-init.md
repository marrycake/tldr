# pio init

> Este comando é um alias de `pio project`.

- Exibe documentação do comando original:

`tldr pio project`
