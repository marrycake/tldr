# cola

> Este comando é um alias de `git-cola`.

- Exibe documentação do comando original:

`tldr git-cola`
