# fossil delete

> Este comando é um alias de `fossil rm`.

- Exibe documentação do comando original:

`tldr fossil rm`
