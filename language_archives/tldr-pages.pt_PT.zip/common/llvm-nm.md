# llvm-nm

> Este comando é um alias de `nm`.

- Exibe documentação do comando original:

`tldr nm`
