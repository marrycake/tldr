# hx

> Este comando é um alias de `helix`.

- Exibe documentação do comando original:

`tldr helix`
