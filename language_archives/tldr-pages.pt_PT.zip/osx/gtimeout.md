# gtimeout

> Este comando é um alias de `timeout`.

- Ver documentação do comando original:

`tldr timeout`
