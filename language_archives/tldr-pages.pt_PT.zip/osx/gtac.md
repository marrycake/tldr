# gtac

> Este comando é um alias de `tac`.

- Ver documentação do comando original:

`tldr tac`
