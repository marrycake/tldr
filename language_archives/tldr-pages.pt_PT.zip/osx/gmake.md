# gmake

> Este comando é um alias de `make`.

- Ver documentação do comando original:

`tldr make`
