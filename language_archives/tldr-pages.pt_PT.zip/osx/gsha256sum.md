# gsha256sum

> Este comando é um alias de `sha256sum`.

- Ver documentação do comando original:

`tldr sha256sum`
