# gsum

> Este comando é um alias de `sum`.

- Ver documentação do comando original:

`tldr sum`
