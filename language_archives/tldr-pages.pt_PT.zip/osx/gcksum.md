# gcksum

> Este comando é um alias de `cksum`.

- Ver documentação do comando original:

`tldr cksum`
