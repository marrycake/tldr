# gtar

> Este comando é um alias de `tar`.

- Ver documentação do comando original:

`tldr tar`
