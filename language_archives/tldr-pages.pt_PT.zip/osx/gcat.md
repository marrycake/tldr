# gcat

> Este comando é um alias de `-p linux cat`.

- Exibe documentação do comando original:

`tldr {{[-p|--platform]}} linux cat`
