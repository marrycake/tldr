# gbasename

> Este comando é um alias de `basename`.

- Ver documentação do comando original:

`tldr basename`
