# gnproc

> Este comando é um alias de `nproc`.

- Ver documentação do comando original:

`tldr nproc`
