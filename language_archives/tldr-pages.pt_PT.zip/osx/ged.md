# ged

> Este comando é um alias de `ed`.

- Ver documentação do comando original:

`tldr ed`
