# grexec

> Este comando é um alias de `-p linux rexec`.

- Exibe documentação do comando original:

`tldr {{[-p|--platform]}} linux rexec`
