# glogger

> Este comando é um alias de `-p linux logger`.

- Exibe documentação do comando original:

`tldr {{[-p|--platform]}} linux logger`
