# gvdir

> Este comando é um alias de `vdir`.

- Ver documentação do comando original:

`tldr vdir`
