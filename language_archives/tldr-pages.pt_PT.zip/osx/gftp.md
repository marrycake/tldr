# gftp

> Este comando é um alias de `ftp`.

- Ver documentação do comando original:

`tldr ftp`
