# grmdir

> Este comando é um alias de `rmdir`.

- Ver documentação do comando original:

`tldr rmdir`
