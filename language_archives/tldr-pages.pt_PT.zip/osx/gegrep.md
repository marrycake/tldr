# gegrep

> Este comando é um alias de `egrep`.

- Ver documentação do comando original:

`tldr egrep`
