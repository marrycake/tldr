# gsha512sum

> Este comando é um alias de `sha512sum`.

- Ver documentação do comando original:

`tldr sha512sum`
