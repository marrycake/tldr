# gwho

> Este comando é um alias de `who`.

- Ver documentação do comando original:

`tldr who`
