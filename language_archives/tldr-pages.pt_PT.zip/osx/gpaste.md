# gpaste

> Este comando é um alias de `paste`.

- Ver documentação do comando original:

`tldr paste`
