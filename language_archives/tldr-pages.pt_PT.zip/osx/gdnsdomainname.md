# gdnsdomainname

> Este comando é um alias de `-p linux dnsdomainname`.

- Exibe documentação do comando original:

`tldr {{[-p|--platform]}} linux dnsdomainname`
