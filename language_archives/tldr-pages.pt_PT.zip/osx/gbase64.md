# gbase64

> Este comando é um alias de `base64`.

- Ver documentação do comando original:

`tldr {{[-p|--platform]}} common base64`
