# gsha224sum

> Este comando é um alias de `sha224sum`.

- Ver documentação do comando original:

`tldr sha224sum`
