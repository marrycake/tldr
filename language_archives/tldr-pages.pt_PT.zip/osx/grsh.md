# grsh

> Este comando é um alias de `-p linux rsh`.

- Exibe documentação do comando original:

`tldr {{[-p|--platform]}} linux rsh`
