# gjoin

> Este comando é um alias de `join`.

- Ver documentação do comando original:

`tldr join`
