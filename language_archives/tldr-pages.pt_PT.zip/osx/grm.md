# grm

> Este comando é um alias de `rm`.

- Ver documentação do comando original:

`tldr rm`
