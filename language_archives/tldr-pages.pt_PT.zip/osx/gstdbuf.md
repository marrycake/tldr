# gstdbuf

> Este comando é um alias de `stdbuf`.

- Ver documentação do comando original:

`tldr stdbuf`
