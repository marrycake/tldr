# gpwd

> Este comando é um alias de `pwd`.

- Ver documentação do comando original:

`tldr pwd`
