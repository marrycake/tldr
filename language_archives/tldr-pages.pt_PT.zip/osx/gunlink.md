# gunlink

> Este comando é um alias de `unlink`.

- Ver documentação do comando original:

`tldr unlink`
