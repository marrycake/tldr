# gsha1sum

> Este comando é um alias de `sha1sum`.

- Ver documentação do comando original:

`tldr sha1sum`
