# ginstall

> Este comando é um alias de `install`.

- Ver documentação do comando original:

`tldr install`
