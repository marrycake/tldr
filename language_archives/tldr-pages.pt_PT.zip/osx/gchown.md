# gchown

> Este comando é um alias de `chown`.

- Ver documentação do comando original:

`tldr chown`
