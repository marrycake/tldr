# gfind

> Este comando é um alias de `find`.

- Ver documentação do comando original:

`tldr find`
