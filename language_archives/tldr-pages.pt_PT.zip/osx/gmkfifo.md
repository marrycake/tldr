# gmkfifo

> Este comando é um alias de `mkfifo`.

- Ver documentação do comando original:

`tldr mkfifo`
