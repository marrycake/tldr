# gshuf

> Este comando é um alias de `shuf`.

- Ver documentação do comando original:

`tldr {{[-p|--platform]}} coomon shuf`
