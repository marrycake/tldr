# gupdatedb

> Este comando é um alias de `-p linux updatedb`.

- Exibe documentação do comando original:

`tldr {{[-p|--platform]}} linux updatedb`
