# gtrue

> Este comando é um alias de `true`.

- Ver documentação do comando original:

`tldr true`
