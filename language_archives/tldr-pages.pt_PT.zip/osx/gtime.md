# gtime

> Este comando é um alias de `time`.

- Ver documentação do comando original:

`tldr time`
