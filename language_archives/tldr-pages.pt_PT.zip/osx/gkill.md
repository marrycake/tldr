# gkill

> Este comando é um alias de `-p linux kill`.

- Exibe documentação do comando original:

`tldr {{[-p|--platform]}} linux kill`
