# glogname

> Este comando é um alias de `logname`.

- Ver documentação do comando original:

`tldr logname`
