# gexpand

> Este comando é um alias de `expand`.

- Ver documentação do comando original:

`tldr expand`
