# gindent

> Este comando é um alias de `indent`.

- Ver documentação do comando original:

`tldr {{[-p|--platform]}} common indent`
