# gdirname

> Este comando é um alias de `dirname`.

- Ver documentação do comando original:

`tldr dirname`
