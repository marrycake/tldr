# gcomm

> Este comando é um alias de `comm`.

- Ver documentação do comando original:

`tldr comm`
