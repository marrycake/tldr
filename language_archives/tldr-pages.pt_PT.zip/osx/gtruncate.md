# gtruncate

> Este comando é um alias de `truncate`.

- Ver documentação do comando original:

`tldr truncate`
