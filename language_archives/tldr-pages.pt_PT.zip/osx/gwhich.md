# gwhich

> Este comando é um alias de `which`.

- Ver documentação do comando original:

`tldr which`
