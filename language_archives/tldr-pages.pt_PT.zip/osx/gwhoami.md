# gwhoami

> Este comando é um alias de `whoami`.

- Ver documentação do comando original:

`tldr whoami`
