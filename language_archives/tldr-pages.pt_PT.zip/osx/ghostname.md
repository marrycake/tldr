# ghostname

> Este comando é um alias de `hostname`.

- Ver documentação do comando original:

`tldr hostname`
