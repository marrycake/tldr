# gshred

> Este comando é um alias de `shred`.

- Ver documentação do comando original:

`tldr shred`
