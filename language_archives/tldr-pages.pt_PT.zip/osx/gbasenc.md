# gbasenc

> Este comando é um alias de `basenc`.

- Ver documentação do comando original:

`tldr basenc`
