# gcp

> Este comando é um alias de `cp`.

- Ver documentação do comando original:

`tldr cp`
