# gpr

> Este comando é um alias de `pr`.

- Ver documentação do comando original:

`tldr pr`
