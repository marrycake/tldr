# gb2sum

> Este comando é um alias de `b2sum`.

- Ver documentação do comando original:

`tldr b2sum`
