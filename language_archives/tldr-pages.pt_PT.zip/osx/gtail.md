# gtail

> Este comando é um alias de `tail`.

- Ver documentação do comando original:

`tldr {{[-p|--platform]}} common tail`
