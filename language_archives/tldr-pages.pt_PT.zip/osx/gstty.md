# gstty

> Este comando é um alias de `stty`.

- Ver documentação do comando original:

`tldr stty`
