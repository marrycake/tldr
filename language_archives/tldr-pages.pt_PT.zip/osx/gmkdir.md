# gmkdir

> Este comando é um alias de `mkdir`.

- Ver documentação do comando original:

`tldr mkdir`
