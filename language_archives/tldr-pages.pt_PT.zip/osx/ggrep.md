# ggrep

> Este comando é um alias de `grep`.

- Ver documentação do comando original:

`tldr grep`
