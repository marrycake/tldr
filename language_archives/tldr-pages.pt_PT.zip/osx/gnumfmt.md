# gnumfmt

> Este comando é um alias de `numfmt`.

- Ver documentação do comando original:

`tldr numfmt`
