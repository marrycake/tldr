# genv

> Este comando é um alias de `env`.

- Ver documentação do comando original:

`tldr env`
