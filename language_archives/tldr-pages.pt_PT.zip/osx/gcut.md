# gcut

> Este comando é um alias de `cut`.

- Ver documentação do comando original:

`tldr {{[-p|--platform]}} common cut`
