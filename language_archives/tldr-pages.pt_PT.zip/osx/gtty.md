# gtty

> Este comando é um alias de `tty`.

- Ver documentação do comando original:

`tldr tty`
