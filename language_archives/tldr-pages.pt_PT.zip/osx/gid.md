# gid

> Este comando é um alias de `id`.

- Ver documentação do comando original:

`tldr id`
