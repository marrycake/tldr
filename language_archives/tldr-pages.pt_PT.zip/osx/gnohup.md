# gnohup

> Este comando é um alias de `nohup`.

- Ver documentação do comando original:

`tldr nohup`
