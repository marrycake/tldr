# gexpr

> Este comando é um alias de `expr`.

- Ver documentação do comando original:

`tldr expr`
