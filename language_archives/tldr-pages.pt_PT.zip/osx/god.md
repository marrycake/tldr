# god

> Este comando é um alias de `od`.

- Ver documentação do comando original:

`tldr od`
