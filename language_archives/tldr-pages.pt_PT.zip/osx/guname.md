# guname

> Este comando é um alias de `uname`.

- Ver documentação do comando original:

`tldr {{[-p|--platform]}} common uname`
