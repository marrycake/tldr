# gusers

> Este comando é um alias de `users`.

- Ver documentação do comando original:

`tldr users`
