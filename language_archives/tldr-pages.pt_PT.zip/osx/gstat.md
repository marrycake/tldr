# gstat

> Este comando é um alias de `stat`.

- Ver documentação do comando original:

`tldr {{[-p|--platform]}} common stat`
