# gln

> Este comando é um alias de `ln`.

- Ver documentação do comando original:

`tldr ln`
