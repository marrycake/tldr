# gpinky

> Este comando é um alias de `pinky`.

- Ver documentação do comando original:

`tldr pinky`
