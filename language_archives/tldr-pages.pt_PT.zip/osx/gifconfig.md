# gifconfig

> Este comando é um alias de `ifconfig`.

- Ver documentação do comando original:

`tldr ifconfig`
