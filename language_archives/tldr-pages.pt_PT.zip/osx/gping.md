# gping

> Este comando é um alias de `ping`.

- Ver documentação do comando original:

`tldr {{[-p|--platform]}} common ping`
