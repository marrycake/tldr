# gdd

> Este comando é um alias de `-p linux dd`.

- Exibe documentação do comando original:

`tldr {{[-p|--platform]}} linux dd`
