# gtouch

> Este comando é um alias de `touch`.

- Ver documentação do comando original:

`tldr touch`
