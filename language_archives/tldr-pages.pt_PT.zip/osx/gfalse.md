# gfalse

> Este comando é um alias de `false`.

- Ver documentação do comando original:

`tldr false`
