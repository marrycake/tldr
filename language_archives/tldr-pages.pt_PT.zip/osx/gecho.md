# gecho

> Este comando é um alias de `echo`.

- Ver documentação do comando original:

`tldr echo`
