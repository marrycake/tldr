# g[

> Este comando é um alias de `[`.

- Ver documentação do comando original:

`tldr [`
