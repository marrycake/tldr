# gnl

> Este comando é um alias de `-p linux nl`.

- Exibe documentação do comando original:

`tldr {{[-p|--platform]}} linux nl`
