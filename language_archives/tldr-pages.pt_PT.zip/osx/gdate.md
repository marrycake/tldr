# gdate

> Este comando é um alias de `date`.

- Ver documentação do comando original:

`tldr {{[-p|--platform]}} common date`
