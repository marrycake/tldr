# gchmod

> Este comando é um alias de `chmod`.

- Ver documentação do comando original:

`tldr chmod`
