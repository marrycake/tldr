# greadlink

> Este comando é um alias de `readlink`.

- Ver documentação do comando original:

`tldr readlink`
