# gwhois

> Este comando é um alias de `whois`.

- Ver documentação do comando original:

`tldr whois`
