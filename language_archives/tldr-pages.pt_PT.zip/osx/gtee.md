# gtee

> Este comando é um alias de `tee`.

- Ver documentação do comando original:

`tldr tee`
