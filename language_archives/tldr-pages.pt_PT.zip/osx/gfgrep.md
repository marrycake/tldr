# gfgrep

> Este comando é um alias de `fgrep`.

- Ver documentação do comando original:

`tldr fgrep`
