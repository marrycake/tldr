# ggroups

> Este comando é um alias de `groups`.

- Ver documentação do comando original:

`tldr groups`
