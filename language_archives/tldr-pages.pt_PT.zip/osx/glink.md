# glink

> Este comando é um alias de `link`.

- Ver documentação do comando original:

`tldr link`
