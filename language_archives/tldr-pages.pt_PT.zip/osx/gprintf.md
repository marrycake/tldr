# gprintf

> Este comando é um alias de `printf`.

- Ver documentação do comando original:

`tldr printf`
