# gfactor

> Este comando é um alias de `factor`.

- Ver documentação do comando original:

`tldr factor`
