# gmv

> Este comando é um alias de `mv`.

- Ver documentação do comando original:

`tldr mv`
