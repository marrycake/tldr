# gdircolors

> Este comando é um alias de `dircolors`.

- Ver documentação do comando original:

`tldr dircolors`
