# gchroot

> Este comando é um alias de `chroot`.

- Ver documentação do comando original:

`tldr chroot`
