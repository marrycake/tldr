# gbase32

> Este comando é um alias de `base32`.

- Ver documentação do comando original:

`tldr base32`
