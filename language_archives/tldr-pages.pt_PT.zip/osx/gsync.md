# gsync

> Este comando é um alias de `sync`.

- Ver documentação do comando original:

`tldr sync`
