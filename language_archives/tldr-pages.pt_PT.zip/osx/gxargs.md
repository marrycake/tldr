# gxargs

> Este comando é um alias de `xargs`.

- Ver documentação do comando original:

`tldr xargs`
