# gtest

> Este comando é um alias de `test`.

- Ver documentação do comando original:

`tldr test`
