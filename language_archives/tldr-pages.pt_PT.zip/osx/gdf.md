# gdf

> Este comando é um alias de `-p linux df`.

- Exibe documentação do comando original:

`tldr {{[-p|--platform]}} linux df`
