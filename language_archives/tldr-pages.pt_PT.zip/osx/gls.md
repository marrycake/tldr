# gls

> Este comando é um alias de `ls`.

- Ver documentação do comando original:

`tldr ls`
