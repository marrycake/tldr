# gsort

> Este comando é um alias de `sort`.

- Ver documentação do comando original:

`tldr sort`
