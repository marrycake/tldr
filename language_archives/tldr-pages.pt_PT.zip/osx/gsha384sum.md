# gsha384sum

> Este comando é um alias de `sha384sum`.

- Ver documentação do comando original:

`tldr sha384sum`
