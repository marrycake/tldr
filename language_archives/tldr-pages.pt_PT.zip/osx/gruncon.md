# gruncon

> Este comando é um alias de `-p linux runcon`.

- Exibe documentação do comando original:

`tldr {{[-p|--platform]}} linux runcon`
