# gfmt

> Este comando é um alias de `fmt`.

- Ver documentação do comando original:

`tldr fmt`
