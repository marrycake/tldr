# gwc

> Este comando é um alias de `wc`.

- Ver documentação do comando original:

`tldr {{[-p|--platform]}} common wc`
