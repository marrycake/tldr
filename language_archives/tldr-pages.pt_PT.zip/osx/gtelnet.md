# gtelnet

> Este comando é um alias de `telnet`.

- Ver documentação do comando original:

`tldr telnet`
