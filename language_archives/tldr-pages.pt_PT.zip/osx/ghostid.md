# ghostid

> Este comando é um alias de `hostid`.

- Ver documentação do comando original:

`tldr hostid`
