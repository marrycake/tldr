# gping6

> Este comando é um alias de `ping6`.

- Ver documentação do comando original:

`tldr ping6`
