# guniq

> Este comando é um alias de `uniq`.

- Ver documentação do comando original:

`tldr uniq`
