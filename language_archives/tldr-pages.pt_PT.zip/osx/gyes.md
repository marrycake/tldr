# gyes

> Este comando é um alias de `yes`.

- Ver documentação do comando original:

`tldr yes`
