# grealpath

> Este comando é um alias de `realpath`.

- Ver documentação do comando original:

`tldr realpath`
