# gtraceroute

> Este comando é um alias de `traceroute`.

- Ver documentação do comando original:

`tldr traceroute`
