# gtr

> Este comando é um alias de `tr`.

- Ver documentação do comando original:

`tldr tr`
