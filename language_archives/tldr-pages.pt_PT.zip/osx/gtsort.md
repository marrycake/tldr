# gtsort

> Este comando é um alias de `tsort`.

- Ver documentação do comando original:

`tldr tsort`
