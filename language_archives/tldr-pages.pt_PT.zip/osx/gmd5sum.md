# gmd5sum

> Este comando é um alias de `md5sum`.

- Ver documentação do comando original:

`tldr md5sum`
