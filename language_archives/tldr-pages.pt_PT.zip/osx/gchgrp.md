# gchgrp

> Este comando é um alias de `chgrp`.

- Ver documentação do comando original:

`tldr chgrp`
