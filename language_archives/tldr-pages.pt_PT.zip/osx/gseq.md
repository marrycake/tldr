# gseq

> Este comando é um alias de `seq`.

- Ver documentação do comando original:

`tldr seq`
