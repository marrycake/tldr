# gpathchk

> Este comando é um alias de `pathchk`.

- Ver documentação do comando original:

`tldr pathchk`
