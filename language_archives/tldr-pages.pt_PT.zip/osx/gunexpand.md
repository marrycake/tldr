# gunexpand

> Este comando é um alias de `unexpand`.

- Ver documentação do comando original:

`tldr unexpand`
