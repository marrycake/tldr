# gnice

> Este comando é um alias de `nice`.

- Ver documentação do comando original:

`tldr nice`
