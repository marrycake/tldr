# guptime

> Este comando é um alias de `uptime`.

- Ver documentação do comando original:

`tldr {{[-p|--platform]}} common uptime`
