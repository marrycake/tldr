# batcat

> Este comando é um alias de `bat`.

- Exibe documentação do comando original:

`tldr bat`
