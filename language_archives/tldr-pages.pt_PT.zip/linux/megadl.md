# megadl

> Este comando é um alias de `megatools-dl`.

- Exibe documentação do comando original:

`tldr megatools-dl`
