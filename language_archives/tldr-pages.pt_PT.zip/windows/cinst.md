# cinst

> Este comando é um alias de `choco install`.

- Exibe documentação do comando original:

`tldr choco install`
