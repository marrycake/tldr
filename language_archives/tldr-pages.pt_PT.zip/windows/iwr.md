# iwr

> Este comando é um alias de `invoke-webrequest`.

- Exibe documentação do comando original:

`tldr invoke-webrequest`
