# pwsh where

> Este comando é um alias de `Where-Object`.

- Exibe documentação do comando original:

`tldr Where-Object`
