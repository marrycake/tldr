# chrome

> Este comando é um alias de `chromium`.
> Mais informações: <https://chrome.google.com>.

- Exibe documentação do comando original:

`tldr chromium`
