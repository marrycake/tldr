# toolbox help

> `toolbox` பற்றிய உதவித் தகவலைக் காட்டுகிறது.
> மேலும் விவரத்திற்கு: <https://manned.org/toolbox-help.1>.

- `toolbox` கையேட்டைக் காண்பி:

`toolbox help`

- குறிப்பிட்ட துணைக் கட்டளைக்கான `toolbox` கையேட்டைக் காண்பி:

`toolbox help {{துணை_கட்டளை}}`
