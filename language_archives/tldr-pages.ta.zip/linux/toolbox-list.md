# toolbox list

> ஏற்கனவே உள்ள `toolbox' கொள்கலன்களையும் படங்களையும் பட்டியலிடுங்கள்.
> மேலும் விவரத்திற்கு: <https://manned.org/toolbox-list.1>.

- அனைத்து `toolbox` கொள்கலன்களையும் படங்களையும் பட்டியலிடுங்கள்:

`toolbox list`

- `toolbox` கொள்கலன்களை மட்டும் பட்டியலிடுங்கள்:

`toolbox list --containers`

- `toolbox` படங்களை மட்டும் பட்டியலிடுங்கள்:

`toolbox list --images`
