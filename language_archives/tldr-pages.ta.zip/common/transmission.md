# transmission

> Transmission ஒரு எளிய டொரண்ட் (torrent) வாடிக்கையாளர்.
> Transmission ஒரு கட்டளை அல்ல, ஆனால் கட்டளைகளின் தொகுப்பு. கீழே உள்ள பக்கங்களைப் பார்க்கவும்.
> மேலும் விவரத்திற்கு: <https://transmissionbt.com/>.

- Transmission டீமானை இயக்குவதற்கு tldr பக்கத்தைக் காட்டு:

`tldr transmission-daemon`

- டெமானுடன் தொடர்புகொள்வதற்கு tldr பக்கத்தைக் காட்டு:

`tldr transmission-remote`

- டொரண்ட் கோப்புகளை உருவாக்க tldr பக்கத்தைக் காட்டு:

`tldr transmission-create`

- டொரண்ட் கோப்புகளை மாற்றுவதற்கு tldr பக்கத்தைக் காட்டு:

`tldr transmission-edit`

- டொரண்ட் கோப்புகளைப் பற்றிய தகவலைப் பெற tldr பக்கத்தைக் காட்டு:

`tldr transmission-show`

- டெமானுடன் தொடர்புகொள்வதற்கான தடுக்கப்பட்ட முறைக்கான tldr பக்கத்தைக் காட்டு:

`tldr transmission-cli`
