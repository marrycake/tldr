# ac

> چاپ مدت زمان اتصال کاربران.
> اطلاعات بیشتر: <https://www.gnu.org/software/acct/manual/accounting.html#ac>.

- چاپ تعداد ساعات اتصال کاربر کنونی:

`ac`

- چاپ تعداد ساعات اتصال کاربران:

`ac {{[-p|--individual-totals]}}`

- چاپ تعداد ساعات اتصال یک کاربر خاص:

`ac {{[-p|--individual-totals]}} {{username}}`

- چاپ تعداد ساعات اتصال یک کاربر خاص (به همراه مجموع آن):

`ac {{[-d|--daily-totals]}} {{[-p|--individual-totals]}} {{username}}`

- نمایش اطلاعات بیشتر:

`ac --compatibility`
