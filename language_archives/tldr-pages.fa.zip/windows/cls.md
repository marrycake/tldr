# cls

> پاک کردن صفحه.
> اطلاعات بیشتر: <https://learn.microsoft.com/windows-server/administration/windows-commands/cls>.

- پاک کردن صفحه:

`cls`
