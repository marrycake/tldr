# apktool

> مهندسی معکوس فایل های APK.
> اطلاعات بیشتر: <https://ibotpeaches.github.io/Apktool/>.

- رمزگشایی یک فایل APK:

`apktool d {{path/to/file.apk}}`

- ساخت یک فایل APK از یک دایرکتوری:

`apktool b {{path/to/directory}}`

- نصب و ذخیره یک فریمورک:

`apktool if {{path/to/framework.apk}}`
