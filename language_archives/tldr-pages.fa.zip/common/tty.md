# tty

> نمایش نام ترمینال.
> اطلاعات بیشتر: <https://www.gnu.org/software/coreutils/manual/html_node/tty-invocation.html>.

- نمایش نام فایل ترمینال جاری:

`tty`
