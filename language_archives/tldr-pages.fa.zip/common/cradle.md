# cradle

> فریمورک پی اچ پی cradle.
> بعضی از زیردستور ها مانند `install` مستندات خاص خود را دارند.
> اطلاعات بیشتر: <https://cradlephp.github.io>.

- اتصال به یک سرور:

`cradle connect {{server_name}}`

- اجرای یک دستور Cradle:

`cradle {{command}}`

- نمایش راهنما:

`cradle help`

- نمایش راهنما برای یک دستور خاص:

`cradle {{command}} help`
