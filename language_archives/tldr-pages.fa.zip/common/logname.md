# logname

> نمایش نام کاربر.
> اطلاعات بیشتر: <https://www.gnu.org/software/coreutils/manual/html_node/logname-invocation.html>.

- نمایش نام کاربر لاگین شده:

`logname`
