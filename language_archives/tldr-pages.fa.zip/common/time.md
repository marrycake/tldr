# time

> نمایش زمان اجرای یک دستور.
> اطلاعات بیشتر: <https://manned.org/time>.

- نمایش زمان اجرای دستور `command`:

`time {{command}}`
