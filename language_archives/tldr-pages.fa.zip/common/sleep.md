# sleep

> ایجاد تاخیر بر اساس زمان.
> اطلاعات بیشتر: <https://pubs.opengroup.org/onlinepubs/9699919799/utilities/sleep.html>.

- تاخیر به ثانیه:

`sleep {{seconds}}`

- تاخیر به دقیقه:

`sleep {{minutes}}m`

- تاخیر به ساعت:

`sleep {{hours}}h`
