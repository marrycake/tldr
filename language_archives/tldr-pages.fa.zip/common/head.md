# head

> نمایش محتوای ابتدایی یک فایل.
> اطلاعات بیشتر: <https://manned.org/head.1p>.

- نمایش چند خط اول یک فایل:

`head -n {{count}} {{path/to/file}}`
