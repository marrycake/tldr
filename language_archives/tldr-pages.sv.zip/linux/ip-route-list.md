# ip route list

> Det här kommandot är ett alias för `ip route show`.

- Se dokumentationen för orginalkommandot:

`tldr ip route show`
