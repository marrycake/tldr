# sls

> Det här kommandot är ett alias för `Select-String`.

- Se dokumentationen för orginalkommandot:

`tldr select-string`
