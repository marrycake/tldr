# logname

> Visar användarens inloggningsnamn.
> Mer information: <https://www.gnu.org/software/coreutils/manual/html_node/logname-invocation.html>.

- Visa den för tillfället inloggades användarnamn:

`logname`
