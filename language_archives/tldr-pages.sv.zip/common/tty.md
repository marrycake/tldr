# tty

> Returnerar terminalnamn.
> Mer information: <https://www.gnu.org/software/coreutils/manual/html_node/tty-invocation.html>.

- Skriv ut filnamnet på denna terminal:

`tty`
