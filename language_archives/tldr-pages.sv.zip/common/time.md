# time

> Se hur lång tid ett kommando tar.
> Mer information: <https://manned.org/time>.

- Tidtagning `command`:

`time {{command}}`
