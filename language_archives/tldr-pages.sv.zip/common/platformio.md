# platformio

> Det här kommandot är ett alias för `pio`.

- Se dokumentationen för orginalkommandot:

`tldr pio`
