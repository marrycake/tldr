# pio init

> Det här kommandot är ett alias för `pio project`.

- Se dokumentationen för orginalkommandot:

`tldr pio project`
