# llvm-gcc

> Det här kommandot är ett alias för `clang`.

- Se dokumentationen för orginalkommandot:

`tldr clang`
