# false

> Returnerar en utgångskod på 1.
> Mer information: <https://www.gnu.org/software/coreutils/manual/html_node/false-invocation.html>.

- Returnera en utgångskod på 1:

`false`
