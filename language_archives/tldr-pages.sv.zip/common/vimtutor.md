# vimtutor

> Vim-handledare, lär ut de grundläggande vim-kommandona.
> Mer information: <https://manned.org/vimtutor>.

- Starta vim-handledaren med det angivna språket (en, fr, de, ...):

`vimtutor {{språk}}`

- Gå ur handledaren:

`<Esc><:>q<Enter>`
