# mscore

> Det här kommandot är ett alias för `musescore`.

- Se dokumentationen för orginalkommandot:

`tldr musescore`
