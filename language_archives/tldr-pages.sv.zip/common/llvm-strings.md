# llvm-strings

> Det här kommandot är ett alias för `strings`.

- Se dokumentationen för orginalkommandot:

`tldr strings`
