# atrm

> Elimina trabajos programados por comandos `at` o `batch`.
> Para encontrar los números de trabajo usa `atq`.
> Más información: <https://manned.org/atrm>.

- Elimina el trabajo número 10:

`atrm {{10}}`

- Elimina varios trabajos, separados por espacios:

`atrm {{15}} {{17}} {{22}}`
