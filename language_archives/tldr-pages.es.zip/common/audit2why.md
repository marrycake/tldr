# audit2why

> Este comando es un alias de `audit2allow --why`.

- Vea la documentación del comando original:

`tldr audit2allow`
