# dtrx

> "Do The Right eXtraction" - extrae cualquier archivo en un directorio nuevo adivinando la herramienta a partir de la extensión.
> Más información: <https://github.com/dtrx-py/dtrx>.

- Extrae el archivo, adivinando la herramienta de extracción de la extensión:

`dtrx {{ruta/al/archivo}}`

- Extrae el archivo, sobrescribe cualquier salida de destino existente:

`dtrx --overwrite {{ruta/al/archivo}}`

- Extrae archivo, pone todo en el directorio actual:

`dtrx --flat {{ruta/al/archivo}}`
