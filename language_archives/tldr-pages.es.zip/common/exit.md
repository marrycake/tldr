# exit

> Sale de la interfaz de comandos.
> Más información: <https://manned.org/exit.1posix>.

- Sale con el estado de salida del comando más recientemente ejecutado:

`exit`

- Sale con un estado de salida específico:

`exit {{estado_de_salida}}`
