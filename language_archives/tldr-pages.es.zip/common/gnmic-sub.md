# gnmic sub

> Este comando es un alias de `gnmic subscribe`.

- Vea la documentación del comando original:

`tldr gnmic subscribe`
