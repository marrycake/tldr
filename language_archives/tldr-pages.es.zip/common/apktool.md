# apktool

> Ingeniería inversa de archivos APK.
> Más información: <https://ibotpeaches.github.io/Apktool/>.

- Decodifica un archivo APK:

`apktool d {{archivo.apk}}`

- Construye un archivo APK desde un directorio:

`apktool b {{ruta/al/directorio}}`

- Instala y almacena un framework:

`apktool if {{framework.apk}}`
