# img2sixel

> Convierte imágenes al formato Sixel para mostrarlas en un terminal.
> Más información: <https://manned.org/img2sixel>.

- Muestra una imagen en el terminal:

`img2sixel {{ruta/a/imagen}}`

- Redimensiona la imagen a la anchura y altura especificadas antes de mostrarla:

`img2sixel {{[-w|--width]}} {{número}} {{[-h|--altura]}} {{número}} {{ruta/a/imagen}}`
