# impacket-rpcdump

> Este comando es un alias de `rpcdump.py`.

- Vea la documentación del comando original:

`tldr rpcdump.py`
