# impacket-ntfs-read

> Este comando es un alias de `ntfs-read.py`.

- Vea la documentación del comando original:

`tldr ntfs-read.py`
