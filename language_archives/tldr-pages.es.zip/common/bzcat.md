# bzcat

> Este comando es un alias de `bzip2 --decompress --stdout`.

- Vea la documentación del comando original:

`tldr bzip2`
