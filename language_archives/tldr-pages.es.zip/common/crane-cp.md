# crane cp

> Este comando es un alias de `crane copy`.

- Vea la documentación para el comando original:

`tldr crane copy`
