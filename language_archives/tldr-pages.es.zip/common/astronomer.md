# astronomer

> Herramienta que detecta estrellas ilegítimas de cuentas bot en proyectos de GitHub.
> Más información: <https://github.com/Ullaakut/astronomer>.

- Escanea un repositorio:

`astronomer {{tldr-pages/tldr-node-client}}`

- Escanea el máximo de estrellas del repositorio:

`astronomer {{tldr-pages/tldr-node-client}} --stars {{50}}`

- Escanea un repositorio incluyendo informes comparativos:

`astronomer {{tldr-pages/tldr-node-client}} --verbose`
