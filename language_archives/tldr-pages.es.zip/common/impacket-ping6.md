# impacket-ping6

> Este comando es un alias de `ping6.py`.

- Vea la documentación del comando original:

`tldr ping6.py`
