# impacket-mssqlclient

> Este comando es un alias de `mssqlclient.py`.

- Vea la documentación del comando original:

`tldr mssqlclient.py`
