# gh cs

> Este comando es un alias de `gh codespace`.

- Vea la documentación del comando original:

`tldr gh codespace`
