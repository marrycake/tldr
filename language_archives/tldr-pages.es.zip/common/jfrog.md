# jfrog

> Este comando es un alias de `jf`.

- Vea la documentación para el comando original:

`tldr jf`
