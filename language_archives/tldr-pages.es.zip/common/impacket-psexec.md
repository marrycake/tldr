# impacket-psexec

> Este comando es un alias de `psexec.py`.

- Vea la documentación del comando original:

`tldr psexec.py`
