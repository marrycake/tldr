# elinks

> Un navegador basado en texto similar a `lynx`.
> Más información: <https://github.com/rkd77/elinks>.

- Inicia ELinks:

`elinks`

- Sale de ELinks:

`<Ctrl c>`

- Vuelca la página web a la consola, colorea el texto con códigos de control ANSI:

`elinks -dump -dump-color-mode {{1}} {{url}}`
