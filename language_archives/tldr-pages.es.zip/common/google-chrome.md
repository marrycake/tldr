# google-chrome

> Este comando es un alias de `chromium`.
> Más información: <https://chrome.google.com>.

- Muestra la documentación del comando original:

`tldr chromium`
