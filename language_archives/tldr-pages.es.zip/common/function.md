# function

> Define una función.
> Más información: <https://www.gnu.org/software/bash/manual/bash.html#Shell-Functions>.

- Define una función con el nombre especificado:

`function {{func_name}} { {{echo "Contenido de la función aquí"}}; }`

- Ejecuta una función llamada `func_name`:

`func_name`
