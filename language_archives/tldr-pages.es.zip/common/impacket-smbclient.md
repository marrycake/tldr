# impacket-smbclient

> Este comando es un alias de `smbclient.py`.

- Vea la documentación del comando original:

`tldr smbclient.py`
