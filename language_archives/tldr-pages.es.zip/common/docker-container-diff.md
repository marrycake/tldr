# docker container diff

> Este comando es un alias de `docker diff`.

- Muestra la documentación del comando original:

`tldr docker diff`
