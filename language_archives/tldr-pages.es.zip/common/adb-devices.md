# adb devices

> Lista los dispositivos Android conectados.
> Más información: <https://manned.org/adb>.

- Lista los dispositivos:

`adb devices`

- Lista los dispositivos y su información de sistema (system info):

`adb devices -l`
