# adb disconnect

> Este comando ha sido movido a `adb connect`.

- Vea la documentación para `adb disconnect`:

`tldr adb connect`
