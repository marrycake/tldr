# carbonyl

> Vea páginas web en el terminal usando un backend de Chromium.
> Más información: <https://github.com/fathyb/carbonyl>.

- Abre una página `about:blank`:

`carbonyl`

- Abre una página web:

`carbonyl {{https://example.com}}`

- Sale de carbonyl:

`<Ctrl c>`

- Muestra la ayuda:

`carbonyl {{[-h|--help]}}`
