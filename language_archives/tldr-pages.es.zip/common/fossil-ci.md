# fossil ci

> Este comando es un alias de `fossil commit`.

- Vea la documentación del comando original:

`tldr fossil commit`
