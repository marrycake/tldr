# impacket-sniff

> Este comando es un alias de `sniff.py`.

- Vea la documentación del comando original:

`tldr sniff.py`
