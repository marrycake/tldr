# impacket-rpcmap

> Este comando es un alias de `rpcmap.py`.

- Vea la documentación del comando original:

`tldr rpcmap.py`
