# convert

> Este comando es un alias de `magick convert`.
> Nota: Este alias está obsoleto desde ImageMagick 7. Ha sido reemplazado por `magick`.
> Utiliza `magick convert` si necesitas utilizar la herramienta antigua en versiones 7+.

- Muestra la documentación del comando original:

`tldr magick convert`
