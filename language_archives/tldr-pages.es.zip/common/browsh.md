# browsh

> Vea páginas web en el terminal utilizando un backend de Firefox.
> Más información: <https://www.brow.sh/>.

- Inicia browsh:

`browsh`

- Inicia browsh en una página web específica:

`browsh --startup-url {{URL}}`

- Se focaliza en la barra de dirección URL:

`<Ctrl l>`

- Sale de browsh:

`<Ctrl q>`

- Muestra la ayuda:

`browsh {{[-h|--help]}}`
