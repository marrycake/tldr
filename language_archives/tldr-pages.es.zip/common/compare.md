# compare

> Este comando es un alias de `magick compare`.

- Muestra la documentación del comando original:

`tldr magick compare`
