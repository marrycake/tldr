# impacket-smbserver

> Este comando es un alias de `smbserver.py`.

- Vea la documentación del comando original:

`tldr smbserver.py`
