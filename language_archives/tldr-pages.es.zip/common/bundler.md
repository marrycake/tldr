# bundler

> Gestor de dependencias para el lenguaje de programación Ruby.
> `bundler` es un nombre común para el comando `bundle`, pero no un comando en sí.
> Más información: <https://bundler.io/man/bundle.1.html>.

- Muestra la documentación del comando original:

`tldr bundle`
