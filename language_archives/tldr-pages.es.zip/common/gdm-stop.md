# gdm-stop

> Detiene inmediatamente la ejecución del gestor de pantalla GNOME (GDM).
> Vea también: `gdm`, `gdm-binary`, `gdmsetup`, `gdm-restart`, `gdm-safe-restart`.
> Más información: <https://manned.org/gdm>.

- Detiene la aplicación del gestor de pantalla GNOME:

`gdm-stop`
