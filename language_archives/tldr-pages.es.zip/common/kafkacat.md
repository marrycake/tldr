# kafkacat

> Este comando es un alias de `kcat`.

- Muestra la documentación del comando original:

`tldr kcat`
