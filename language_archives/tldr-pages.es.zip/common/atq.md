# atq

> Muestra trabajos programados por comandos `at` o `batch`.
> Más información: <https://manned.org/atq>.

- Muestra los trabajos programados del usuario actual:

`atq`

- Muestra trabajos de la 'a' [q]ueue (las colas tienen nombres de caracteres individuales):

`atq -q {{a}}`

- Muestra trabajos de todos los usuarios (ejecuta como superusuario):

`sudo atq`
