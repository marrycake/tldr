# fossil init

> Inicia un nuevo repositorio para un proyecto.
> Vea también: `fossil clone`.
> Más información: <https://fossil-scm.org/home/help/init>.

- Crea un nuevo repositorio en un archivo:

`fossil init {{ruta/al/archivo}}`
