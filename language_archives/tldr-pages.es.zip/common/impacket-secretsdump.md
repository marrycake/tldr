# impacket-secretsdump

> Este comando es un alias de `secretsdump.py`.

- Vea la documentación del comando original:

`tldr secretsdump.py`
