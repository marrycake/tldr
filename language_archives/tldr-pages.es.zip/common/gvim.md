# gvim

> Una versión de interfaz gráfica de usuario de Vim (Vi IMproved), un editor de texto de línea de comandos.
> Vea también: `vimdiff`, `vimtutor`, `nvim`, `vim`.
> Más información: <https://www.vim.org>.

- Abre `gvim`:

`gvim`

- Abre un archivo específico:

`gvim {{ruta/al/archivo}}`
