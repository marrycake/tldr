# adb pair

> Este comando ha sido movido a `adb connect`.

- Vea la documentación para `adb pair`:

`tldr adb connect`
