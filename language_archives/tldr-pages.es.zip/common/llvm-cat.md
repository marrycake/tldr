# llvm-cat

> Concatena archivos bitcode LLVM (`.bc`).
> Más información: <https://github.com/llvm/llvm-project/blob/main/llvm/tools/llvm-cat/llvm-cat.cpp>.

- Concatena archivos de bitcode:

`llvm-cat {{ruta/al/archivo1.bc}} {{ruta/al/archivo2.bc}} -o {{ruta/a/concatenado.bc}}`
