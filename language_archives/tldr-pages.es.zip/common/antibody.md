# antibody

> "El más rápido" administrador de complementos de shell.
> Más información: <https://getantibody.github.io>.

- Empaqueta todos los complementos para su carga estática:

`antibody bundle < {{~/.zsh_plugins.txt}} > {{~/.zsh_plugins.sh}}`

- Actualiza todos los empaquetados:

`antibody update`

- Lista todos los complementos instalados:

`antibody list`
