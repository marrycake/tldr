# impacket-getArch

> Este comando es un alias de `getArch.py`.

- Vea la documentación del comando original:

`tldr getArch.py`
