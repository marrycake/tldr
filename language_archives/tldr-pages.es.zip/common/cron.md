# cron

> Un programador del sistema para ejecutar trabajos o tareas desatendidas.
> El comando para enviar, editar o borrar entradas en `cron` se llama `crontab`.

- Vea documentación sobre la gestión de entradas de `cron`:

`tldr crontab`
