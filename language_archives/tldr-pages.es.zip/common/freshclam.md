# freshclam

> Actualiza definiciones de virus para el programa antivirus ClamAV.
> Más información: <https://www.clamav.net>.

- Actualiza definiciones de virus:

`freshclam`
