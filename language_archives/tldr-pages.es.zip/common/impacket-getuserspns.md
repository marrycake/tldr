# impacket-GetUserSPNs

> Este comando es un alias de `GetNPUsers.py`.

- Vea la documentación del comando original:

`tldr GetUserSPNs.py`
