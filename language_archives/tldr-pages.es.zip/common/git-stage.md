# git stage

> Este comando es un alias de `git add`.

- Vea la documentación para el comando original:

`tldr git add`
