# adb uninstall

> Desinstala un paquete.
> Más información: <https://manned.org/adb>.

- Desinstala un paquete:

`adb uninstall {{com.example.app}}`

- Desinstala un paquete, pero conservando los datos del usuario:

`adb uninstall -k {{com.example.app}}`
