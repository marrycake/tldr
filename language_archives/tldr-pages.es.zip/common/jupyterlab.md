# jupyterlab

> Este comando es un alias de `jupyter lab`.

- Vea la documentación del comando original:

`tldr jupyter lab`
