# gdm-binary

> Este comando es un alias de `gdm`.

- Vea la documentación del comando original:

`tldr gdm`
