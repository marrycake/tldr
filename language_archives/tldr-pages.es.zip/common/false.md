# false

> Devuelve un código de salida distinto a cero.
> Más información: <https://www.gnu.org/software/coreutils/manual/html_node/false-invocation.html>.

- Devuelve un código de salida distinto a cero:

`false`
