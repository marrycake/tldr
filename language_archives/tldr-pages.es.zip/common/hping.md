# hping

> Este comando es un alias de `hping3`.

- Vea la documentación para el comando original:

`tldr hping3`
