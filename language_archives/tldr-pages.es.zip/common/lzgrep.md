# lzgrep

> Este comando es un alias de `xzgrep`.

- Vea la documentación para el comando original:

`tldr xzgrep`
