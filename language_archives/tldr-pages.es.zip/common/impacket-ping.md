# impacket-ping

> Este comando es un alias de `ping.py`.

- Vea la documentación del comando original:

`tldr ping.py`
