# lzfgrep

> Este comando es un alias de `xzgrep --fixed-strings`.
> Vea también: `fgrep`.

- Vea la documentación para el comando original:

`tldr xzgrep`
