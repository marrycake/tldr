# lzcat

> Este comando es un alias de `xz --format=lzma --decompress --stdout`.

- Vea la documentación para el comando original:

`tldr xz`
