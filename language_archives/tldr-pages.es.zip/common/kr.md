# kr

> Este comando es un alias de `kiterunner`.

- Vea la documentación del comando original:

`tldr kiterunner`
