# impacket-mqtt_check

> Este comando es un alias de `mqtt_check.py`.

- Vea la documentación del comando original:

`tldr mqtt_check.py`
