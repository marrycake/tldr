# hd

> Este comando es un alias de `hexdump`.

- Vea la documentación para el comando original:

`tldr hexdump`
