# impacket-GetNPUsers

> Este comando es un alias de `GetNPUsers.py`.

- Vea la documentación del comando original:

`tldr GetNPUsers.py`
