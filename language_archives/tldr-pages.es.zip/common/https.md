# https

> Este comando es un alias de `http`.

- Consulte la documentación del comando original:

`tldr http`
