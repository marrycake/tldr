# bunzip2

> Este comando es un alias de `bzip2 --decompress`.

- Vea la documentación del comando original:

`tldr bzip2`
