# docker container top

> Este comando es un alias de `docker top`.

- Vea la documentación para el comando original:

`tldr docker top`
