# import

> Este comando es un alias de `magick import`.

- Vea la documentación para el comando original:

`tldr magick import`
