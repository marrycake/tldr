# lzegrep

> Este comando es un alias de `xzgrep --extended-regexp`.
> Vea también: `egrep`.

- Vea la documentación para el comando original:

`tldr xzgrep`
