# copr

> Este comando es un alias de `copr-cli`.

- Vea la documentación del comando original:

`tldr copr-cli`
