# bugreport

> Muestra un informe de error de Android.
> Este comando solo se puede usar a través de `adb shell`.
> Más información: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- Muestra un informe completo de errores de un dispositivo Android:

`bugreport`
