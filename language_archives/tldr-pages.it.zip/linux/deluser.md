# deluser

> Rimuovi un account utente o un utente da un gruppo.
> Maggiori informazioni: <https://manned.org/deluser>.

- Rimuovi un utente:

`deluser {{nome}}`

- Rimuovi un utente insieme alla sua directory home e raccolta mail:

`deluser -r {{nome}}`

- Rimuovi un utente da un gruppo:

`deluser {{nome}} {{gruppo}}`
