# alternatives

> Questo comando è un alias per `update-alternatives`.

- Consulta la documentazione del comando originale:

`tldr update-alternatives`
