# batcat

> Questo comando è un alias per `bat`.

- Consulta la documentazione del comando originale:

`tldr bat`
