# megadl

> Questo comando è un alias per `megatools-dl`.

- Consulta la documentazione del comando originale:

`tldr megatools-dl`
