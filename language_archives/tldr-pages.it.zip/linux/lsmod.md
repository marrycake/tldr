# lsmod

> Mostra lo stato dei moduli del kernel Linux.
> Vedi anche `modprobe`, che carica i moduli del kernel.
> Maggiori informazioni: <https://manned.org/lsmod>.

- Elenca tutti i moduli del kernel attualmente caricati:

`lsmod`
