# a2enconf

> Attiva un file di configurazione Apache su sistemi operativi basati su Debian.
> Maggiori informazioni: <https://manned.org/a2enconf.8>.

- Attiva un file di configurazione:

`sudo a2enconf {{file_di_configurazione}}`

- Non mostrare messaggi informativi:

`sudo a2enconf --quiet {{file_di_configurazione}}`
