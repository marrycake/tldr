# reset

> Reinizializza il terminale corrente. Cancella l'intera schermata del terminale.
> Maggiori informazioni: <https://manned.org/reset>.

- Reinizializza il terminale corrente:

`reset`

- Visualizza invece il tipo di terminale:

`reset -q`
