# a2dismod

> Disattiva un modulo Apache su sistemi operativi basati su Debian.
> Maggiori informazioni: <https://manned.org/a2dismod.8>.

- Disattiva un modulo:

`sudo a2dismod {{modulo}}`

- Non mostrare messaggi informativi:

`sudo a2dismod --quiet {{modulo}}`
