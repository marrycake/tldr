# ubuntu-bug

> Questo comando è un alias per `apport-bug`.

- Consulta la documentazione del comando originale:

`tldr apport-bug`
