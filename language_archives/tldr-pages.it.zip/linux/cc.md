# cc

> Questo comando è un alias per `gcc`.

- Consulta la documentazione del comando originale:

`tldr gcc`
