# bastet

> Clone di Tetris nel Terminale.
> Maggiori informazioni: <https://fph.altervista.org/prog/bastet.html>.

- Invia un gioco tetris:

`bastet`

- Sposta il pezzo a sinistra o a destra:

`{{<ArrowLeft>|<ArrowRight>}}`

- Ruota in senso orario o inverso:

`{{<Space>|<ArrowUp>}}`

- Caduta lenta:

`<ArrowDown>`

- Caduta veloce:

`<Enter>`

- Pausa:

`<p>`

- Lasciare il gioco:

`<Ctrl c>`
