# hello

> Stampa a schermo "Hello, world!", "hello, world" oppure del testo personalizzabile.
> Maggiori informazioni: <https://www.gnu.org/software/hello/manual/html_node/Invoking-hello.html>.

- Stampa a schermo "Hello, world!":

`hello`

- Stampa a schermo "hello, world", nel modo tradizionale:

`hello {{[-t|--traditional]}}`

- Stampa a schermo un messaggio:

`hello {{[-g|--greeting]}} "{{messaggio}}"`
