# xkill

> Termina una finestra interattivamente attraverso la sessione grafica.
> Vedi anche `kill` e `killall`.
> Maggiori informazioni: <https://www.x.org/releases/current/doc/man/man1/xkill.1.xhtml>.

- Mostra un cursore per terminate una finestra cliccandoci sopra con il tasto sinistro del mouse (premendo qualsiasi altro tasto si cancella l'azione):

`xkill`
