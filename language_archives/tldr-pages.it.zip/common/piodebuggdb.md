# piodebuggdb

> Questo comando è un alias per `pio debug`.

- Consulta la documentazione del comando originale:

`tldr pio debug`
