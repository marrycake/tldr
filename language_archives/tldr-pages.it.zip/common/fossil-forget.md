# fossil forget

> Questo comando è un alias per `fossil rm`.
> Maggiori informazioni: <https://fossil-scm.org/home/help/forget>.

- Consulta la documentazione del comando originale:

`tldr fossil rm`
