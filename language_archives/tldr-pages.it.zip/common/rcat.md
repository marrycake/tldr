# rcat

> Questo comando è un alias per `rc`.

- Consulta la documentazione del comando originale:

`tldr rc`
