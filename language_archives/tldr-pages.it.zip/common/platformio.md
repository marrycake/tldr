# platformio

> Questo comando è un alias per `pio`.

- Consulta la documentazione del comando originale:

`tldr pio`
