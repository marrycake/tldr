# dive

> Un tool per esplorare immagini Docker, contenuti dei livelli, e ridurne la dimensione.
> Maggiori informazioni: <https://github.com/wagoodman/dive>.

- Analizza un'immagine Docker:

`dive {{tag_immagine}}`

- Costruisci un'immagine ed avvia l'analisi:

`dive build -t {{tag}}`
