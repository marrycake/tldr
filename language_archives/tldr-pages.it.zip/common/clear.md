# clear

> Pulisce lo schermo del terminale.
> Maggiori informazioni: <https://manned.org/clear>.

- Pulisci lo schermo (equivalente a `<Ctrl l>` se si utilizza la shell Bash):

`clear`
