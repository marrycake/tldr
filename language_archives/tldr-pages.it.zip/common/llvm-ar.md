# llvm-ar

> Questo comando è un alias per `ar`.

- Consulta la documentazione del comando originale:

`tldr ar`
