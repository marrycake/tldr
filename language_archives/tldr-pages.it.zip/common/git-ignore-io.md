# git ignore-io

> Genera file .gitignore usando template predefiniti.
> Maggiori informazioni: <https://github.com/tj/git-extras/blob/master/Commands.md#git-ignore-io>.

- Elenca i template disponibili:

`git ignore-io list`

- Genera un template `.gitignore`:

`git ignore-io {{elemento_a,elemento_b,elemento_n}}`
