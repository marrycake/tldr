# fossil delete

> Questo comando è un alias per `fossil rm`.

- Consulta la documentazione del comando originale:

`tldr fossil rm`
