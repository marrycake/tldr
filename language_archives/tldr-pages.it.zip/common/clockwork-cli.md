# clockwork-cli

> Una interfaccia da linea di comando per il framework PHP Clockwork.
> Maggiori informazioni: <https://github.com/ptrofimov/clockwork-cli>.

- Monitora i log di Clockwork per il progetto corrente:

`clockwork-cli`

- Monitora i log di Clockwork per uno specifico progetto:

`clockwork-cli {{percorso/della/directory_progetto}}`

- Monitora i log di Clockwork per più progetti:

`clockwork-cli {{percorso/della/directory1 percorso/della/directory2 ...}}`
