# python3

> Questo comando è un alias di `python`.

- Consulta la documentazione del comando originale:

`tldr python`
