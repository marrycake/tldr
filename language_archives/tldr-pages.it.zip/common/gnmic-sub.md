# gnmic sub

> Questo comando è un alias per `gnmic subscribe`.

- Consulta la documentazione del comando originale:

`tldr gnmic subscribe`
