# gexpand

> Questo comando è un alias per `expand`.

- Consulta la documentazione del comando originale:

`tldr expand`
