# gcomm

> Questo comando è un alias per `comm`.

- Consulta la documentazione del comando originale:

`tldr comm`
