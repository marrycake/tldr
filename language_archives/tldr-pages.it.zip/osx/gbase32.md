# gbase32

> Questo comando è un alias per `base32`.

- Consulta la documentazione del comando originale:

`tldr base32`
