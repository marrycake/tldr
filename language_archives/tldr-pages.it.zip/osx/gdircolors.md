# gdircolors

> Questo comando è un alias per `dircolors`.

- Consulta la documentazione del comando originale:

`tldr dircolors`
