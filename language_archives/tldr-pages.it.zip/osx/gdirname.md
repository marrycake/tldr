# gdirname

> Questo comando è un alias per `dirname`.

- Consulta la documentazione del comando originale:

`tldr dirname`
