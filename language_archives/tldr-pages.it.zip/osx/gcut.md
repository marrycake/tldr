# gcut

> Questo comando è un alias per `cut`.

- Consulta la documentazione del comando originale:

`tldr {{[-p|--platform]}} common cut`
