# gbasenc

> Questo comando è un alias per `basenc`.

- Consulta la documentazione del comando originale:

`tldr basenc`
