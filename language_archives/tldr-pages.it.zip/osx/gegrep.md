# gegrep

> Questo comando è un alias per `egrep`.

- Consulta la documentazione del comando originale:

`tldr egrep`
