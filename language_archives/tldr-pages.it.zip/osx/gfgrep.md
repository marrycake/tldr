# gfgrep

> Questo comando è un alias per `fgrep`.

- Consulta la documentazione del comando originale:

`tldr fgrep`
