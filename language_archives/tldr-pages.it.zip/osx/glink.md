# glink

> Questo comando è un alias per `link`.

- Consulta la documentazione del comando originale:

`tldr link`
