# gftp

> Questo comando è un alias per `ftp`.

- Consulta la documentazione del comando originale:

`tldr ftp`
