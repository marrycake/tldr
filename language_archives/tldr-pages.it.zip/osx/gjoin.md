# gjoin

> Questo comando è un alias per `join`.

- Consulta la documentazione del comando originale:

`tldr join`
