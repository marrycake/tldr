# gdnsdomainname

> Questo comando è un alias per `-p linux dnsdomainname`.

- Consulta la documentazione del comando originale:

`tldr {{[-p|--platform]}} linux dnsdomainname`
