# gifconfig

> Questo comando è un alias per `ifconfig`.

- Consulta la documentazione del comando originale:

`tldr ifconfig`
