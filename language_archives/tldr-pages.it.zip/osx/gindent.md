# gindent

> Questo comando è un alias per `indent`.

- Consulta la documentazione del comando originale:

`tldr {{[-p|--platform]}} common indent`
