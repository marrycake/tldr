# ggrep

> Questo comando è un alias per `grep`.

- Consulta la documentazione del comando originale:

`tldr grep`
