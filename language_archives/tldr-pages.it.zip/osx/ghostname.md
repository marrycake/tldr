# ghostname

> Questo comando è un alias per `hostname`.

- Consulta la documentazione del comando originale:

`tldr hostname`
