# gcp

> Questo comando è un alias per `cp`.

- Consulta la documentazione del comando originale:

`tldr cp`
