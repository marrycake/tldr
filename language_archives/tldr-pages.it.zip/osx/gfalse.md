# gfalse

> Questo comando è un alias per `false`.

- Consulta la documentazione del comando originale:

`tldr false`
