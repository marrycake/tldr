# gchgrp

> Questo comando è un alias per `chgrp`.

- Consulta la documentazione del comando originale:

`tldr chgrp`
