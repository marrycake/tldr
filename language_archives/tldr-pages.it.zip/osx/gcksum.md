# gcksum

> Questo comando è un alias per `cksum`.

- Consulta la documentazione del comando originale:

`tldr cksum`
