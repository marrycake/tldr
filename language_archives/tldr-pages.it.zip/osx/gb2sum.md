# gb2sum

> Questo comando è un alias per `b2sum`.

- Consulta la documentazione del comando originale:

`tldr b2sum`
