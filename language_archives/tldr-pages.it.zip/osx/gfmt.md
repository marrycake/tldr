# gfmt

> Questo comando è un alias per `fmt`.

- Consulta la documentazione del comando originale:

`tldr fmt`
