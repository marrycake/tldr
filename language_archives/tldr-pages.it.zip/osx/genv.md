# genv

> Questo comando è un alias per `env`.

- Consulta la documentazione del comando originale:

`tldr env`
