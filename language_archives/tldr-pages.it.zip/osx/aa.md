# aa

> Questo comando è un alias per `yaa`.

- Consulta la documentazione del comando originale:

`tldr yaa`
