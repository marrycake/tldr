# ghostid

> Questo comando è un alias per `hostid`.

- Consulta la documentazione del comando originale:

`tldr hostid`
