# ged

> Questo comando è un alias per `ed`.

- Consulta la documentazione del comando originale:

`tldr ed`
