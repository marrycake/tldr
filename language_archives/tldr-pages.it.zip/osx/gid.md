# gid

> Questo comando è un alias per `id`.

- Consulta la documentazione del comando originale:

`tldr id`
