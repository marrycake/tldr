# gchmod

> Questo comando è un alias per `chmod`.

- Consulta la documentazione del comando originale:

`tldr chmod`
