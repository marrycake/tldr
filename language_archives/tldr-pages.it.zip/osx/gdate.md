# gdate

> Questo comando è un alias per `date`.

- Consulta la documentazione del comando originale:

`tldr {{[-p|--platform]}} common date`
