# gfind

> Questo comando è un alias per `find`.

- Consulta la documentazione del comando originale:

`tldr find`
