# gfactor

> Questo comando è un alias per `factor`.

- Consulta la documentazione del comando originale:

`tldr factor`
