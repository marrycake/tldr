# gcat

> Questo comando è un alias per `-p linux cat`.

- Consulta la documentazione del comando originale:

`tldr {{[-p|--platform]}} linux cat`
