# gchown

> Questo comando è un alias per `chown`.

- Consulta la documentazione del comando originale:

`tldr chown`
