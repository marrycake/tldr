# ggroups

> Questo comando è un alias per `groups`.

- Consulta la documentazione del comando originale:

`tldr groups`
