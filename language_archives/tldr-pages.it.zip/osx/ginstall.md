# ginstall

> Questo comando è un alias per `install`.

- Consulta la documentazione del comando originale:

`tldr install`
