# gchroot

> Questo comando è un alias per `chroot`.

- Consulta la documentazione del comando originale:

`tldr chroot`
