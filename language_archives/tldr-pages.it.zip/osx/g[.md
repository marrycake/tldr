# g[

> Questo comando è un alias per `[`.

- Consulta la documentazione del comando originale:

`tldr [`
