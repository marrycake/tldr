# gbasename

> Questo comando è un alias per `basename`.

- Consulta la documentazione del comando originale:

`tldr basename`
