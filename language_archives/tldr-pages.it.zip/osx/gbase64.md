# gbase64

> Questo comando è un alias per `base64`.

- Consulta la documentazione del comando originale:

`tldr {{[-p|--platform]}} common base64`
