# gexpr

> Questo comando è un alias per `expr`.

- Consulta la documentazione del comando originale:

`tldr expr`
