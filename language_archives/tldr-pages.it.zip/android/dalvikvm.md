# dalvikvm

> Macchina virtuale Java per Android.
> Maggiori informazioni: <https://source.android.com/docs/core/runtime>.

- Lancia un programma Java:

`dalvikvm -classpath {{percorso/del/file.jar}} {{nomeclasse}}`
