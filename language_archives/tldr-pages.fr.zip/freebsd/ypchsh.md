# ypchsh

> Cette commande est un alias de `chpass`.

- Affiche la documentation pour la commande d'origine :

`tldr chpass`
