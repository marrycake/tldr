# auditd

> Réponds aux requêtes depuis l'outil d'audition et de notifications du kernel.
> Il ne doit pas être utilisé manuellement.
> Plus d'informations : <https://manned.org/auditd>.

- Démarre le démon :

`auditd`

- Démarre le démon en mode débogage :

`auditd -d`

- Démarre le démon à la demande depuis launchd :

`auditd -l`
