# ptpython3

> Cette commande est un alias de `ptpython`.

- Voir la documentation de la commande originale :

`tldr ptpython`
