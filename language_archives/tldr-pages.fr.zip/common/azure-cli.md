# azure-cli

> Cette commande est un alias de `az`.

- Voir la documentation de la commande originale :

`tldr az`
