# fossil new

> Cette commande est un alias de `fossil init`.

- Voir la documentation de la commande originale :

`tldr fossil init`
