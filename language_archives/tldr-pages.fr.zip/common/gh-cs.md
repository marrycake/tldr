# gh cs

> Cette commande est un alias de `gh codespace`.

- Voir la documentation de la commande originale :

`tldr gh codespace`
