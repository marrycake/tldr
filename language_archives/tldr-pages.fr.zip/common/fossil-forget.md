# fossil forget

> Cette commande est un alias de `fossil rm`.
> Plus d'informations : <https://fossil-scm.org/home/help/forget>.

- Voir la documentation de la commande originale :

`tldr fossil rm`
