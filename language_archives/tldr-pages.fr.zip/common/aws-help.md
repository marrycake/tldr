# aws help

> Affiche l'aide sur la CLI AWS.
> Plus d'informations : <https://docs.aws.amazon.com/cli/latest/userguide/cli-usage-help.html>.

- Affiche l'aide :

`aws help`

- Liste tous les sujets disponibles :

`aws help topics`

- Affiche l'aide à propos d'un sujet particulier :

`aws help {{nom_du_sujet}}`
