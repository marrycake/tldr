# deluged

> Un processus démon pour le client BitTorrent Deluge.
> Plus d'informations : <https://manned.org/deluged>.

- Lance le démon Deluge :

`deluged`

- Lance le démon Deluge sur un port spécifique :

`deluged {{[-p|--port]}} {{port}}`

- Lance le démon Deluge à l'aide d'un fichier de configuration spécifique :

`deluged {{[-c|--config]}} {{chemin/vers/fichier_configuration}}`

- Lance le démon Deluge et enregistre les journaux dans un fichier :

`deluged {{[-l|--logfile]}} {{chemin/vers/fichier_journalisation}}`
