# python3

> Cette commande est un alias de `python`.

- Voir la documentation de la commande originale :

`tldr python`
