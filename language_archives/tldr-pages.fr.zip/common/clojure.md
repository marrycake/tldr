# clojure

> Cette commande est un alias de `clj`.

- Voir la documentation de la commande originale :

`tldr clj`
