# git stage

> Cette commande est un alias de `git add`.

- Voir la documentation de la commande originale :

`tldr git add`
