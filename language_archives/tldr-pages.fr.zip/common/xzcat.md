# xzcat

> Cette commande est un alias de `xz`.

- Voir la documentation de la commande originale :

`tldr xz`
