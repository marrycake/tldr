# platformio

> Cette commande est un alias de `pio`.

- Voir la documentation de la commande originale :

`tldr pio`
