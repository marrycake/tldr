# fossil delete

> Cette commande est un alias de `fossil rm`.

- Voir la documentation de la commande originale :

`tldr fossil rm`
