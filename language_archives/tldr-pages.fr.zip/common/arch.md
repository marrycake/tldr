# arch

> Affiche le nom de l'architecture système.
> Voir aussi `uname`.
> Plus d'informations : <https://www.gnu.org/software/coreutils/manual/html_node/arch-invocation.html>.

- Affiche l'architecture système :

`arch`
