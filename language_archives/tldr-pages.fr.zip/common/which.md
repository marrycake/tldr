# which

> Localise un programme dans le chemin de l'utilisateur.
> Plus d'informations : <https://manned.org/which>.

- Fouille la variable d'environnement « PATH » et affiche l'emplacement des programmes exécutables correspondants à la requête :

`which {{exécutable}}`

- Affiche tous les exécutables correspondants à la requête, s'il y en a plus qu'un :

`which {{[-a|--all]}} {{exécutable}}`
