# vi

> Cette commande est un alias de `vim`.

- Voir la documentation de la commande originale :

`tldr vim`
