# abduco

> Manageur de session dans un terminal.
> Plus d'informations : <https://manned.org/abduco>.

- Affiche les sessions :

`abduco`

- Rejoint une session, la crée si elle n'existe pas :

`abduco -A {{nom}} {{bash}}`

- Rejoint une session avec `dvtm`, la crée si elle n'existe pas :

`abduco -A {{name}}`

- Quitte la session courante :

`<Ctrl \>`

- Rejoint une session en mode lecture seule :

`abduco -Ar {{name}}`
