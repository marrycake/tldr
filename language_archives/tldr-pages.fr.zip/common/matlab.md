# matlab

> Environnement de calcul numérique créé par MathWorks.
> Plus d'informations : <https://se.mathworks.com/help/matlab/matlab_env/startup-options.html>.

- Lance MATLAB sans afficher l'écran de démarrage :

`matlab -nosplash`

- Exécute une instruction MATLAB :

`matlab -r "{{instruction_matlab}}"`

- Exécute un script MATLAB :

`matlab -r "run({{chemin/vers/script.m}})"`
