# amass

> Outil de Cartographie des Attaques de Surface et découverte de ressource.
> Certaines commandes comme `amass intel` ont leur propre documentation.
> Plus d'informations : <https://github.com/owasp-amass/amass>.

- Exécute une sous-commande Amass :

`amass {{intel|enum}} {{options}}`

- Affiche l'aide général :

`amass -help`

- Affiche l'aide sur une sous-commande de Amass :

`amass {{intel|enum}} -help`

- Affiche la version :

`amass -version`
