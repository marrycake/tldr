# adb uninstall

> Désinstalle un paquet d'une instance d'émulateur Android ou d'un appareil Android.
> Plus d'informations : <https://manned.org/adb>.

- Désinstalle un paquet :

`adb uninstall {{com.example.app}}`

- Désinstalle un paquet, mais conserve les données utilisateur :

`adb uninstall -k {{com.example.app}}`
