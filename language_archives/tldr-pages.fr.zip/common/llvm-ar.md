# llvm-ar

> Cette commande est un alias de `ar`.

- Voir la documentation de la commande originale :

`tldr ar`
