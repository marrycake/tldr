# git init

> Initialise un nouveau registre Git.
> Plus d'informations : <https://git-scm.com/docs/git-init>.

- Initialise un nouveau registre Git local :

`git init`

- Initialiser un référentiel barebones, adapté à une utilisation distante via SSH :

`git init --bare`
