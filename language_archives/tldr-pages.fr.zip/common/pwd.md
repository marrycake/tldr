# pwd

> Affiche le nom du répertoire actuel.
> Plus d'informations : <https://www.gnu.org/software/coreutils/manual/html_node/pwd-invocation.html>.

- Affiche le répertoire actuel :

`pwd`

- Affiche le répertoire actuel tout en traduisant les liens symboliques (c.-à-d. afficher le répertoire « physique ») :

`pwd {{[-P|--physical]}}`
