# adb devices

> Liste des appareils Android connectés.
> Plus d'informations : <https://manned.org/adb>.

- Liste les appareils :

`adb devices`

- Liste les appareils et leurs informations système :

`adb devices -l`
