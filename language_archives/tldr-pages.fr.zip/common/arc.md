# arc

> Arcanist: Une CLI pour Phabricator.
> Plus d'informations : <https://secure.phabricator.com/book/phabricator/article/arcanist/>.

- Envoie les changements à un différentiel pour relecture :

`arc diff`

- Affiche les informations de la révision en suspens :

`arc list`

- Mets à jour les messages de commit Git après relecture :

`arc amend`

- Pousse les changements Git :

`arc land`
