# a2dismod

> Désactive un module Apache sur une distribution Debian.
> Plus d'informations : <https://manned.org/a2dismod.8>.

- Désactive un module :

`sudo a2dismod {{module}}`

- N'affiche aucun message (mode silencieux) :

`sudo a2dismod --quiet {{module}}`
