# ip route show

> Cette commande est un alias de `ip route list`.

- Voir la documentation de la commande originale :

`tldr ip route list`
