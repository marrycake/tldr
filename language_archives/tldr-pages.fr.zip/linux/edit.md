# edit

> Un alias à l'action de modification de `run-mailcap`.
> Originellement, `run-mailcap` est utilisé afin de modifier des fichiers mime-type.
> Plus d'informations : <https://www.computerhope.com/unix/uedit.htm>.

- L'action de modification peut être utilisée pour voir n'importe quel fichier dans l'explorateur mailcap par défaut :

`edit {{fichier}}`

- Avec `run-mailcap` :

`run-mailcap --action=edit {{fichier}}`
