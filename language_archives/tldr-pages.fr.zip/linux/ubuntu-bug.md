# ubuntu-bug

> Cette commande est un alias de `apport-bug`.

- Voir la documentation de la commande originale :

`tldr apport-bug`
