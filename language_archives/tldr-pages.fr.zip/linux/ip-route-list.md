# ip route list

> Cette commande est un alias de `ip route show`.

- Voir la documentation de la commande originale :

`tldr ip route show`
