# alternatives

> Cette commande est un alias de `update-alternatives`.

- Voir la documentation de la commande originale :

`tldr update-alternatives`
