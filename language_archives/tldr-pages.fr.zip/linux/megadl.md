# megadl

> Cette commande est un alias de `megatools-dl`.

- Voir la documentation de la commande originale :

`tldr megatools-dl`
