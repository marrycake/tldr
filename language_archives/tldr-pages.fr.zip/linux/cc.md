# cc

> Cette commande est un alias de `gcc`.

- Voir la documentation de la commande originale :

`tldr gcc`
