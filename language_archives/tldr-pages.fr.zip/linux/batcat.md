# batcat

> Cette commande est un alias de `bat`.

- Voir la documentation de la commande originale :

`tldr bat`
