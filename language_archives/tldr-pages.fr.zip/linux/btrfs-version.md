# btrfs version

> Afficher les informations de version des outils btrfs, et accéder aux pages d'aide.
> Plus d'informations : <https://btrfs.readthedocs.io/en/latest/btrfs.html>.

- Afficher l'aide :

`btrfs version --help`

- Afficher les informations de version des outils btrfs :

`btrfs version`
