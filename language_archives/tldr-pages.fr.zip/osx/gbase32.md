# gbase32

> Cette commande est un alias de `base32`.

- Voir la documentation de la commande originale :

`tldr base32`
