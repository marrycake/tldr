# gbasename

> Cette commande est un alias de `basename`.

- Voir la documentation de la commande originale :

`tldr basename`
