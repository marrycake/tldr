# gchmod

> Cette commande est un alias de `chmod`.

- Voir la documentation de la commande originale :

`tldr chmod`
