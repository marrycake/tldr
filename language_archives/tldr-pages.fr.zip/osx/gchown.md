# gchown

> Cette commande est un alias de `chown`.

- Voir la documentation de la commande originale :

`tldr chown`
