# gchgrp

> Cette commande est un alias de `chgrp`.

- Voir la documentation de la commande originale :

`tldr chgrp`
