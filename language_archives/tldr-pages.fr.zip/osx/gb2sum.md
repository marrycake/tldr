# gb2sum

> Cette commande est un alias de `b2sum`.

- Voir la documentation de la commande originale :

`tldr b2sum`
