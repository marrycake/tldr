# gchroot

> Cette commande est un alias de `chroot`.

- Voir la documentation de la commande originale :

`tldr chroot`
