# gbasenc

> Cette commande est un alias de `basenc`.

- Voir la documentation de la commande originale :

`tldr basenc`
