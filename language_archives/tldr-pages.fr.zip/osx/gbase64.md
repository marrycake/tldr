# gbase64

> Cette commande est un alias de `base64`.

- Voir la documentation de la commande originale :

`tldr {{[-p|--platform]}} common base64`
