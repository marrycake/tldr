# wm

> Affiche les informations de l'écran d'un appareil Android.
> Cette commande peut être utilisée uniquement depuis `adb shell`.
> Plus d'informations: <https://web.archive.org/web/20240420064706/https://adbinstaller.com/commands/adb-shell-wm-5b672b17e7958178a2955538>.

- Affiche la taille physique de l'écran d'un appareil Android :

`wm size`

- Affiche la densité physique de l'écran d'un appareil Android :

`wm density`
