# fossil delete

> Denne kommando er et alias af `fossil rm`.

- Se dokumentation for den oprindelige kommando:

`tldr fossil rm`
