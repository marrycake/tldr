# pio init

> هذا الأمر هو اسم مستعار لـ `pio project`.

- إعرض التوثيقات للأمر الأصلي:

`tldr pio project`
