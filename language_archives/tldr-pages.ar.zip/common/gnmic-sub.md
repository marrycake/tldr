# gnmic sub

> هذا الأمر هو اسم مستعار لـ `gnmic subscribe`.

- إعرض التوثيقات للأمر الأصلي:

`tldr gnmic subscribe`
