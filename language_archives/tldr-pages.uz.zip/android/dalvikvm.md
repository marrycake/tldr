# dalvikvm

> Android Java virtual mashinasi.
> Ko'proq malumot: <https://source.android.com/docs/core/runtime>.

- Java dasturini ishga tushirish:

`dalvikvm -classpath {{fayl/uchun/yo_l.jar}} {{klassnomi}}`
