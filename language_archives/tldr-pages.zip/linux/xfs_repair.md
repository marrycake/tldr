# xfs_repair

> Repair an XFS filesystem.
> More information: <https://manned.org/xfs_repair>.

- Repair a partition:

`sudo xfs_repair {{path/to/partition}}`
