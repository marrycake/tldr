# deleted

> Keeps track of purgeable space and asks clients to purge when space is low.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/deleted.8.html>.

- Start the daemon:

`deleted`
