# gindent

> This command is an alias of GNU `indent`.

- View documentation for the original command:

`tldr -p linux indent`
