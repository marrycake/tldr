# usernoted

> Provides notification services.
> It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/usernoted.8.html>.

- Start the daemon:

`usernoted`
