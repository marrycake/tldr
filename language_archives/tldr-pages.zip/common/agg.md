# agg

> Create a GIF from an `asciinema` terminal session recording.
> More information: <https://docs.asciinema.org/manual/agg/usage/>.

- Create a GIF:

`agg {{path/to/demo.cast}} {{path/to/demo.gif}}`
