# adb pair

> This command has been moved to `adb connect`.

- View documentation for `adb pair`:

`tldr adb connect`
