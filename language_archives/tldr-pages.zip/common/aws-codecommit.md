# aws codecommit

> A managed source control service that hosts private Git repositories.
> More information: <https://docs.aws.amazon.com/cli/latest/reference/codecommit/>.

- Display help:

`aws codecommit help`

- Display help for a specific command:

`aws codecommit {{command}} help`
