# bundler

> Dependency manager for the Ruby programming language.
> `bundler` is a common name for the command `bundle`, but not a command itself.
> More information: <https://bundler.io/man/bundle.1.html>.

- View documentation for the original command:

`tldr bundle`
