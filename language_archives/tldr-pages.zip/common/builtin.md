# builtin

> Execute shell builtins.
> More information: <https://manned.org/builtin.1>.

- Run a shell builtin:

`builtin {{command}}`
