# Colon

> Returns a successful exit status code of 0.
> More information: <https://pubs.opengroup.org/onlinepubs/9699919799/utilities/V3_chap02.html#colon>.

- Return a successful exit code:

`:`

- Make a command always exit with 0:

`{{command}} || :`
