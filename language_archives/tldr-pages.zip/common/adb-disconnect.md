# adb disconnect

> This command has been moved to `adb connect`.

- View documentation for `adb disconnect`:

`tldr adb connect`
