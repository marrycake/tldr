# audit2why

> This command is an alias of `audit2allow --why`.

- View documentation for the original command:

`tldr audit2allow`
