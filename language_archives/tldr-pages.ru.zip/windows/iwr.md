# iwr

> Эта команда — псевдоним для `invoke-webrequest`.

- Смотри документацию для оригинальной команды:

`tldr invoke-webrequest`
