# mkdir

> Создает каталог или подкаталог в файловой системе.
> Больше информации: <https://learn.microsoft.com/windows-server/administration/windows-commands/mkdir>.

- Создать новый каталог:

`mkdir {{путь\до\папки}}`

- Чтобы создать дерево каталогов в корневом каталоге введите:

`mkdir {{путь\до\под_папки}}`
