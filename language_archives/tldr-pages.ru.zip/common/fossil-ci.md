# fossil ci

> Эта команда — псевдоним для `fossil commit`.

- Смотри документацию для оригинальной команды:

`tldr fossil commit`
