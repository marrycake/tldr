# fossil new

> Эта команда — псевдоним для `fossil init`.

- Смотри документацию для оригинальной команды:

`tldr fossil init`
