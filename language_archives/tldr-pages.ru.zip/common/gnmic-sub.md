# gnmic sub

> Эта команда — псевдоним для `gnmic subscribe`.

- Смотри документацию для оригинальной команды:

`tldr gnmic subscribe`
