# tty

> Выводит название терминала.
> Больше информации: <https://www.gnu.org/software/coreutils/manual/html_node/tty-invocation.html>.

- Вывести имя файла, соответствующее текущему терминалу:

`tty`
