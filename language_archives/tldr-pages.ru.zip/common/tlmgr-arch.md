# tlmgr arch

> Эта команда — псевдоним для `tlmgr platform`.

- Смотри документацию для оригинальной команды:

`tldr tlmgr platform`
