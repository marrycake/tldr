# ip route list

> Эта команда — псевдоним для `ip route show`.

- Смотри документацию для оригинальной команды:

`tldr ip route show`
