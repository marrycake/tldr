# bugreport

> Показать отчет об ошибках Android.
> Эту команду можно использовать только через `adb shell`.
> Больше информации: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- Показать полный отчет об ошибках на устройстве Android:

`bugreport`
