# ypchpass

> यह कमांड `chpass` का उपनाम है।

- मूल कमांड के लिए दस्तावेज़ देखें:

`tldr chpass`
