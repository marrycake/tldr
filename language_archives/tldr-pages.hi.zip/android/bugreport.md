# bugreport

> एंड्रॉयड बग रिपोर्ट दिखाएँ।
> इस कमांड का उपयोग केवल `adb shell` के माध्यम से किया जा सकता है।
> अधिक जानकारी: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>।

- एंड्रॉयड डिवाइस की संपूर्ण बग रिपोर्ट प्रदर्शित करें:

`bugreport`
