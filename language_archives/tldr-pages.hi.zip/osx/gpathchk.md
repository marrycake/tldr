# gpathchk

> यह आदेश `pathchk` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr pathchk`
