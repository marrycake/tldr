# gbase64

> यह आदेश `base64` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr {{[-p|--platform]}} common base64`
