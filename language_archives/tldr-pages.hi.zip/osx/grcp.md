# grcp

> यह आदेश `-p linux rcp` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr {{[-p|--platform]}} linux rcp`
