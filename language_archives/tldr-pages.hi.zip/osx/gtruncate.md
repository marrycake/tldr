# gtruncate

> यह आदेश `truncate` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr truncate`
