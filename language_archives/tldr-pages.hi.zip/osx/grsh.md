# grsh

> यह आदेश `-p linux rsh` का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr {{[-p|--platform]}} linux rsh`
