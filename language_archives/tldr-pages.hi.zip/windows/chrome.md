# chrome

> यह आदेश `chromium` का उपनाम है।
> अधिक जानकारी: <https://chrome.google.com>।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr chromium`
