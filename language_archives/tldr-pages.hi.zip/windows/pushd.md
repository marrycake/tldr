# pushd

> एक निर्देशिका को एक स्टैक पर रखें ताकि इसे बाद में एक्सेस किया जा सके।
> मूल निर्देशिका पर वापस जाने के लिए `popd` भी देखें।
> अधिक जानकारी: <https://learn.microsoft.com/windows-server/administration/windows-commands/pushd>।

- निर्देशिका पर स्विच करें और इसे स्टैक पर डालें:

`pushd {{निर्देशिका\का\पथ}}`
