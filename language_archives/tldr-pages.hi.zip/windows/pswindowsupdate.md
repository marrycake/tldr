# PSWindowsUpdate

> Windows Update प्रबंधित करने के लिए एक PowerShell बाहरी मॉड्यूल।
> यह उपकरण कई कमांड प्रदान करता है जिन्हें केवल PowerShell के माध्यम से चलाया जा सकता है।
> अधिक जानकारी: <https://github.com/mgajda83/PSWindowsUpdate>।

- मॉड्यूल को `Install-Module` का उपयोग करके स्थापित करें:

`Install-Module PSWindowsUpdate`

- मॉड्यूल के अंतर्गत सभी उपलब्ध कमांडों की सूची बनाएं:

`Get-Command -Module PSWindowsUpdate`
