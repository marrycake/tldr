# choco feature

> चॉकलेट के साथ विशेषताओं के साथ इंटरैक्ट करें।
> अधिक जानकारी: <https://chocolatey.org/docs/commands-feature>।

- उपलब्ध विशेषताओं की सूची दिखाएँ:

`choco feature list`

- एक विशेषता सक्षम करें:

`choco feature enable --name {{नाम}}`

- एक विशेषता अक्षम करें:

`choco feature disable --name {{नाम}}`
