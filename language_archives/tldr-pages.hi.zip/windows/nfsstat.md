# nfsstat

> NFS सर्वर पर की गई कॉल की संख्या को प्रदर्शित करें या रीसेट करें।
> अधिक जानकारी: <https://learn.microsoft.com/windows-server/administration/windows-commands/nfsstat>।

- NFS सर्वर पर की गई कॉल की रिकॉर्ड की गई संख्या को प्रदर्शित करें:

`nfsstat`

- NFS सर्वर पर की गई कॉल की रिकॉर्ड की गई संख्या को रीसेट करें:

`nfsstat -z`
