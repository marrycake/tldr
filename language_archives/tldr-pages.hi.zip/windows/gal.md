# gal

> PowerShell में, यह कमांड `Get-Alias` का उपनाम है।

- मूल कमांड के लिए प्रलेखन देखें:

`tldr get-alias`
