# mv

> PowerShell में, यह कमांड `Move-Item` का उपनाम है।
> हालाँकि, यह कमांड Command Prompt (`cmd`) पर उपलब्ध नहीं है। समान कार्यक्षमता के लिए इसके बजाय `move` का उपयोग करें।

- समान Command Prompt कमांड के लिए दस्तावेज़ देखें:

`tldr move`

- मूल PowerShell कमांड के लिए दस्तावेज़ देखें:

`tldr move-item`
