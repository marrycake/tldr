# gl

> PowerShell में, यह कमांड `Get-Location` का उपनाम है।

- मूल कमांड के लिए दस्तावेज़ देखें:

`tldr get-location`
