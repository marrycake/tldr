# fossil new

> यह आदेश `fossil init`.का उपनाम है।

- मूल आदेश के लिए दस्तावेज़ देखें:

`tldr fossil init`
