# time

> देखें कि एक कमांड में कितना समय लगता है।
> अधिक जानकारी: <https://manned.org/time>।

- समय `command`:

`time {{command}}`
