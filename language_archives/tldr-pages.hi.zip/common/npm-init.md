# npm init

> एक `package.json` फ़ाइल बनाएँ।
> अधिक जानकारी: <https://docs.npmjs.com/cli/commands/npm-init>।

- संकेतों के साथ एक नया पैकेज प्रारंभ करें:

`npm init`

- डिफ़ॉल्ट मानों के साथ एक नया पैकेज प्रारंभ करें:

`npm init {{[-y|--yes]}}`

- एक विशिष्ट इनिशियलाइज़र का उपयोग करके एक नया पैकेज प्रारंभ करें:

`npm init {{create-react-app}} {{my-app}}`
