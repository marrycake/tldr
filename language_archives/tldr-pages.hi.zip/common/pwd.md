# pwd

> वर्तमान/कार्यशील निर्देशिका का नाम देखें।
> अधिक जानकारी: <https://www.gnu.org/software/coreutils/manual/html_node/pwd-invocation.html>।

- वर्तमान निर्देशिका का नाम देखें:

`pwd`

- वर्तमान निर्देशिका का नाम देखें और सभी सिम्लिंक को हल करें (यानी "भौतिक" पथ दिखाएं):

`pwd {{[-P|--physical]}}`
