# ruget

> Rust में लिखे गए wget का विकल्प।
> अधिक जानकारी: <https://github.com/ksk001100/ruget>।

- किसी फ़ाइल में URL की सामग्री डाउनलोड करें:

`ruget {{https://example.com/file}}`

- किसी निर्दिष्ट आउटपुट फ़ाइल में URL की सामग्री डाउनलोड करें:

`ruget --output {{file_name}} {{https://example.com/file}}`
