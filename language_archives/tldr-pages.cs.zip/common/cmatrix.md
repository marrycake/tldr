# cmatrix

> Zobrazuje v terminálu obrazovku podobnou Matrixu.
> Více informací: <https://github.com/abishekvashok/cmatrix>.

- Povolit [a]synchroní posouvání:

`cmatrix -a`

- Změnit barvu textu (výchozí je zelená):

`cmatrix -C {{red}}`

- Povolit duhový režim:

`cmatrix -r`

- Použít zpoždění akt[u]alizace 100 centisekund (1 sekunda):

`cmatrix -u 100`
