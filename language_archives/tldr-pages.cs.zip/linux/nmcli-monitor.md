# nmcli monitor

> Monitoruje změny stavu připojení NetworkManageru.
> Tento dílčí příkaz může být zvolán také pomocí `nmcli m`.
> Více informací: <https://networkmanager.pages.freedesktop.org/NetworkManager/NetworkManager/nmcli.html>.

- Spustit monitorování změn NetworkManageru:

`nmcli {{[m|monitor]}}`
