# gexpand

> 這是 `expand` 命令的一個別名。

- 原命令的文件在：

`tldr expand`
