# gsha256sum

> 這是 `sha256sum` 命令的一個別名。

- 原命令的文件在：

`tldr sha256sum`
