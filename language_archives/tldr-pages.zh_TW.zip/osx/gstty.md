# gstty

> 這是 `stty` 命令的一個別名。

- 原命令的文件在：

`tldr stty`
