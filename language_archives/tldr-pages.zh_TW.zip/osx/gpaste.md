# gpaste

> 這是 `paste` 命令的一個別名。

- 原命令的文件在：

`tldr paste`
