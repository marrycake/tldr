# gpwd

> 這是 `pwd` 命令的一個別名。

- 原命令的文件在：

`tldr pwd`
