# gsha384sum

> 這是 `sha384sum` 命令的一個別名。

- 原命令的文件在：

`tldr sha384sum`
