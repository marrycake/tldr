# gtraceroute

> 這是 `traceroute` 命令的一個別名。

- 原命令的文件在：

`tldr traceroute`
