# gchgrp

> 這是 `chgrp` 命令的一個別名。

- 原命令的文件在：

`tldr chgrp`
