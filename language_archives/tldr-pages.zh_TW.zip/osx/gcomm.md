# gcomm

> 這是 `comm` 命令的一個別名。

- 原命令的文件在：

`tldr comm`
