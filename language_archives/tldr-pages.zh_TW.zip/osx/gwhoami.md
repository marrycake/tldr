# gwhoami

> 這是 `whoami` 命令的一個別名。

- 原命令的文件在：

`tldr whoami`
