# gfind

> 這是 `find` 命令的一個別名。

- 原命令的文件在：

`tldr find`
