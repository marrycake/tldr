# gtouch

> 這是 `touch` 命令的一個別名。

- 原命令的文件在：

`tldr touch`
