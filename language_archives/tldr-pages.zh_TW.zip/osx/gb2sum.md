# gb2sum

> 這是 `b2sum` 命令的一個別名。

- 原命令的文件在：

`tldr b2sum`
