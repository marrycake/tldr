# gchmod

> 這是 `chmod` 命令的一個別名。

- 原命令的文件在：

`tldr chmod`
