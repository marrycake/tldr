# gsum

> 這是 `sum` 命令的一個別名。

- 原命令的文件在：

`tldr sum`
