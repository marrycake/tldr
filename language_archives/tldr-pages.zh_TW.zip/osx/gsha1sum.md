# gsha1sum

> 這是 `sha1sum` 命令的一個別名。

- 原命令的文件在：

`tldr sha1sum`
