# gtelnet

> 這是 `telnet` 命令的一個別名。

- 原命令的文件在：

`tldr telnet`
