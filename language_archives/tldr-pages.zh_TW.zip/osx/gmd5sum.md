# gmd5sum

> 這是 `md5sum` 命令的一個別名。

- 原命令的文件在：

`tldr md5sum`
