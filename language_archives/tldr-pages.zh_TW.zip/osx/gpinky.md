# gpinky

> 這是 `pinky` 命令的一個別名。

- 原命令的文件在：

`tldr pinky`
