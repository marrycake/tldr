# gprintenv

> 這是 `printenv` 命令的一個別名。

- 原命令的文件在：

`tldr printenv`
