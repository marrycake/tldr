# gping6

> 這是 `ping6` 命令的一個別名。

- 原命令的文件在：

`tldr ping6`
