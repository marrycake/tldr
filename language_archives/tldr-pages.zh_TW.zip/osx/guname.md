# guname

> 這是 `uname` 命令的一個別名。

- 原命令的文件在：

`tldr {{[-p|--platform]}} common uname`
