# gcut

> 這是 `cut` 命令的一個別名。

- 原命令的文件在：

`tldr {{[-p|--platform]}} common cut`
