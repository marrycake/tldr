# gjoin

> 這是 `join` 命令的一個別名。

- 原命令的文件在：

`tldr join`
