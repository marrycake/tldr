# gdirname

> 這是 `dirname` 命令的一個別名。

- 原命令的文件在：

`tldr dirname`
