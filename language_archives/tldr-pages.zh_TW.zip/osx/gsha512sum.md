# gsha512sum

> 這是 `sha512sum` 命令的一個別名。

- 原命令的文件在：

`tldr sha512sum`
