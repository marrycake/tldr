# gshuf

> 這是 `shuf` 命令的一個別名。

- 原命令的文件在：

`tldr {{[-p|--platform]}} coomon shuf`
