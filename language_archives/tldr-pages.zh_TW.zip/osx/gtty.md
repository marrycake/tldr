# gtty

> 這是 `tty` 命令的一個別名。

- 原命令的文件在：

`tldr tty`
