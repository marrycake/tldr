# gftp

> 這是 `ftp` 命令的一個別名。

- 原命令的文件在：

`tldr ftp`
