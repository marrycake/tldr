# gmake

> 這是 `make` 命令的一個別名。

- 原命令的文件在：

`tldr make`
