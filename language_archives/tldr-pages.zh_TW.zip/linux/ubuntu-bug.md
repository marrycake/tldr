# ubuntu-bug

> 這是 `apport-bug` 命令的一個別名。

- 原命令的文件在：

`tldr apport-bug`
