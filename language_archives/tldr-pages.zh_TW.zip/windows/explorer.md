# explorer

> Windows 檔案總管。
> 更多資訊：<https://ss64.com/nt/explorer.html>.

- 打開 Windows 檔案總管：

`explorer`

- 在當前目錄打開 Windows 檔案總管：

`explorer .`

- 在指定目錄打開 Windows 檔案總管：

`explorer {{目錄/完整/路徑}}`
