# title

> 設定命令提示字元視窗的標題。
> 更多資訊：<https://learn.microsoft.com/windows-server/administration/windows-commands/title>.

- 設定當前命令提示字元的視窗標題：

`title {{新標題}}`
