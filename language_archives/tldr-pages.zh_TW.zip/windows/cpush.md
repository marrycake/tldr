# cpush

> 這是 `choco push` 命令的一個別名。

- 原命令的文件在：

`tldr choco push`
