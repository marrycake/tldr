# mkdir

> 建立一個資料夾。
> 更多資訊：<https://learn.microsoft.com/windows-server/administration/windows-commands/mkdir>.

- 建立一個資料夾：

`mkdir {{資料夾名稱}}`

- 遞迴建立資料夾及子資料夾：

`mkdir {{資料夾/子資料夾名稱}}`
