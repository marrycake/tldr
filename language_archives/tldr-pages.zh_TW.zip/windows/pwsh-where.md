# pwsh where

> 這是 `Where-Object` 命令的一個別名。

- 原命令的文件在：

`tldr Where-Object`
