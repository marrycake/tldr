# sls

> 這是 `Select-String` 命令的一個別名。

- 原命令的文件在：

`tldr select-string`
