# tldrl

> 這是 `tldr-lint` 命令的一個別名。

- 原命令的文件在：

`tldr tldr-lint`
