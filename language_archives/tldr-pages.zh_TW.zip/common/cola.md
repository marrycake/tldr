# cola

> 這是 `git-cola` 命令的一個別名。

- 原命令的文件在：

`tldr git-cola`
