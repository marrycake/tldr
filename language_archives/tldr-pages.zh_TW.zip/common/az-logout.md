# az logout

> 登出 Azure 訂閱。
> `azure-cli` 的一部分（也稱為 `az`）。
> 更多資訊：<https://learn.microsoft.com/cli/azure/reference-index#az-logout>.

- 登出當前帳號：

`az logout`

- 登出指定使用者：

`az logout --username {{alias@somedomain.com}}`
