# cuyo

> Tetris-ähnliches Spiel.
> Weitere Informationen: <https://www.karimmi.de/cuyo/>.

- Starte ein neues Spiel:

`cuyo`

- Verschiebe die Teile horizontal:

`{{<a>|<d>|<ArrowLeft>|<ArrowRight>}}`

- Drehe die Teile:

`{{<w>|<ArrowUp>}}`

- Lasse die Teile schnell fallen:

`{{<s>|<ArrowDown>}}`
