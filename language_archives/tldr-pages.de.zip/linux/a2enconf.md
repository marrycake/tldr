# a2enconf

> Aktiviert eine Apache-Konfigurationsdatei auf Debian-basierten Betriebssystemen.
> Weitere Informationen: <https://manned.org/a2enconf.8>.

- Aktiviere eine Konfigurationsdatei:

`sudo a2enconf {{konfigurationsdatei}}`

- Zeige keine Informationsnachrichten an:

`sudo a2enconf --quiet {{konfigurationsdatei}}`
