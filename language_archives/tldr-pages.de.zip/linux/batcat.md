# batcat

> Dieser Befehl ist ein Alias von `bat`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr bat`
