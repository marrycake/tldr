# line

> Liest eine einzelne Eingabezeile.
> Weitere Informationen: <https://manned.org/line.1>.

- Lies eine Eingabezeile:

`line`
