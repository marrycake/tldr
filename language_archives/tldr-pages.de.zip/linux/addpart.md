# addpart

> Informiert den Linux-Kernel über die Existenz der angegebenen Partition.
> Dieser Befehl ist ein einfacher Wrapper um den `add partition` ioctl.
> Weitere Informationen: <https://manned.org/addpart>.

- Informiere den Kernel über die Existenz der angegebenen Partition:

`addpart {{gerät}} {{partition}} {{start}} {{länge}}`
