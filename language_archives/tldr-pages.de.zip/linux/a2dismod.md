# a2dismod

> Deaktiviert ein Apache-Modul auf Debian-basierten Betriebssystemen.
> Weitere Informationen: <https://manned.org/a2dismod.8>.

- Deaktiviere ein Modul:

`sudo a2dismod {{modul}}`

- Zeige keine Informationsnachrichten an:

`sudo a2dismod --quiet {{modul}}`
