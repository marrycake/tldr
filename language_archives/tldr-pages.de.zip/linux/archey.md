# archey

> Simples Tool um System-Informationen stylisch zu präsentieren.
> Weitere Informationen: <https://lclarkmichalek.github.io/archey3/>.

- Zeige System-Informationen:

`archey`
