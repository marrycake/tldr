# megadl

> Dieser Befehl ist ein Alias von `megatools-dl`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr megatools-dl`
