# ubuntu-bug

> Dieser Befehl ist ein Alias von `apport-bug`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr apport-bug`
