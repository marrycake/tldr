# archinstall

> Geführte Arch Linux-Installation.
> Weitere Informationen: <https://archinstall.readthedocs.io>.

- Starte den interaktiven Installer:

`archinstall`

- Starte einen voreingestellten Installer:

`archinstall {{minimal|unattended}}`
