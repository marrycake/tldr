# alternatives

> Dieser Befehl ist ein Alias von `update-alternatives`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr update-alternatives`
