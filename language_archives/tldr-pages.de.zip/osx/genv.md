# genv

> Dieser Befehl ist ein Alias von `env`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr env`
