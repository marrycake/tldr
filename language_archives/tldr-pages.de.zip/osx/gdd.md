# gdd

> Dieser Befehl ist ein Alias von GNU `dd`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr {{[-p|--platform]}} linux dd`
