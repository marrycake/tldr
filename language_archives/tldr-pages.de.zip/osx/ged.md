# ged

> Dieser Befehl ist ein Alias von `ed`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr ed`
