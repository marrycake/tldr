# gegrep

> Dieser Befehl ist ein Alias von `egrep`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr egrep`
