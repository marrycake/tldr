# gfold

> Dieser Befehl ist ein Alias von GNU `fold`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr {{[-p|--platform]}} linux fold`
