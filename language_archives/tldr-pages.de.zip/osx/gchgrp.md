# gchgrp

> Dieser Befehl ist ein Alias von `chgrp`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr chgrp`
