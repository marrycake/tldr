# gdircolors

> Dieser Befehl ist ein Alias von `dircolors`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr dircolors`
