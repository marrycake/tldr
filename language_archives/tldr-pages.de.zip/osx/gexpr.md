# gexpr

> Dieser Befehl ist ein Alias von `expr`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr expr`
