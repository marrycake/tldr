# gcsplit

> Dieser Befehl ist ein Alias von GNU `csplit`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr {{[-p|--platform]}} linux csplit`
