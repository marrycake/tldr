# gcut

> Dieser Befehl ist ein Alias von `cut`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr {{[-p|--platform]}} common cut`
