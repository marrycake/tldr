# gbase32

> Dieser Befehl ist ein Alias von `base32`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr base32`
