# gdate

> Dieser Befehl ist ein Alias von `date`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr {{[-p|--platform]}} common date`
