# gfmt

> Dieser Befehl ist ein Alias von `fmt`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr fmt`
