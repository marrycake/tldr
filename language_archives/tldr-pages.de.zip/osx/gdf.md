# gdf

> Dieser Befehl ist ein Alias von GNU `df`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr {{[-p|--platform]}} linux df`
