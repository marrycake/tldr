# gecho

> Dieser Befehl ist ein Alias von `echo`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr echo`
