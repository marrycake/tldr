# gcat

> Dieser Befehl ist ein Alias von GNU `cat`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr {{[-p|--platform]}} linux cat`
