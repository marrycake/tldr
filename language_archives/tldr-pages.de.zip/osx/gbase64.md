# gbase64

> Dieser Befehl ist ein Alias von `base64`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr {{[-p|--platform]}} common base64`
