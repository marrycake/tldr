# gfgrep

> Dieser Befehl ist ein Alias von `fgrep`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr fgrep`
