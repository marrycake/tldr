# gcp

> Dieser Befehl ist ein Alias von `cp`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr cp`
