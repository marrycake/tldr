# gfalse

> Dieser Befehl ist ein Alias von `false`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr false`
