# gchroot

> Dieser Befehl ist ein Alias von `chroot`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr chroot`
