# gexpand

> Dieser Befehl ist ein Alias von `expand`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr expand`
