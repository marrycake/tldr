# gb2sum

> Dieser Befehl ist ein Alias von `b2sum`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr b2sum`
