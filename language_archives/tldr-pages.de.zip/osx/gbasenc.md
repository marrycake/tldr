# gbasenc

> Dieser Befehl ist ein Alias von `basenc`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr basenc`
