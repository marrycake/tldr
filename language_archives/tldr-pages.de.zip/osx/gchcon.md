# gchcon

> Dieser Befehl ist ein Alias von GNU `chcon`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr {{[-p|--platform]}} linux chcon`
