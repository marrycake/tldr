# gcksum

> Dieser Befehl ist ein Alias von `cksum`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr cksum`
