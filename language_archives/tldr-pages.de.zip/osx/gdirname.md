# gdirname

> Dieser Befehl ist ein Alias von `dirname`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr dirname`
