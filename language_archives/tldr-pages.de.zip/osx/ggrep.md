# ggrep

> Dieser Befehl ist ein Alias von `grep`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr grep`
