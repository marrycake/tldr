# gchown

> Dieser Befehl ist ein Alias von `chown`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr chown`
