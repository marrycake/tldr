# gcomm

> Dieser Befehl ist ein Alias von `comm`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr comm`
