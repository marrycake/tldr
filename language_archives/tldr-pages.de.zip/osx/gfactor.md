# gfactor

> Dieser Befehl ist ein Alias von `factor`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr factor`
