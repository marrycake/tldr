# gdir

> Dieser Befehl ist ein Alias von GNU `dir`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr {{[-p|--platform]}} linux dir`
