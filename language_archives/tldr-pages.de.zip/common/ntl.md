# ntl

> Dieser Befehl ist ein Alias von `netlify`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr netlify`
