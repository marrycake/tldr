# google-chrome

> Dieser Befehl ist ein Alias von `chromium`.
> Weitere Informationen: <https://chrome.google.com>.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr chromium`
