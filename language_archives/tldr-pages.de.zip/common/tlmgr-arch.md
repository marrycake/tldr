# tlmgr arch

> Dieser Befehl ist ein Alias von `tlmgr platform`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr tlmgr platform`
