# sc_analysis_dump

> Ausgabe von Traceroute-Pfaden in einem leicht zu parsenden Format.
> Weitere Informationen: <https://www.caida.org/catalog/software/scamper/>.

- Gib die traceroute in `warts`-Dateien nacheinander in einem leicht zu parsendem Format aus:

`sc_analysis_dump {{path/to/file1.warts path/to/file2.warts ...}}`
