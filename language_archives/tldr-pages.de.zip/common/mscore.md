# mscore

> Dieser Befehl ist ein Alias von `musescore`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr musescore`
