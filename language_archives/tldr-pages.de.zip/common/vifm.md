# vifm

> Vifm (VI File Manager) ist ein Kommandozeilen-Dateimanager.
> Weitere Informationen: <https://github.com/vifm/vifm>.

- Öffne das aktuelle Verzeichnis:

`vifm .`

- Öffne angegebene Verzeichnisse auf der linken oder rechten Seite:

`vifm {{pfad/zu/verzeichnis1 pfad/zu/verzeichnis2 ...}}`
