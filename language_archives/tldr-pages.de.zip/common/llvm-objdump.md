# llvm-objdump

> Dieser Befehl ist ein Alias von `objdump`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr objdump`
