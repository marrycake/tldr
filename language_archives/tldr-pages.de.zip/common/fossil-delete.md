# fossil delete

> Dieser Befehl ist ein Alias von `fossil rm`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr fossil rm`
