# unclutter

> Versteckt den Mauszeiger.
> Weitere Informationen: <https://manned.org/unclutter.1x>.

- Verstecke den Mauszeiger nach 3 Sekunden:

`unclutter -idle {{3}}`
