# meshnamed

> Verteiltes Namensystem für IPv6 Mesh-Netzwerke.
> Weitere Informationen: <https://github.com/zhoreeq/meshname/>.

- Starte einen lokalen meshname DNS-Server:

`meshnamed`

- Wandle eine IPv6-Adresse in einen meshname um:

`meshnamed -getname {{200:6fc8:9220:f400:5cc2:305a:4ac6:967e}}`

- Wandle einen meshname in eine IPv6-Adresse um:

`meshnamed -getip {{aiag7sesed2aaxgcgbnevruwpy}}`
