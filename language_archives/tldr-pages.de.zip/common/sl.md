# sl

> Dampflokomotive welche durch das Terminal fährt.
> Weitere Informationen: <https://github.com/mtoyoda/sl>.

- Lasse eine Dampflokomotive durch dein Terminal fahren:

`sl`

- Der Zug brennt, Menschen schreien:

`sl -a`

- Lasse den Zug fliegen:

`sl -F`

- Zeige den Zug kleiner an:

`sl -l`

- Lasse den Benutzer abbrechen (`<Ctrl c>`):

`sl -e`
