# kafkacat

> Dieser Befehl ist ein Alias von `kcat`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr kcat`
