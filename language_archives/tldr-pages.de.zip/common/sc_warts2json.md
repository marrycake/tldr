# sc_warts2json

> Wandelt eine WARTS-Datei in eine JSON-Datei um.
> Weitere Informationen: <https://www.caida.org/catalog/software/scamper/>.

- Wandle `warts`-Dateien in JSON um und gib diese aus:

`sc_warts2json {{path/to/file1.warts path/to/file2.warts ...}}`
