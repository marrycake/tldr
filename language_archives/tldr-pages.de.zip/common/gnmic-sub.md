# gnmic sub

> Dieser Befehl ist ein Alias von `gnmic subscribe`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr gnmic subscribe`
