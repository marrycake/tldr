# docker container remove

> Dit commando is een alias van `docker rm`.

- Bekijk de documentatie van het originele commando:

`tldr docker rm`
