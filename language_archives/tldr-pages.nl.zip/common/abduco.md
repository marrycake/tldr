# abduco

> Terminal sessiemanager.
> Meer informatie: <https://manned.org/abduco>.

- Toon alle sessies:

`abduco`

- Koppel aan een sessie en maak deze aan als deze nog niet bestaat:

`abduco -A {{naam}} {{bash}}`

- Maak verbinding met een sessie met `dvtm` en maak deze aan als deze nog niet bestaat:

`abduco -A {{naam}}`

- Loskoppelen van een sessie:

`<Ctrl \>`

- Voeg toe aan een sessie in alleen-lezen modus:

`abduco -Ar {{naam}}`
