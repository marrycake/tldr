# pamedge

> Voer randdetectie uit op een Netpbm afbeelding.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pamedge.html>.

- Voer randdetectie uit op een Netpbm afbeelding:

`pamedge {{pad/naar/invoer.pam}} > {{pad/naar/uitvoer.pam}}`
