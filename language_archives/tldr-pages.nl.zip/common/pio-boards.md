# pio boards

> Toon alle voorgeconfigureerde embedded boards beschikbaar in PlatformIO.
> Meer informatie: <https://docs.platformio.org/en/latest/core/userguide/cmd_boards.html>.

- Toon alle beschikbare boards:

`pio boards`

- Toon alleen boards van geïnstalleerde platformen:

`pio boards --installed`
