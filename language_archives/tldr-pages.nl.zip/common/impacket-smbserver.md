# impacket-smbserver

> Dit commando is een alias van `smbserver.py`.

- Bekijk de documentatie van het originele commando:

`tldr smbserver.py`
