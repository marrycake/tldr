# mpicxx

> Dit commando is een alias van `mpic++`.

- Bekijk de documentatie van het originele commando:

`tldr mpic++`
