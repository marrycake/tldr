# j

> Dit commando is een alias van `autojump`.

- Bekijk de documentatie van het originele commando:

`tldr autojump`
