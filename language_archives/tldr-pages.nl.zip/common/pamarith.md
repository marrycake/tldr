# pamarith

> Pas een binaire functie toe op twee Netpbm afbeeldingen.
> Bekijk ook: `pamfunc`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pamarith.html>.

- Pas de gespecificeerde binaire functie pixel-gewijs toe op twee gespecificeerde afbeeldingen (welke hetzelfde formaat dienen te hebben):

`pamarith -{{add|subtract|multiply|divide|difference|minimum|maximum|...}} {{pad/naar/afbeelding1.pam|pbm|pgm|ppm}} {{pad/naar/afbeelding2.pam|pbm|pgm|ppm}}`
