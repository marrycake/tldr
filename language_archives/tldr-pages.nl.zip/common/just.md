# just

> `just` kan naar meerdere commando's met dezelfde naam verwijzen.

- Bekijk de documentatie van het commando:

`tldr just.1`

- Bekijk de documentatie voor de V8 JavaScript runtime voor Linux:

`tldr just.js`
