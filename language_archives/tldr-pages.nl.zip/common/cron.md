# cron

> Een systeemplanner voor het onbewaakt uitvoeren van taken of opdrachten.
> Het commando om invoer toe te voegen, te bewerken of te verwijderen in `cron` heet `crontab`.

- Bekijk de documentatie voor het beheren van `cron`-invoeren:

`tldr crontab`
