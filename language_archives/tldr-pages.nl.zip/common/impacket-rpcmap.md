# impacket-rpcmap

> Dit commando is een alias van `rpcmap.py`.

- Bekijk de documentatie van het originele commando:

`tldr rpcmap.py`
