# impacket-GetUserSPNs

> Dit commando is een alias van `GetUserSPNs.py`.

- Bekijk de documentatie van het originele commando:

`tldr GetUserSPNs.py`
