# impacket-mssqlclient

> Dit commando is een alias van `mssqlclient.py`.

- Bekijk de documentatie van het originele commando:

`tldr mssqlclient.py`
