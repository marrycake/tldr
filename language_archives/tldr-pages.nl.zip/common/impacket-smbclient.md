# impacket-smbclient

> Dit commando is een alias van `smbclient.py`.

- Bekijk de documentatie van het originele commando:

`tldr smbclient.py`
