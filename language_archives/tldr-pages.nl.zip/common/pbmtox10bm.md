# pbmtox10bm

> Dit commando is vervangen door `pbmtoxbm -x10`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pbmtox10bm.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pbmtoxbm`
