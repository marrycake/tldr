# convert

> Dit commando is een alias van `magick convert`.
> Let op: deze alias is verouderd sinds ImageMagick 7. Het is vervangen door `magick`.
> Gebruik `magick convert` als je de oude tool wilt gebruiken in versies 7+.

- Bekijk de documentatie van het originele commando:

`tldr magick convert`
