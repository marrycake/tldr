# mpic++

> Open MPI wrapper compiler voor C++.
> Bekijk ook: `mpirun`.
> Meer informatie: <https://manned.org/mpicxx>.

- Compileer een Open MPI programma:

`mpic++ {{pad/naar/bronbestand}}`

- Toon alle wrapper geleverde vlaggen:

`mpic++ --showme`
