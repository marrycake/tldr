# gdm-binary

> Dit commando is een alias van `gdm`.

- Bekijk de documentatie van het originele commando:

`tldr gdm`
