# mogrify

> Dit commando is een alias van `magick mogrify`.

- Bekijk de documentatie van het originele commando:

`tldr magick mogrify`
