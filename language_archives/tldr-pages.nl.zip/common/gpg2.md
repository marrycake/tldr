# gpg2

> Dit commando is een alias van `gpg`.

- Bekijk de documentatie van het originele commando:

`tldr gpg`
