# netcat

> Dit commando is een alias van `nc`.

- Bekijk de documentatie van het originele commando:

`tldr nc`
