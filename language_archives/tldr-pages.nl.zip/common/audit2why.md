# audit2why

> Dit commando is een alias van `audit2allow --why`.

- Bekijk de documentatie van het originele commando:

`tldr audit2allow`
