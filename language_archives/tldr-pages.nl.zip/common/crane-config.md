# crane config

> Verkrijg de configuratie van een image.
> Meer informatie: <https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_config.md>.

- Verkrijg de configuratie van een image:

`crane config {{image_naam}}`

- Toon de help:

`crane config {{[-h|--help]}}`
