# msedge

> De command-line utility van Microsoft Edge is beschikbaar als `msedge` op Windows en `microsoft-edge` op andere platforms.
> Meer informatie: <https://microsoft.com/edge>.

- Bekijk de documentatie van Microsoft Edge op Windows:

`tldr {{[-p|--platform]}} windows msedge`

- Bekijk de documentatie van Microsoft Edge op andere platforms:

`tldr {{[-p|--platform]}} common microsoft-edge`
