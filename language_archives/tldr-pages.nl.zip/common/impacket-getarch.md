# impacket-getArch

> Dit commando is een alias van `getArch.py`.

- Bekijk de documentatie van het originele commando:

`tldr getArch.py`
