# nm-classic

> Dit commando is een alias van `nm`.

- Bekijk de documentatie van het originele commando:

`tldr nm`
