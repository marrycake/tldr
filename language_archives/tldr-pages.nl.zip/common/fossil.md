# fossil

> Gedistribueerd versiebheer systeem.
> Sommige subcommando's zoals `db` hebben hun eigen documentatie.
> Meer informatie: <https://fossil-scm.org/>.

- Voer een Fossil subcommando uit:

`fossil {{subcommando}}`

- Toon de algemene help:

`fossil help`

- Toon de help voor een specifiek subcommando (zoals `add`, `commit`, etc.):

`fossil help {{subcommando}}`

- Toon de versie:

`fossil version`
