# lzcat

> Dit commando is een alias van `xz --format=lzma --decompress --stdout`.

- Bekijk de documentatie van het originele commando:

`tldr xz`
