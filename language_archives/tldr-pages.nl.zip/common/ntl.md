# ntl

> Dit commando is een alias van `netlify`.

- Bekijk de documentatie van het originele commando:

`tldr netlify`
