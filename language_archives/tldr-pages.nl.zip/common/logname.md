# logname

> Toont de inlognaam van de gebruiker.
> Meer informatie: <https://www.gnu.org/software/coreutils/manual/html_node/logname-invocation.html>.

- Geef de momenteel aangemelde gebruikersnaam weer:

`logname`
