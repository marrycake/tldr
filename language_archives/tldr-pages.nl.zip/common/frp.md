# frp

> Fast Reverse Proxy: snel netwerktunnels opzetten om bepaalde services bloot te stellen aan het internet of andere externe netwerken.
> Meer informatie: <https://github.com/fatedier/frp>.

- Bekijk de documentatie voor `frpc`, het `frp`-clientcomponent:

`tldr frpc`

- Bekijk de documentatie voor `frps`, het `frp`-servercomponent:

`tldr frps`
