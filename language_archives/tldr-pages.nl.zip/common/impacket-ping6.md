# impacket-ping6

> Dit commando is een alias van `ping6.py`.

- Bekijk de documentatie van het originele commando:

`tldr ping6.py`
