# mesg

> Controleer of stel in of een terminal berichten van andere gebruikers kan ontvangen, meestal van het `write`-commando.
> Bekijk ook `write`, `talk`.
> Meer informatie: <https://manned.org/mesg.1p>.

- Controleer of de terminal openstaat voor berichten:

`mesg`

- Sta geen berichten toe van het write-commando:

`mesg n`

- Sta berichten toe van het write-commando:

`mesg y`
