# identify

> Dit commando is een alias van `magick identify`.

- Bekijk de documentatie van het originele commando:

`tldr magick identify`
