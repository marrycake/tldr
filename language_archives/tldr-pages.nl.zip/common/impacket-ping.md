# impacket-ping

> Dit commando is een alias van `ping.py`.

- Bekijk de documentatie van het originele commando:

`tldr ping.py`
