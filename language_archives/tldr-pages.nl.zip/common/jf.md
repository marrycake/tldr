# jf

> Werk met JFrog producten zoals Artifactory, Xray, Distribution, Pipelines en Mission Control.
> Meer informatie: <https://jfrog.com/help/r/jfrog-cli/usage>.

- Voeg een nieuwe configuratie toe:

`jf config add`

- Toon de huidige configuratie:

`jf config show`

- Zoek naar artifacts binnen de opgegeven repository en map:

`jf rt search --recursive {{repostiory_naam}}/{{pad}}/`
