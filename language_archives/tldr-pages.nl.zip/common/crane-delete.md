# crane delete

> Verwijder een image-referentie uit de registry.
> Meer informatie: <https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_delete.md>.

- Verwijder een image-referentie uit de registry:

`crane delete {{image_naam}}`

- Toon de help:

`crane delete {{[-h|--help]}}`
