# netexec

> Dit commando is een alias van `nxc`.

- Bekijk de documentatie van het originele commando:

`tldr nxc`
