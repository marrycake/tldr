# jfrog

> Dit commando is een alias van `jf`.

- Bekijk de documentatie van het originele commando:

`tldr jf`
