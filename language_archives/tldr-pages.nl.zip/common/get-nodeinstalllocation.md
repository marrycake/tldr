# Get-NodeInstallLocation

> Haal de huidige Node.js installatiemap voor `ps-nvm` op.
> Onderdeel van `ps-nvm` en kan alleen uitgevoerd worden in PowerShell.
> Meer informatie: <https://github.com/aaronpowell/ps-nvm>.

- Haal de huidige Node.js installatiemap op:

`Get-NodeInstallLocation`
