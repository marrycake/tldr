# more

> Toon een bestand interactief, met de mogelijkheid om te scrollen en te zoeken.
> Bekijk ook: `less`.
> Meer informatie: <https://manned.org/more.1p>.

- Open een bestand:

`more {{pad/naar/bestand}}`

- Toon een specifieke regel:

`more +{{regelnummer}} {{pad/naar/bestand}}`

- Ga naar de volgende pagina:

`<Spatie>`

- Zoek naar een string (druk op `<n>` om naar de volgende overeenkomst te gaan):

`</>{{iets}}<Enter>`

- Afsluiten:

`<q>`

- Toon de help over interactieve commando's:

`<h>`
