# impacket-ntfs-read

> Dit commando is een alias van `ntfs-read.py`.

- Bekijk de documentatie van het originele commando:

`tldr ntfs-read.py`
