# mscore

> Dit commando is een alias van `musescore`.

- Bekijk de documentatie van het originele commando:

`tldr musescore`
