# moreutils

> Een collectie van UNIX tools.
> Let op: moreutils is geen commando, maar een set van commando's.
> Meer informatie: <https://joeyh.name/code/moreutils/>.

- Bekijk de documentatie van pagina's gerelateerd aan standaard streams:

`tldr {{ifne|mispipe|pee|sponge|vipe|vidir}}`

- Bekijk de documentatie van andere pagina's:

`tldr {{combine|errno|ifdata|isutt8|lckdo|parallel|zrun}}`
