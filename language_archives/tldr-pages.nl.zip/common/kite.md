# kite

> Dit commando is een alias van `kiterunner`.

- Bekijk de documentatie van het originele commando:

`tldr kiterunner`
