# ClamAV

> Open-source anti-virus programma.
> ClamAV is geen commando, maar een set van commando's.
> Meer informatie: <https://www.clamav.net>.

- Toon de tldr pagina om bestanden te scannen door gebruik te maken van de `clamd` daemon:

`tldr clamdscan`

- Toon de tldr pagina om bestanden te scannen zonder gebruik te maken van de `clamd` daemon:

`tldr clamscan`

- Toon de tldr pagina om de virus definities te updaten:

`tldr freshclam`
