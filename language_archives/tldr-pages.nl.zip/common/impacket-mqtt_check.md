# impacket-mqtt_check

> Dit commando is een alias van `mqtt_check.py`.

- Bekijk de documentatie van het originele commando:

`tldr mqtt_check.py`
