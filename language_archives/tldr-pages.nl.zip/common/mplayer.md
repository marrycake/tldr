# mplayer

> Cross-platform multimediaspeler.
> Meer informatie: <https://mplayerhq.hu/DOCS/HTML/en/commandline.html>.

- Speel het opgegeven bestand of URL af:

`mplayer {{pad/naar/bestand|url}}`

- Speel meerdere bestanden af:

`mplayer {{pad/naar/bestand1 pad/naar/bestand2 ...}}`

- Speel een specifiek bestand herhaaldelijk af:

`mplayer -loop {{0}} {{pad/naar/bestand}}`

- Pauzeer het afspelen:

`<Spatie>`

- Sluit mplayer:

`<Esc>`

- Zoek 10 seconden vooruit of achteruit:

`{{<ArrowLeft>|<ArrowRight>}}`
