# open

> `open` kan verwijzen naar meerdere commando's met dezelfde naam.

- Bekijk de documentatie voor het commando dat beschikbaar is in macOS:

`tldr open {{[-p|--platform]}} osx`

- Bekijk de documentatie voor het commando dat beschikbaar is via fish:

`tldr open.fish`
