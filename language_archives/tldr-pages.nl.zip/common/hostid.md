# hostid

> Toon het numerieke identificatienummer voor de huidige host (niet noodzakelijkerwijs het IP-adres).
> Meer informatie: <https://www.gnu.org/software/coreutils/manual/html_node/hostid-invocation.html>.

- Toon het numerieke identificatienummer voor de huidige host in hexadecimale notatie:

`hostid`
