# npm run-script

> Dit commando is een alias van `npm run`.

- Bekijk de documentatie van het originele commando:

`tldr npm run`
