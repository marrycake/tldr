# opera

> Dit commando is een alias van `chromium`.
> Meer informatie: <https://opera.com>.

- Bekijk de documentatie van het originele commando:

`tldr chromium`
