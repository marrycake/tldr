# lima

> Dit commando is een alias van `limactl shell` voor de default VM instantie.
> Je kan ook de omgevingsvariabele `$LIMA_INSTANCE` zetten om te werken op een andere instantie.

- Bekijk de documentatie van het originele commando:

`tldr limactl`
