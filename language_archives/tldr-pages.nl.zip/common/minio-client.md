# minio-client

> Dit commando is een alias van `mc` (MinIO client).

- Bekijk de documentatie van het originele commando:

`tldr mc.cli`
