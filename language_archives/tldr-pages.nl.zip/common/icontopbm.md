# icontopbm

> Dit commando is vervangen door `sunicontopnm`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/icontopbm.html>.

- Bekijk de documentatie van het huidige commando:

`tldr sunicontopnm`
