# bzcat

> Dit commando is een alias van `bzip2 --decompress --stdout`.

- Bekijk de documentatie van het originele commando:

`tldr bzip2`
