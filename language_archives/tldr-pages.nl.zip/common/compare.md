# compare

> Dit commando is een alias van `magick compare`.

- Bekijk de documentatie van het originele commando:

`tldr magick compare`
