# bunzip2

> Dit commando is een alias van `bzip2 --decompress`.

- Bekijk de documentatie van het originele commando:

`tldr bzip2`
