# false

> Geeft een afsluitcode van 1 terug.
> Meer informatie: <https://www.gnu.org/software/coreutils/manual/html_node/false-invocation.html>.

- Geeft een afsluitcode van 1 terug:

`false`
