# impacket-GetADUsers

> Dit commando is een alias van `GetADUsers.py`.

- Bekijk de documentatie van het originele commando:

`tldr GetADUsers.py`
