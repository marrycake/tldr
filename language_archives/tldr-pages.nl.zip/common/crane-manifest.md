# crane manifest

> Verkrijg het manifest van een image.
> Meer informatie: <https://github.com/google/go-containerregistry/blob/main/cmd/crane/doc/crane_manifest.md>.

- Verkrijg het manifest:

`crane manifest {{image_naam}}`

- Toon de help:

`crane manifest {{[-h|--help]}}`
