# mpiexec

> Dit commando is een alias van `mpirun`.

- Bekijk de documentatie van het originele commando:

`tldr mpirun`
