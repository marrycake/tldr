# npm fund

> Haal financieringsinformatie op van pakketten.
> Meer informatie: <https://docs.npmjs.com/cli/npm-fund>.

- Toon afhankelijkheden met financierings-URL voor het project in de huidige directory:

`npm fund`

- Open de financierings-URL voor een specifiek pakket in de standaard webbrowser:

`npm fund {{pakket}}`

- Toon afhankelijkheden met een financierings-URL voor een specifieke [w]orkspace voor het project in de huidige directory:

`npm fund {{[-w|--workspace]}} {{workspace}}`
