# logger

> Voeg berichten toe aan syslog.
> Meer informatie: <https://manned.org/logger.1p>.

- Log een bericht naar syslog:

`logger {{bericht}}`
