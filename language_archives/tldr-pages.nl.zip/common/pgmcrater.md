# pgmcrater

> Dit commando is vervangen door `pamcrater`, `pamshadedrelief` en `pamtopnm`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pgmcrater.html>.

- Bekijk de documentatie voor `pamcrater`:

`tldr pamcrater`

- Bekijk de documentatie voor `pamshadedrelief`:

`tldr pamshadedrelief`

- Bekijk de documentatie voor `pamtopnm`:

`tldr pamtopnm`
