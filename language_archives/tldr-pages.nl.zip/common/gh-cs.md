# gh cs

> Dit commando is een alias van `gh codespace`.

- Bekijk de documentatie van het originele commando:

`tldr gh codespace`
