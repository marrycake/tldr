# impacket-secretsdump

> Dit commando is een alias van `secretsdump.py`.

- Bekijk de documentatie van het originele commando:

`tldr secretsdump.py`
