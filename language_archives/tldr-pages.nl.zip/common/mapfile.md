# mapfile

> Dit commando is een alias van `readarray`.

- Bekijk de documentatie van het originele commando:

`tldr readarray`
