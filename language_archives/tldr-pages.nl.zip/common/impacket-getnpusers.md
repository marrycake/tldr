# impacket-GetNPUsers

> Dit commando is een alias van `GetNPUsers.py`.

- Bekijk de documentatie van het originele commando:

`tldr GetNPUsers.py`
