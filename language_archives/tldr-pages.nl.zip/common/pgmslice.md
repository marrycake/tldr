# pgmslice

> Dit commando is vervangen door `pamslice`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pgmslice.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamslice`
