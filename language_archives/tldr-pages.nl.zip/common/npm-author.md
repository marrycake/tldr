# npm author

> Dit commando is een alias van `npm owner`.

- Bekijk de documentatie van het originele commando:

`tldr npm owner`
