# npm start

> Dit commando is een alias van `npm run start`.

- Bekijk de documentatie van het originele commando:

`tldr npm run`
