# gcrane help

> Help biedt hulp voor elk commando in de applicatie.
> Meer informatie: <https://github.com/google/go-containerregistry/blob/main/cmd/gcrane/README.md>.

- Toon de help voor een subcommando:

`gcrane help {{commando}}`

- Toon de help:

`gcrane help {{[-h|--help]}}`
