# impacket-rpcdump

> Dit commando is een alias van `rpcdump.py`.

- Bekijk de documentatie van het originele commando:

`tldr rpcdump.py`
