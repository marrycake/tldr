# jupyterlab

> Dit commando is een alias van `jupyter lab`.

- Bekijk de documentatie van het originele commando:

`tldr jupyter lab`
