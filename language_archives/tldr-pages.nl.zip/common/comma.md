# comma

> Dit commando is een alias van `,`.

- Bekijk de documentatie van het originele commando:

`tldr ,`
