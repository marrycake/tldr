# crane cp

> Dit commando is een alias van `crane copy`.

- Bekijk de documentatie van het originele commando:

`tldr crane copy`
