# pamnoraw

> Dit commando is een alias van `pamtopnm -plain`.

- Bekijk de documentatie van het originele commando:

`tldr pamtopnm`
