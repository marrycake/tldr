# groups

> Toon groepslidmaatschappen voor een gebruiker.
> Bekijk ook: `groupadd`, `groupdel`, `groupmod`.
> Meer informatie: <https://www.gnu.org/software/coreutils/manual/html_node/groups-invocation.html>.

- Toon groepslidmaatschappen voor de huidige gebruiker:

`groups`

- Toon groepslidmaatschappen voor een lijst van gebruikers:

`groups {{gebruikersnaam1 gebruikersnaam2 ...}}`
