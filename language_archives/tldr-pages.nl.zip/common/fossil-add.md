# fossil add

> Plaats bestanden of mappen in Fossil versiebeheer.
> Meer informatie: <https://fossil-scm.org/home/help/add>.

- Plaats een bestand of map in versiebeheer, zodat het in de huidige checkout zit:

`fossil add {{pad/naar/map_of_bestand}}`

- Verwijder alle toegevoegde bestanden uit de huidige checkout:

`fossil add --reset`
