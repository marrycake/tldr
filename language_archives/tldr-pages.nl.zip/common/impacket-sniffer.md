# impacket-sniffer

> Dit commando is een alias van `sniffer.py`.

- Bekijk de documentatie van het originele commando:

`tldr sniffer.py`
