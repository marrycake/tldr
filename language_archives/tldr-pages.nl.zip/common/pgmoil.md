# pgmoil

> Dit commando is vervangen door `pamoil`.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pgmoil.html>.

- Bekijk de documentatie van het huidige commando:

`tldr pamoil`
