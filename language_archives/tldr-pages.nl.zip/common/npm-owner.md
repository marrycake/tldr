# npm owner

> Beheer eigendom van gepubliceerde pakketten.
> Meer informatie: <https://docs.npmjs.com/cli/npm-owner>.

- Voeg een nieuwe gebruiker toe als maintainer van een pakket:

`npm owner add {{gebruikersnaam}} {{pakket_naam}}`

- Verwijder een gebruiker van de eigenaars-lijst van een pakket:

`npm owner rm {{gebruikersnaam}} {{pakket_naam}}`

- Toon alle eigenaars van een pakket:

`npm owner ls {{pakket_naam}}`
