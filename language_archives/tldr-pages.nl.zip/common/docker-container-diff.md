# docker container diff

> Dit commando is een alias van `docker diff`.

- Bekijk de documentatie van het originele commando:

`tldr docker diff`
