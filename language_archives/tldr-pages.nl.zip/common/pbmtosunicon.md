# pbmtosunicon

> Converteer een PBM afbeelding naar een Sun icon.
> Meer informatie: <https://netpbm.sourceforge.net/doc/pbmtosunicon.html>.

- Converteer een PBM afbeelding naar een Sun icon:

`pbmtosunicon {{pad/naar/invoer.pbm}} > {{pad/naar/uitvoer.ico}}`
