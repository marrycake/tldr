# httpie

> Beheersinterface voor HTTPie.
> Bekijk ook: `http`, de tool zelf.
> Meer informatie: <https://httpie.io/docs/cli/plugin-manager>.

- Controleer op updates voor `http`:

`httpie cli check-updates`

- Toon geïnstalleerde `http` plugins:

`httpie cli plugins list`

- Installeer/upgrade/installeer plugins:

`httpie cli plugins {{install|upgrade|uninstall}} {{plugin_naam}}`
