# lckdo

> Dit commando is verouderd en vervangen door `flock`.
> Meer informatie: <https://manned.org/lckdo>.

- Bekijk de documentatie van de aanbevolen vervanging:

`tldr flock`
