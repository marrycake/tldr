# lzless

> Dit commando is een alias van `xzless`.

- Bekijk de documentatie van het originele commando:

`tldr xzless`
