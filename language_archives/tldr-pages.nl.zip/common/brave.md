# brave

> Dit commando is een alias van `chromium`.
> Meer informatie: <https://support.brave.com/hc/en-us/articles/360044860011-How-Do-I-Use-Command-Line-Flags-in-Brave>.

- Bekijk de documentatie van het originele commando:

`tldr chromium`
