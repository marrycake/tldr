# copr

> Dit commando is een alias van `copr-cli`.

- Bekijk de documentatie van het originele commando:

`tldr copr-cli`
