# fossil delete

> Dit commando is een alias van `fossil rm`.

- Bekijk de documentatie van het originele commando:

`tldr fossil rm`
