# npm-home

> Open de `npm`-pagina, Yarn-pagina of GitHub-repository van een pakket in de webbrowser.
> Meer informatie: <https://github.com/sindresorhus/npm-home>.

- Open de `npm`-pagina van een specifiek pakket in de webbrowser:

`npm-home {{pakket}}`

- Open de GitHub-repository van een specifiek pakket in de webbrowser:

`npm-home {{[-g|--github]}} {{pakket}}`

- Open de Yarn-pagina van een specifiek pakket in de webbrowser:

`npm-home {{[-y|--yarn]}} {{pakket}}`
