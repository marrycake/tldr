# impacket-sniff

> Dit commando is een alias van `sniff.py`.

- Bekijk de documentatie van het originele commando:

`tldr sniff.py`
