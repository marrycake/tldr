# pwd

> แสดงชื่อของไดเรกทอรีที่ทำงานอยู่
> ข้อมูลเพิ่มเติม: <https://www.gnu.org/software/coreutils/manual/html_node/pwd-invocation.html>

- แสดงชื่อของไดเรกทอรีที่ทำงานอยู่:

`pwd`

- แสดงชื่อของไดเรกทอรีที่ทำงานอยู่ โดยไม่รวม symlinks:

`pwd {{[-P|--physical]}}`
