# tlmgr arch

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `tlmgr platform`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr tlmgr platform`
