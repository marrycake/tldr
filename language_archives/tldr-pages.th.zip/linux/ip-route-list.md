# ip route list

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `ip route show`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr ip route show`
