# auvaltool

> เครื่องมือสำหรับตรวจสอบและยืนยันความถูกต้องของ AudioUnit บน macOS.
> ใช้ในการทดสอบว่า AudioUnit แต่ละตัวทำงานถูกต้องตามมาตรฐานหรือไม่.
> ข้อมูลเพิ่มเติม: <https://keith.github.io/xcode-man-pages/auvaltool.1.html>

- แสดงรายการ AudioUnit ที่มีทั้งหมดทุกประเภท:

`auvaltool -a`

- แสดงรายการ AudioUnit ที่มีทั้งหมด พร้อมแสดงที่ตั้งไฟล์:

`auvaltool -al`
