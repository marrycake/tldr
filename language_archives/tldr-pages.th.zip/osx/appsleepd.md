# appsleepd

> เริ่มการพักการทำงานของแอป.
> ไม่ควรเรียกใช้งานด้วยตนเอง.
> ข้อมูลเพิ่มเติม: <https://keith.github.io/xcode-man-pages/appsleepd.8.html>

- เริ่ม daemon:

`appsleepd`
