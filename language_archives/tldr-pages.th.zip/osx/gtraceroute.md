# gtraceroute

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `traceroute`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr traceroute`
