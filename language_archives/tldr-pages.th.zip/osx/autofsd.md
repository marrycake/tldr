# autofsd

> รันคำสั่ง `automount` เมื่อเริ่มระบบหรือมีการเปลี่ยนแปลงการตั้งค่าเครือข่ายเน็ต.
> ไม่ควรเรียกใช้งานด้วยตนเอง.
> ข้อมูลเพิ่มเติม: <https://keith.github.io/xcode-man-pages/autofsd.8.html>

- เริ่ม daemon:

`autofsd`
