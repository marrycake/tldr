# applecamerad

> ตัวจัดการกล้อง.
> ไม่ควรเรียกใช้งานด้วยตนเอง.
> ข้อมูลเพิ่มเติม: <https://www.theiphonewiki.com/wiki/Services>

- เริ่ม daemon:

`applecamerad`
