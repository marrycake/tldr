# gupdatedb

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `-p linux updatedb`

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr {{[-p|--platform]}} linux updatedb`
