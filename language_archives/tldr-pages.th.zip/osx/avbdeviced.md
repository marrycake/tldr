# avbdeviced

> บริการสำหรับจัดการอุปกรณ์ Audio Video Bridging (AVB).
> ไม่ควรเรียกใช้งานด้วยตนเอง.
> ข้อมูลเพิ่มเติม: <https://keith.github.io/xcode-man-pages/avbdeviced.1.html>

- เริ่ม daemon:

`avbdeviced`
