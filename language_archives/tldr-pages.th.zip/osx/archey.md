# archey

> แสดงข้อมูลระบบอย่างมีสไตล์.
> ข้อมูลเพิ่มเติม: <https://github.com/joshfinnie/archey-osx>

- แสดงข้อมูลระบบ:

`archey`

- แสดงข้อมูลระบบแบบไร้สี:

`archey --nocolor`

- แสดงข้อมูลระบบโดยใช้ MacPorts แทน Homebrew:

`archey --macports`

- แสดงข้อมูลระบบโดยไม่ตรวจสอบ IP address:

`archey --offline`
