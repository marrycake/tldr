# apachectl

> อินเทอร์เฟซควบคุมสำหรับ Apache HTTP Server เพื่อ macOS.
> ข้อมูลเพิ่มเติม: <https://keith.github.io/xcode-man-pages/apachectl.8.html>

- เริ่ม `org.apache.httpd` launchd job:

`apachectl start`

- หยุด launchd job:

`apachectl stop`

- รีสตาร์ท (หยุด, แล้วเริ่ม) launchd job ใหม่:

`apachectl restart`
