# airportd

> อินเทอร์เฟซจัดการเครือข่ายไร้สาย (WLANs, Wi-Fi).
> โปรแกรมนี้ทำงานในพื้นหลังในฐานะ daemon และไม่ควรเรียกใช้งานด้วยตนเอง.
> ข้อมูลเพิ่มเติม: <https://keith.github.io/xcode-man-pages/airportd.8.html>

- เริ่มต้น daemon:

`airportd`
