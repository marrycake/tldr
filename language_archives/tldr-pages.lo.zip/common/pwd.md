# pwd

> ສະແດງຊື່ directory ທີ່ເຮັດວຽກຢູ່
> ຂໍ້ມູນເພີ່ມເຕີມ: <https://www.gnu.org/software/coreutils/manual/html_node/pwd-invocation.html>.

- ສະແດງຊື່ directory ທີ່ເຮັດວຽກຢູ່:

`pwd`

- ສະແດງຊື່ directory ທີ່ເຮັດວຽກຢູ່ໂດຍບໍ່ລວມ symlinks:

`pwd -P`
