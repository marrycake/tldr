# piodebuggdb

> ຄຳສັ່ງນີ້ເປັນອີກຊື່ໜຶ່ງຂອງຄຳສັ່ງ `pio debug --interface=gdb`.

- ເປີດເບິ່ງລາຍລະອຽດຄຳສັ່ງແບບເຕັມ:

`tldr pio debug`
