# ypchfn

> To polecenie jest aliasem `chpass`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr chpass`
