# git abort

> Przerwij trwający rebase, merge lub cherry-pick.
> Jest częścią `git-extras`.
> Więcej informacji: <https://github.com/tj/git-extras/blob/master/Commands.md#git-abort>.

- Przerwij operację Git rebase, merge lub cherry-pick:

`git abort`
