# comma

> To polecenie jest aliasem `,`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr ,`
