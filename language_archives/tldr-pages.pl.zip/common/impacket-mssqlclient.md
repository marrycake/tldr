# impacket-mssqlclient

> To polecenie jest aliasem `mssqlclient.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr mssqlclient.py`
