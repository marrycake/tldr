# impacket-sniff

> To polecenie jest aliasem `sniff.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr sniff.py`
