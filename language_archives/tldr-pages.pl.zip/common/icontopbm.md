# icontopbm

> To polecenie zostało zastąpione przez `sunicontopnm`.
> Więcej informacji: <https://netpbm.sourceforge.net/doc/icontopbm.html>.

- Zobacz dokumentację aktualnego polecenia:

`tldr sunicontopnm`
