# lzcat

> To polecenie jest aliasem `xz --format=lzma --decompress --stdout`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xz`
