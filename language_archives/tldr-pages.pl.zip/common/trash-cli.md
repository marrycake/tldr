# trash-cli

> To polecenie jest aliasem `trash`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr trash`
