# copr

> To polecenie jest aliasem `copr-cli`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr copr-cli`
