# bunzip2

> To polecenie jest aliasem `bzip2 --decompress`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr bzip2`
