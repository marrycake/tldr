# impacket-getArch

> To polecenie jest aliasem `getArch.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr getArch.py`
