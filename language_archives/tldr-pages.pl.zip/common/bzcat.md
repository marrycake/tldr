# bzcat

> To polecenie jest aliasem `bzip2 --decompress --stdout`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr bzip2`
