# tlmgr arch

> To polecenie jest aliasem `tlmgr platform`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr tlmgr platform`
