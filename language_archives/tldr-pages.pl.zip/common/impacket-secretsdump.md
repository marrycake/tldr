# impacket-secretsdump

> To polecenie jest aliasem `secretsdump.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr secretsdump.py`
