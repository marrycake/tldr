# netcat

> To polecenie jest aliasem `nc`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr nc`
