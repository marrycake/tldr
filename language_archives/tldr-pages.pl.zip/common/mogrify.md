# mogrify

> To polecenie jest aliasem `magick mogrify`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr magick mogrify`
