# pnmdepth

> To polecenie jest aliasem `pamdepth`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pamdepth`
