# rustup uninstall

> To polecenie jest aliasem `rustup toolchain uninstall`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr rustup toolchain`
