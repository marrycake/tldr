# impacket-psexec

> To polecenie jest aliasem `psexec.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr psexec.py`
