# impacket-smbclient

> To polecenie jest aliasem `smbclient.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr smbclient.py`
