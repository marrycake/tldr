# impacket-mqtt_check

> To polecenie jest aliasem `mqtt_check.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr mqtt_check.py`
