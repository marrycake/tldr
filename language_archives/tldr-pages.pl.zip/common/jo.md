# jo

> To polecenie jest aliasem `autojump`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr autojump`
