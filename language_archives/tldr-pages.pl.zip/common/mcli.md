# mcli

> To polecenie jest aliasem `mc` (MinIO client).

- Zobacz dokumentację oryginalnego polecenia:

`tldr mc.cli`
