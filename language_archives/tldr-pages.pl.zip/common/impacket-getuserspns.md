# impacket-GetUserSPNs

> To polecenie jest aliasem `GetUserSPNs.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr GetUserSPNs.py`
