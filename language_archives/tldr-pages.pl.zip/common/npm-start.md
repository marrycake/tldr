# npm start

> To polecenie jest aliasem `npm run start`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr npm run`
