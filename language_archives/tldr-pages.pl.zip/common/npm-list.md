# npm list

> To polecenie jest aliasem `npm ls`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr npm ls`
