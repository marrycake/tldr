# npm stop

> To polecenie jest aliasem `npm run stop`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr npm run`
