# mpicxx

> To polecenie jest aliasem `mpic++`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr mpic++`
