# impacket-ntfs-read

> To polecenie jest aliasem `ntfs-read.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr ntfs-read.py`
