# zstdcat

> To polecenie jest aliasem `zstd --decompress --stdout`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr zstd`
