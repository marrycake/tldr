# identify

> To polecenie jest aliasem `magick identify`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr magick identify`
