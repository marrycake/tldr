# xml xmln

> To polecenie jest aliasem `xml pyx`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xml pyx`
