# impacket-smbserver

> To polecenie jest aliasem `smbserver.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr smbserver.py`
