# gh cs

> To polecenie jest aliasem `gh codespace`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr gh codespace`
