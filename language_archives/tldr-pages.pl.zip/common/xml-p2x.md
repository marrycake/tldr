# xml p2x

> To polecenie jest aliasem `xml depyx`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xml depyx`
