# gpg2

> To polecenie jest aliasem `gpg`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr gpg`
