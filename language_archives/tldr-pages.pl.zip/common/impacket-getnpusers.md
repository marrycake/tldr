# impacket-GetNPUsers

> To polecenie jest aliasem `GetNPUsers.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr GetNPUsers.py`
