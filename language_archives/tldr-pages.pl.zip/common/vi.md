# vi

> To polecenie jest aliasem `vim`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr vim`
