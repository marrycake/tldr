# impacket-GetADUsers

> To polecenie jest aliasem `GetADUsers.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr GetADUsers.py`
