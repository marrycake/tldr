# npm test

> To polecenie jest aliasem `npm run test`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr npm run`
