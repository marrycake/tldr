# batch

> To polecenie jest aliasem `at`.
> Więcej informacji: <https://manned.org/batch>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr at`
