# npm run-script

> To polecenie jest aliasem `npm run`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr npm run`
