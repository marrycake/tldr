# mpiexec

> To polecenie jest aliasem `mpirun`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr mpirun`
