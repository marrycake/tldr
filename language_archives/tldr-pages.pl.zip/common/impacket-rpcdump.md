# impacket-rpcdump

> To polecenie jest aliasem `rpcdump.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr rpcdump.py`
