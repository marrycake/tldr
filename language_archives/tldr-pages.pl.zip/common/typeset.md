# typeset

> To polecenie jest aliasem `declare`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr declare`
