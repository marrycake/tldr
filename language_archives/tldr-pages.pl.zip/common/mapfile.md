# mapfile

> To polecenie jest aliasem `readarray`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr readarray`
