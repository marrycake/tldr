# kite

> To polecenie jest aliasem `kiterunner`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr kiterunner`
