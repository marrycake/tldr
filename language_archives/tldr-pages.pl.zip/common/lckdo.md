# lckdo

> To polecenie jest przestarzałe i zastąpione przez `flock`.
> Więcej informacji: <https://manned.org/lckdo>.

- Zobacz dokumentację zalecanego zamiennika:

`tldr flock`
