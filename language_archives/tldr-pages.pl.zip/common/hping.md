# hping

> To polecenie jest aliasem `hping3`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr hping3`
