# pulumi down

> To polecenie jest aliasem `pulumi destroy`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pulumi destroy`
