# netexec

> To polecenie jest aliasem `nxc`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr nxc`
