# rustup install

> To polecenie jest aliasem `rustup toolchain install`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr rustup toolchain`
