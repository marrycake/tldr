# impacket-sniffer

> To polecenie jest aliasem `sniffer.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr sniffer.py`
