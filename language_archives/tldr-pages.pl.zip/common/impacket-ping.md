# impacket-ping

> To polecenie jest aliasem `ping.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr ping.py`
