# rnano

> To polecenie jest aliasem `nano --restricted`.
> Więcej informacji: <https://manned.org/rnano>.

- Zobacz dokumentację oryginalnego polecenia:

`tldr nano`
