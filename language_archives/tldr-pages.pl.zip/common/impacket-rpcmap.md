# impacket-rpcmap

> To polecenie jest aliasem `rpcmap.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr rpcmap.py`
