# pulumi update

> To polecenie jest aliasem `pulumi up`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pulumi up`
