# R

> Interpreter języka R.
> Więcej informacji: <https://www.r-project.org>.

- Uruchom interaktywną powłokę R (REPL):

`R`

- Sprawdź wersję R:

`R --version`

- Uruchom plik:

`R -f {{plik.R}}`
