# tldrl

> To polecenie jest aliasem `tldr-lint`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr tldr-lint`
