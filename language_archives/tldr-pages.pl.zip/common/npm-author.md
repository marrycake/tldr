# npm author

> To polecenie jest aliasem `npm owner`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr npm owner`
