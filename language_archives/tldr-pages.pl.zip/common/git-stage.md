# git stage

> To polecenie jest aliasem `git add`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr git add`
