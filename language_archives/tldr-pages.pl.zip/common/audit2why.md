# audit2why

> To polecenie jest aliasem `audit2allow --why`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr audit2allow`
