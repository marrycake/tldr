# compare

> To polecenie jest aliasem `magick compare`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr magick compare`
