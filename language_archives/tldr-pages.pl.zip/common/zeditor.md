# zeditor

> To polecenie jest aliasem `zed`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr zed`
