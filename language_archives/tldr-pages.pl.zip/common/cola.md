# cola

> To polecenie jest aliasem `git-cola`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr git-cola`
