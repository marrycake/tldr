# impacket-ping6

> To polecenie jest aliasem `ping6.py`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr ping6.py`
