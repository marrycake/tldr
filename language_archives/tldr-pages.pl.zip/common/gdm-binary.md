# gdm-binary

> To polecenie jest aliasem `gdm`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr gdm`
