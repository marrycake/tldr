# lzma

> To polecenie jest aliasem `xz --format=lzma`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xz`
