# xml c14n

> To polecenie jest aliasem `xml canonic`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr xml canonic`
