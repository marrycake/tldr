# jupyterlab

> To polecenie jest aliasem `jupyter lab`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr jupyter lab`
