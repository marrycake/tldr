# gchown

> To polecenie jest aliasem GNU `chown`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr chown`
