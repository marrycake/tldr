# gnl

> To polecenie jest aliasem GNU `nl`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux nl`
