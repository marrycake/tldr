# gbasenc

> To polecenie jest aliasem GNU `basenc`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr basenc`
