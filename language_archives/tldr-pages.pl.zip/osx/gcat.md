# gcat

> To polecenie jest aliasem GNU `cat`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux cat`
