# gdirname

> To polecenie jest aliasem GNU `dirname`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr dirname`
