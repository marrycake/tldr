# glibtool

> To polecenie jest aliasem GNU `libtool`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux libtool`
