# gecho

> To polecenie jest aliasem GNU `echo`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr echo`
