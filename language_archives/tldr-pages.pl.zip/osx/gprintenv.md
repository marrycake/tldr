# gprintenv

> To polecenie jest aliasem GNU `printenv`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr printenv`
