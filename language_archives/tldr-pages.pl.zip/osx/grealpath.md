# grealpath

> To polecenie jest aliasem GNU `realpath`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr realpath`
