# gls

> To polecenie jest aliasem GNU `ls`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr ls`
