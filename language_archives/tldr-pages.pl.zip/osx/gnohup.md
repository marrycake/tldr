# gnohup

> To polecenie jest aliasem GNU `nohup`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr nohup`
