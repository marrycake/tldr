# grlogin

> To polecenie jest aliasem GNU `rlogin`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux rlogin`
