# gdir

> To polecenie jest aliasem GNU `dir`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux dir`
