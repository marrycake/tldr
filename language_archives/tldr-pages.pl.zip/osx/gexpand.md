# gexpand

> To polecenie jest aliasem GNU `expand`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr expand`
