# gmkdir

> To polecenie jest aliasem GNU `mkdir`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr mkdir`
