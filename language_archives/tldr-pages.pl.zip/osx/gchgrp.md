# gchgrp

> To polecenie jest aliasem GNU `chgrp`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr chgrp`
