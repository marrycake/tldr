# gifconfig

> To polecenie jest aliasem GNU `ifconfig`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr ifconfig`
