# gfmt

> To polecenie jest aliasem GNU `fmt`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr fmt`
