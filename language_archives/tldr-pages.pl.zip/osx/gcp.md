# gcp

> To polecenie jest aliasem GNU `cp`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr cp`
