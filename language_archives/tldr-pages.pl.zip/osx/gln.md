# gln

> To polecenie jest aliasem GNU `ln`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr ln`
