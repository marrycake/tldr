# gpwd

> To polecenie jest aliasem GNU `pwd`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pwd`
