# gmkfifo

> To polecenie jest aliasem GNU `mkfifo`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr mkfifo`
