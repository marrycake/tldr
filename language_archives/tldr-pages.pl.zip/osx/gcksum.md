# gcksum

> To polecenie jest aliasem GNU `cksum`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr cksum`
