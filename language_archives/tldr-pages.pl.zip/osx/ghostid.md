# ghostid

> To polecenie jest aliasem GNU `hostid`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr hostid`
