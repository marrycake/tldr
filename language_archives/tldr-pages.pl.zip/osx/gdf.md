# gdf

> To polecenie jest aliasem GNU `df`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux df`
