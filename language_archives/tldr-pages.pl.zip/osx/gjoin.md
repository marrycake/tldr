# gjoin

> To polecenie jest aliasem GNU `join`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr join`
