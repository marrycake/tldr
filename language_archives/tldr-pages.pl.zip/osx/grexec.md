# grexec

> To polecenie jest aliasem GNU `rexec`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux rexec`
