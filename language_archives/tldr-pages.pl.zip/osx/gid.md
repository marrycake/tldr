# gid

> To polecenie jest aliasem GNU `id`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr id`
