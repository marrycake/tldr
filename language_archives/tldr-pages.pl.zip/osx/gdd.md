# gdd

> To polecenie jest aliasem GNU `dd`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux dd`
