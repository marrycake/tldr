# gfalse

> To polecenie jest aliasem GNU `false`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr false`
