# genv

> To polecenie jest aliasem GNU `env`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr env`
