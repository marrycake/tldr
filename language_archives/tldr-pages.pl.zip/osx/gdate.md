# gdate

> To polecenie jest aliasem GNU `date`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} common date`
