# gcomm

> To polecenie jest aliasem GNU `comm`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr comm`
