# ghostname

> To polecenie jest aliasem GNU `hostname`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr hostname`
