# grcp

> To polecenie jest aliasem GNU `rcp`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux rcp`
