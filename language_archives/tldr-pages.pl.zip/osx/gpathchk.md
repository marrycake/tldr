# gpathchk

> To polecenie jest aliasem GNU `pathchk`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pathchk`
