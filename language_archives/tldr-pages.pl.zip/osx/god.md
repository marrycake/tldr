# god

> To polecenie jest aliasem GNU `od`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr od`
