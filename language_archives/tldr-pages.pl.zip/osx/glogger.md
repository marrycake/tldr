# glogger

> To polecenie jest aliasem GNU `logger`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux logger`
