# gpaste

> To polecenie jest aliasem GNU `paste`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr paste`
