# gchroot

> To polecenie jest aliasem GNU `chroot`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr chroot`
