# gbase64

> To polecenie jest aliasem GNU `base64`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} common base64`
