# ginstall

> To polecenie jest aliasem GNU `install`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr install`
