# gping6

> To polecenie jest aliasem GNU `ping6`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr ping6`
