# gfgrep

> To polecenie jest aliasem GNU `fgrep`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr fgrep`
