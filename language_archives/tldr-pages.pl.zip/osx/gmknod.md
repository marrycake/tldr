# gmknod

> To polecenie jest aliasem GNU `mknod`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux mknod`
