# ged

> To polecenie jest aliasem GNU `ed`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr ed`
