# gegrep

> To polecenie jest aliasem GNU `egrep`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr egrep`
