# gdircolors

> To polecenie jest aliasem GNU `dircolors`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr dircolors`
