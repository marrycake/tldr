# gmv

> To polecenie jest aliasem GNU `mv`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr mv`
