# gprintf

> To polecenie jest aliasem GNU `printf`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr printf`
