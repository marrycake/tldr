# gfind

> To polecenie jest aliasem GNU `find`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr find`
