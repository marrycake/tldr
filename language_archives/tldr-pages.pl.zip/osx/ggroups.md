# ggroups

> To polecenie jest aliasem GNU `groups`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr groups`
