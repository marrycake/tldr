# gbase32

> To polecenie jest aliasem GNU `base32`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr base32`
