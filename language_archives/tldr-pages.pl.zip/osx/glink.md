# glink

> To polecenie jest aliasem GNU `link`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr link`
