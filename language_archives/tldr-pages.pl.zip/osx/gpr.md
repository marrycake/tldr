# gpr

> To polecenie jest aliasem GNU `pr`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pr`
