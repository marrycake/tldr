# gptx

> To polecenie jest aliasem GNU `ptx`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux ptx`
