# greadlink

> To polecenie jest aliasem GNU `readlink`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr readlink`
