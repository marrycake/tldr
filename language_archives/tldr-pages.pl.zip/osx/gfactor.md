# gfactor

> To polecenie jest aliasem GNU `factor`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr factor`
