# glocate

> To polecenie jest aliasem GNU `locate`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux locate`
