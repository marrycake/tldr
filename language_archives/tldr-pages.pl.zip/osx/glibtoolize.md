# glibtoolize

> To polecenie jest aliasem GNU `libtoolize`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux libtoolize`
