# ggrep

> To polecenie jest aliasem GNU `grep`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr grep`
