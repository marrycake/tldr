# gmake

> To polecenie jest aliasem GNU `make`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr make`
