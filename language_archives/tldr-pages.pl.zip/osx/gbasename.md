# gbasename

> To polecenie jest aliasem GNU `basename`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr basename`
