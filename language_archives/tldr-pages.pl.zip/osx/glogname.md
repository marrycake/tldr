# glogname

> To polecenie jest aliasem GNU `logname`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr logname`
