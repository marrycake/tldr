# gchmod

> To polecenie jest aliasem GNU `chmod`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr chmod`
