# gpinky

> To polecenie jest aliasem GNU `pinky`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pinky`
