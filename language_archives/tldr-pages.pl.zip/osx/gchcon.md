# gchcon

> To polecenie jest aliasem GNU `chcon`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux chcon`
