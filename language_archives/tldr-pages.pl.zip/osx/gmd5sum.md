# gmd5sum

> To polecenie jest aliasem GNU `md5sum`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr md5sum`
