# gexpr

> To polecenie jest aliasem GNU `expr`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr expr`
