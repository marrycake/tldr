# gindent

> To polecenie jest aliasem GNU `indent`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} common indent`
