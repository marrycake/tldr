# gkill

> To polecenie jest aliasem GNU `kill`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux kill`
