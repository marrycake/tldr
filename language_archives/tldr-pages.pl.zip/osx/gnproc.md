# gnproc

> To polecenie jest aliasem GNU `nproc`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr nproc`
