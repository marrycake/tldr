# gftp

> To polecenie jest aliasem GNU `ftp`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr ftp`
