# aa

> To polecenie jest aliasem `yaa`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr yaa`
