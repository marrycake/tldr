# gcsplit

> To polecenie jest aliasem GNU `csplit`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux csplit`
