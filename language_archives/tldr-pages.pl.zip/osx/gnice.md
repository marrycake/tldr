# gnice

> To polecenie jest aliasem GNU `nice`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr nice`
