# gping

> To polecenie jest aliasem GNU `ping`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} common ping`
