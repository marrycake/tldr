# ghead

> To polecenie jest aliasem GNU `head`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux head`
