# gcut

> To polecenie jest aliasem GNU `cut`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} common cut`
