# gb2sum

> To polecenie jest aliasem GNU `b2sum`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr b2sum`
