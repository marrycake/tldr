# gfold

> To polecenie jest aliasem GNU `fold`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr {{[-p|--platform]}} linux fold`
