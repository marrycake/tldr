# gnumfmt

> To polecenie jest aliasem GNU `numfmt`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr numfmt`
