# pkg

> Menedżer pakietów OpenBSD.
> Więcej informacji: <https://www.openbsd.org/faq/faq15.html>.

- Zobacz dokumentację dotyczącą instalowania/aktualizowania pakietów:

`tldr pkg_add`

- Zobacz dokumentację dotyczącą usuwania pakietów:

`tldr pkg_delete`

- Zobacz dokumentację dotyczącą pokazywania informacji o pakietach:

`tldr pkg_info`
