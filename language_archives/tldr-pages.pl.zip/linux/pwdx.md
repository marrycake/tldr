# pwdx

> Wyświetla katalog roboczy procesu.
> Więcej informacji: <https://manned.org/pwdx>.

- Wyświetlenie aktualnego katalogu roboczego procesu:

`pwdx {{id_procesu}}`
