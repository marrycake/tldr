# wtf

> Pokazuje rozwinięcia akronimów.
> Więcej informacji: <https://manned.org/wtf.6>.

- Rozwinięcie podanego akronimu:

`wtf {{IMO}}`

- Określenie typu wyszukania jako związanego z komputerem:

`wtf -t {{comp}} {{WWW}}`
