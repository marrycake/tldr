# pacman -Q

> To polecenie jest aliasem `pacman --query`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pacman query`
