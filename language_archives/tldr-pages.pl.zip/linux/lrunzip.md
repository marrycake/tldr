# lrunzip

> To polecenie jest aliasem `lrzip -d`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr lrzip`
