# vpnc

> Klient VPN dla Cisco 3000 VPN Concentrator.
> Więcej informacji: <https://manned.org/vpnc>.

- Połącznie przy pomocy zdefiniowanego pliku konfiguracyjnego:

`sudo vpnc {{plik_konfiguracyjny}}`

- Zakończenie wcześniej utworzonego połączenia:

`sudo vpnc-disconnect`
