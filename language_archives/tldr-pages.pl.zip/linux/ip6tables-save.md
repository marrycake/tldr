# ip6tables-save

> To polecenie jest aliasem `iptables-save` dla zapory sieciowej IPv6.

- Zobacz dokumentację oryginalnego polecenia:

`tldr iptables-save`
