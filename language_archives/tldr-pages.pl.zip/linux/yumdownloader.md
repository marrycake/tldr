# yumdownloader

> Program do pobierania pakietów YUM dla instalacji Fedory; obecnie przestarzały.
> To polecenie jest aliasem `dnf download`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr dnf download`
