# fatlabel

> Uzyskaj lub ustaw etykietę partycji FAT32.
> Więcej informacji: <https://manned.org/fatlabel>.

- Uzyskaj etykietę partycji FAT32:

`fatlabel {{/dev/sda1}}`

- Ustaw etykietę partycji FAT32:

`fatlabel {{/dev/sdc3}} "{{nowa_etykieta}}"`
