# lex

> To polecenie jest aliasem `flex`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr flex`
