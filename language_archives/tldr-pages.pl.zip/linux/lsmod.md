# lsmod

> Pokazuje status modułów kernela Linuksa.
> Zobacz także `modprobe`, który ładuje moduły kernela.
> Więcej informacji: <https://manned.org/lsmod>.

- Wyświetlenie aktualnie załadowanych modułów kernela:

`lsmod`
