# pacman -F

> To polecenie jest aliasem `pacman --files`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pacman files`
