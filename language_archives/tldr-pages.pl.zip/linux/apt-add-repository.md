# apt-add-repository

> To polecenie jest aliasem `add-apt-repository`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr add-apt-repository`
