# mate-about

> Pokaż informacje o środowisku desktopowym MATE.
> Więcej informacji: <https://manned.org/mate-about>.

- Wyświetl wersję MATE:

`mate-about --version`
