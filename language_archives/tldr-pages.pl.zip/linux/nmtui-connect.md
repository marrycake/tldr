# nmtui-connect

> To polecenie jest aliasem `nmtui connect`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr nmtui`
