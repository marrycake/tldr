# steamos-boot-install

> To polecenie jest aliasem `steamos-finalize-install`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr steamos-finalize-install`
