# avahi-resolve-address

> To polecenie jest aliasem `avahi-resolve --address`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr avahi-resolve`
