# caffeinate

> Zapobiegaj usypaniu pulpitu.
> Więcej informacji: <https://manned.org/caffeinate>.

- Zapobiegaj usypaniu pulpitu (użyj `<Ctrl c>`, aby wyjść):

`caffeinate`
