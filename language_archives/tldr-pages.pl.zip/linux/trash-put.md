# trash-put

> To polecenie jest aliasem `trash`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr trash`
