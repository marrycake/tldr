# qm importdisk

> To polecenie jest aliasem `qm disk import`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr qm disk import`
