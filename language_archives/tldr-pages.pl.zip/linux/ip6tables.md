# ip6tables

> To polecenie jest aliasem `iptables` dla zapory sieciowej IPv6.

- Zobacz dokumentację oryginalnego polecenia:

`tldr iptables`
