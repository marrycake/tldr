# linux64

> To polecenie jest aliasem `setarch linux64`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr setarch`
