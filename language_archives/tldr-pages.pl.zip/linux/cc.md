# cc

> To polecenie jest aliasem `gcc`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr gcc`
