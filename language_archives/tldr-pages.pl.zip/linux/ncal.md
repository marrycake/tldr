# ncal

> To polecenie jest aliasem `cal`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr cal`
