# pacman -R

> To polecenie jest aliasem `pacman --remove`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pacman remove`
