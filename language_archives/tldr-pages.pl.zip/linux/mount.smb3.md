# mount.smb3

> To polecenie jest aliasem `mount.cifs`.
> Uwaga: dla wersji SMB poniżej 3 musisz użyć `mount.cifs`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr mount.cifs`
