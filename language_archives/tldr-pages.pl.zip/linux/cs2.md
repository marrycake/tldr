# cs2

> To polecenie jest aliasem `counter strike 2`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr counter strike 2`
