# linux32

> To polecenie jest aliasem `setarch linux32`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr setarch`
