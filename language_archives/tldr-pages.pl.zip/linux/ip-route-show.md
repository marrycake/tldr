# ip route show

> To polecenie jest aliasem `ip route list`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr ip route list`
