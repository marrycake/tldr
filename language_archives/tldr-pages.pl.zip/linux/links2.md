# links2

> Tekstowa przeglądarka WWW.
> Zobacz także: `links`.
> Więcej informacji: <http://links.twibright.com/>.

- Odwiedź stronę w trybie graficznym:

`links2 -g {{https://example.com}}`
