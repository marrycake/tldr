# a2disconf

> Wyłącz plik konfiguracyjny Apache w systemach opartych na Debianie.
> Więcej informacji: <https://manned.org/a2disconf.8>.

- Wyłącz plik konfiguracyjny:

`sudo a2disconf {{plik_konfiguracyjny}}`

- Nie pokazuj wiadomości informacyjnych:

`sudo a2disconf --quiet {{plik_konfiguracyjny}}`
