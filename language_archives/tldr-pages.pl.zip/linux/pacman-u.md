# pacman -U

> To polecenie jest aliasem `pacman --upgrade`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pacman upgrade`
