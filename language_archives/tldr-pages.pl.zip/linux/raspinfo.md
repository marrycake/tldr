# raspinfo

> Wyświetla informacje o systemie Raspberry Pi.
> Więcej informacji: <https://github.com/raspberrypi/utils/tree/master/raspinfo>.

- Wyświetlenie informacji o systemie:

`raspinfo`
