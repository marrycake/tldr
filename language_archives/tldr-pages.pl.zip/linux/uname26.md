# uname26

> To polecenie jest aliasem `setarch uname26`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr setarch`
