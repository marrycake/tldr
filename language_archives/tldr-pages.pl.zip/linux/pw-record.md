# pw-record

> To polecenie jest aliasem `pw-cat --record`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pw-cat`
