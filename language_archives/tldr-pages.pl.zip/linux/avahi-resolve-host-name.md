# avahi-resolve-host-name

> To polecenie jest aliasem `avahi-resolve --name`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr avahi-resolve`
