# umount

> Właściwe polecenie to `umount` (u-mount).
> Więcej informacji: <https://manned.org/umount.8>.

- Zobacz dokumentację właściwego polecenia:

`tldr umount`
