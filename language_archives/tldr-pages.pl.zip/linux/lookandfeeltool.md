# lookandfeeltool

> To polecenie jest aliasem `plasma-apply-lookandfeel`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr plasma-apply-lookandfeel`
