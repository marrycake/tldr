# yum config-manager

> To polecenie jest aliasem `dnf config-manager`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr dnf config-manager`
