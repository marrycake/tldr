# systemd-umount

> To polecenie jest aliasem `systemd-mount --umount`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr systemd-mount`
