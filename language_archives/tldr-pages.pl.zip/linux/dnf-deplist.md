# dnf deplist

> To polecenie jest aliasem `dnf repoquery --deplist`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr dnf repoquery`
