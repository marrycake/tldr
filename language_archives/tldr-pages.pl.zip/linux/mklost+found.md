# mklost+found

> Tworzy katalog lost+found.
> Więcej informacji: <https://linux.die.net/man/8/mklost+found>.

- Utwórz katalog `lost+found` w bieżącym katalogu:

`mklost+found`
