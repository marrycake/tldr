# chcpu

> Włącza/wyłącza CPU w systemie.
> Więcej informacji: <https://manned.org/chcpu>.

- Wyłączenie CPU przez podanie listy numerów ID CPU:

`chcpu -d {{1,3}}`

- Włączenie zbioru CPU przez podanie zakresu numerów ID CPU:

`chcpu -e {{1-10}}`
