# pw-play

> To polecenie jest aliasem `pw-cat --playback`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pw-cat`
