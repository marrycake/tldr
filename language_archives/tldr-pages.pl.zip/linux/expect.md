# expect

> Wykonuje skrypty, które dokonują interakcji z programami przyjmującymi dane od użytkownika.
> Więcej informacji: <https://manned.org/expect>.

- Wykonaj skrypt expect z pliku:

`expect {{ścieżka/do/pliku}}`

- Wykonaj podany skrypt expect:

`expect -c "{{polecenia}}"`

- Wejdź do interaktywnego REPL (użyj `exit` lub `<Ctrl d>`, aby wyjść):

`expect -i`
