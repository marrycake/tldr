# batcat

> To polecenie jest aliasem `bat`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr bat`
