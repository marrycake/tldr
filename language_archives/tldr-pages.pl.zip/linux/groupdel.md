# groupdel

> Usuwa istniejącą grupę użytkowników z systemu.
> Zobacz także: `groups`, `groupadd`, `groupmod`.
> Więcej informacji: <https://manned.org/groupdel>.

- Usuń istniejącą grupę użytkowników:

`sudo groupdel {{nazwa_grupy}}`
