# tcpflow

> Przechwytuje ruch TCP do debugowania i analizy.
> Więcej informacji: <https://manned.org/tcpflow>.

- Pokaż wszystkie dane z interfejsu `eth0` i portu `80`:

`tcpflow -c -i {{eth0}} port {{80}}`
