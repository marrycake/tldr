# mkfs.vfat

> To polecenie jest aliasem `mkfs.fat`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr mkfs.fat`
