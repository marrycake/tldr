# insmod

> Dynamicznie ładuj moduły do jądra systemu Linux.
> Więcej informacji: <https://manned.org/insmod>.

- Załaduj moduł jądra do jądra systemu Linux:

`insmod {{ścieżka/do/modułu.ko}}`
