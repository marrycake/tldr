# lrzuntar

> To polecenie jest aliasem `lrztar -d`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr lrztar`
