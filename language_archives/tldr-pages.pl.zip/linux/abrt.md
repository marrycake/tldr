# abrt

> To polecenie jest aliasem `abrt-cli`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr abrt-cli`
