# pacman -T

> To polecenie jest aliasem `pacman --deptest`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pacman deptest`
