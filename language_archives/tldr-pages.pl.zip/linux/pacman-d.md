# pacman -D

> To polecenie jest aliasem `pacman --database`.

- Zobacz dokumentację oryginalnego polecenia:

`tldr pacman database`
