# i7z

> Narzędzie raportujące w czasie rzeczywistym dla CPU Intel (tylko i3, i5 oraz i7).
> Więcej informacji: <https://manned.org/i7z>.

- Uruchomienie i7z (wymaga uruchomienia jako superuser):

`sudo i7z`
