# ypchpass

> Esse comando é um apelido de `chpass`.

- Exibe documentação sobre o comando original:

`tldr chpass`
