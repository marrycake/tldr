# bundler

> Gerenciador de dependências para a linguagem de programação Ruby.
> `bundler` é um nome comum para o comando `bundle`, mas não um comando em si.
> Mais informações: <https://bundler.io/man/bundle.1.html>.

- Veja a documentação para o comando original:

`tldr bundle`
