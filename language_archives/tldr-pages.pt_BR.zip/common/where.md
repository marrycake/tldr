# where

> Reporta todas as instâncias conhecidas do comando.
> Pode ser um executável na variável PATH, um alias, ou um comando builtin do shell.
> Mais informações: <https://zsh.sourceforge.io/Doc/Release/Shell-Builtin-Commands.html>.

- Encontra todas as instâncias de um comando:

`where {{comando}}`
