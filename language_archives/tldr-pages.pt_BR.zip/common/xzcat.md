# xzcat

> Este comando é um apelido de `xz`.

- Exibe documentação sobre o comando original:

`tldr xz`
