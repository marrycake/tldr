# fossil ci

> Este comando é um apelido de `fossil commit`.

- Exibe documentação sobre o comando original:

`tldr fossil commit`
