# tlmgr arch

> Este comando é um apelido de `tlmgr platform`.

- Exibe documentação sobre o comando original:

`tldr tlmgr platform`
