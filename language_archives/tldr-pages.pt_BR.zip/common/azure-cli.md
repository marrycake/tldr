# azure-cli

> Este comando ė um alias(apelido) de `az`.

- Veja a documentação para o comando original:

`tldr az`
