# cmatrix

> Exibe um padrão semelhante à Matrix rolando na tela do terminal.
> Mais informações: <https://github.com/abishekvashok/cmatrix>.

- Habilita rolagem assíncrona:

`cmatrix -a`

- Altera a cor do texto (verde por padrão):

`cmatrix -C {{red}}`

- Habilita modo arco-íris:

`cmatrix -r`

- Usa um atraso de atualização da tela de 100 centissegundos (1 segundo):

`cmatrix -u 100`
