# llvm-objdump

> Este comando é um apelido de `objdump`.

- Exibe documentação sobre o comando original:

`tldr objdump`
