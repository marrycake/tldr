# llvm-nm

> Este comando é um apelido de `nm`.

- Exibe documentação sobre o comando original:

`tldr nm`
