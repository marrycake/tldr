# airpaste

> Compartilhar mensagens e arquivos na mesma rede.
> Mais informações: <https://github.com/mafintosh/airpaste>.

- Espera por mensagens e as mostra quando recebidas:

`airpaste`

- Envia um texto:

`echo {{texto}} | airpaste`

- Envia um arquivo:

`airpaste < {{caminho/para/arquivo}}`

- Recebe um arquivo:

`airpaste > {{caminho/para/arquivo}}`

- Cria/Entra em canal:

`airpaste {{nome_do_canal}}`
