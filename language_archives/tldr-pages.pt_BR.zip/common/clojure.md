# clojure

> Este comando é um apelido de `clj`.

- Exibe documentação sobre o comando original:

`tldr clj`
