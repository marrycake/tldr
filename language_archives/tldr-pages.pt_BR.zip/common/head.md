# head

> Exibe a primeira parte de arquivos.
> Mais informações: <https://manned.org/head.1p>.

- Exibe as primeiras linhas de um arquivo:

`head -n {{número_linhas}} {{caminho/para/arquivo}}`
