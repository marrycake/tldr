# mscore

> Este comando é um apelido de `musescore`.

- Exibe documentação sobre o comando original:

`tldr musescore`
