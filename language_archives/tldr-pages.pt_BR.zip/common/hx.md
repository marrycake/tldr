# hx

> Este comando é um apelido de `helix`.

- Exibe documentação sobre o comando original:

`tldr helix`
