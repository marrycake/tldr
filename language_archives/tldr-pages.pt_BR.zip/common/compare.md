# compare

> Este comando é um alias(apelido) de `magick compare`.
> Use para anotar visualmente e matematicamente a diferença entre uma imagem e sua reconstrução.
> Mais informações: <https://imagemagick.org/script/compare.php>.

- Veja a documentação para o comando original:

`tldr magick compare`
