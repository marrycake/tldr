# batch

> Este comando é um apelido de `at`.
> Mais informações: <https://manned.org/batch>.

- Exibe documentação sobre o comando original:

`tldr at`
