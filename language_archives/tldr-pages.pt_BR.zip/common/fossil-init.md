# fossil init

> Inicializa um novo repositório para um projeto.
> Veja também: `fossil clone`.
> Mais informações: <https://fossil-scm.org/home/help/init>.

- Cria um novo repositório em um arquivo nomeado:

`fossil init {{caminho/para/arquivo}}`
