# blkid

> Lista todas as partições reconhecidas e seu Identificador Único Universal (UUID).
> Mais informações: <https://manned.org/blkid>.

- Lista todas as partições:

`sudo blkid`

- Lista todas as partições em uma tabela, incluindo os pontos de montagem atuais:

`sudo blkid -o list`
