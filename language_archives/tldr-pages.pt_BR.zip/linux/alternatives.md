# alternatives

> Este comando é um apelido de `update-alternatives`.

- Exibe documentação sobre o comando original:

`tldr update-alternatives`
