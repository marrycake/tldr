# a2ensite

> Ativa um host virtual do Apache em sistemas operacionais baseados no Debian.
> Mais informações: <https://manned.org/a2ensite.8>.

- Ativa um host virtual:

`sudo a2ensite {{host_virtual}}`

- Não mostra mensagens informativas:

`sudo a2ensite --quiet {{host_virtual}}`
