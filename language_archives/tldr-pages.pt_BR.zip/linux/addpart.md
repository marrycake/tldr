# addpart

> Informa ao kernel do Linux sobre a existência da partição especificada.
> O comando é um wrapper do ioctl `add partition`.
> Mais informações: <https://manned.org/addpart>.

- Informa ao kernel do Linux sobre a existência da partição especificada:

`addpart {{dispositivo}} {{particao}} {{inicio}} {{tamanho}}`
