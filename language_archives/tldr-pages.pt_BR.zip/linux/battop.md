# battop

> Um visualizador interativo para as baterias instaladas no seu notebook.
> Mais informações: <https://github.com/svartalf/rust-battop>.

- Exibe informações da bateria:

`battop`

- Altera a [u]nidade de medida das informações da bateria (padrão: human):

`battop -u {{human|si}}`
