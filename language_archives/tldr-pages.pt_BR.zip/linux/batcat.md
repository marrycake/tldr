# batcat

> Este comando é um apelido de `bat`.

- Exibe documentação sobre o comando original:

`tldr bat`
