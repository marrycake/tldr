# cmatrix

> Mostra una pantalla similar a la de Matrix en la terminal.
> Més informació: <https://github.com/abishekvashok/cmatrix>.

- Activa el desplaçament asíncron:

`cmatrix -a`

- Mostra el text en vermell:

`cmatrix -C {{red}}`

- Activa el mode multicolor:

`cmatrix -r`

- Estableix el retràs d'actualització de la pantalla a 100 centrisegons (1 segons):

`cmatrix -u 100`
