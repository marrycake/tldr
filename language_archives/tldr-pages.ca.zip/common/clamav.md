# ClamAV

> Programa antivirus de codi obert.
> ClamAV no és una ordre, sinó un conjunt d'ordres.
> Més informació: <https://www.clamav.net>.

- Mostra la pàgina tldr per escanejar fitxers amb el dimoni `clamd`:

`tldr clamdscan`

- Mostra la pàgina tldr per escanejar fitxers sense que s'executi el dimoni `clamd`:

`tldr clamscan`

- Mostra la pàgina tldr per actualitzar les definicions de virus:

`tldr freshclam`
