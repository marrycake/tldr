# ncal

> Aquest comandament és un àlies de `cal`.

- Veure documentació per el comandament original:

`tldr cal`
