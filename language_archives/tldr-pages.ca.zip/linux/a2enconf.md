# a2enconf

> Activa un fitxer de configuració d'Apache en sistemes operatius basats en debian.
> Més informació: <https://manned.org/a2enconf.8>.

- Activa un fitxer de configuració:

`sudo a2enconf {{fitxer_configuració}}`

- No mostris missatges informatius:

`sudo a2enconf --quiet {{fitxer_configuració}}`
