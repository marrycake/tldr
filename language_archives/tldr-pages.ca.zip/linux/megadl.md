# megadl

> Aquest comandament es un àlies de `megatools-dl`.

- Veure documentació per el comandament original:

`tldr megatools-dl`
