# tcpkill

> Mata les conexions TCP en curs especificades.
> Més informació: <https://manned.org/tcpkill>.

- Mata les conexions en curs d'una interfície, màquina i port indicats:

`tcpkill -i {{eth1}} host {{192.95.4.27}} and port {{2266}}`
