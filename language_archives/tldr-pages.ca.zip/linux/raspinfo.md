# raspinfo

> Mostra informació del sistema en una Raspberry Pi.
> Més informació: <https://github.com/raspberrypi/utils/tree/master/raspinfo>.

- Mostra informació del sistema:

`raspinfo`
