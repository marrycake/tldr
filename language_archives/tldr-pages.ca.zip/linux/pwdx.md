# pwdx

> Mostra el directori de treball de un procés.
> Més informació: <https://manned.org/pwdx>.

- Mostra el directori de treball actual de un procés:

`pwdx {{process_id}}`
