# mklost+found

> Crea un directori lost+found.
> Més informació: <https://linux.die.net/man/8/mklost+found>.

- Crea un directori `lost+found` en el directori actual:

`mklost+found`
