# ifdown

> Desactiva interfícies de xarxa.
> Més informació: <https://manned.org/ifdown>.

- Desactiva la interfície eth0:

`ifdown {{eth0}}`

- Desactiva totes les interfícies que estiguin activades:

`ifdown -a`
