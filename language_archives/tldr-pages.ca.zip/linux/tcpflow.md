# tcpflow

> Captura el tràfic TCP per depuració i anàlisi.
> Més informació: <https://manned.org/tcpflow>.

- Mostra totes les dades de la interfície i el port indicats:

`tcpflow -c -i {{eth0}} port {{80}}`
