# cpuid

> Mostra informació detallada sobre totes les CPUs.
> Més informació: <https://manned.org/cpuid.1>.

- Mostra informació de totes les CPUs:

`cpuid`

- Mostra informació només per la CPU actual:

`cpuid {{[-1|--one-cpu]}}`

- Mostra informació hexadecimal en brut sense decodificar:

`cpuid {{[-r|--raw]}}`
