# exit

> Surt de la instància CMD actual o del fitxer per lots actual.
> Més informació: <https://learn.microsoft.com/windows-server/administration/windows-commands/exit>.

- Surt de la instància CMD actual:

`exit`

- Surt del conjunt d'instruccions del fitxer per lots actual:

`exit /b`

- Surt usant un codi de sortida específic:

`exit {{2}}`
