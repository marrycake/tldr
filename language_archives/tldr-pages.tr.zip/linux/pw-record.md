# pw-record

> Bu komut `pw-cat --record` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr pw-cat`
