# pw-play

> Bu komut `pw-cat --playback` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr pw-cat`
