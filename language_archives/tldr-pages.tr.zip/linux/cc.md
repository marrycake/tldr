# cc

> Bu komut `gcc` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr gcc`
