# batcat

> Bu komut `bat` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr bat`
