# wl-paste

> Wayland için panoda saklanan verilere erişim aracı.
> Ayrıca bakın: `wl-copy`.
> Daha fazla bilgi için: <https://github.com/bugaevc/wl-clipboard>.

- Panonun içeriğini yapıştır:

`wl-paste`

- Panonun içeriğini bir dosyaya yaz:

`wl-paste > {{dosya/yolu}}`

- Panonun içeriğini bir komuta aktar:

`wl-paste | {{komut}}`
