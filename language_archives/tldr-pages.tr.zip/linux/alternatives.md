# alternatives

> Bu komut `update-alternatives` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr update-alternatives`
