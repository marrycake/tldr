# ncal

> Bu komut `cal` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr cal`
