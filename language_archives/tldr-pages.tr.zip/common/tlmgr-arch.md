# tlmgr arch

> Bu komut `tlmgr platform` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr tlmgr platform`
