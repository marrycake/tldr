# npm run

> Komut çalıştırır.
> Daha fazla bilgi için: <https://docs.npmjs.com/cli/commands/npm-run-script>.

- Bir komut çalıştırır:

`npm run {{komut_adı}}`

- Komuta argüman gönderir:

`npm run {{komut_adı}} -- {{argüman}} {{--seçenek}}`

- `start` isimli komudu çalıştırır:

`npm start`

- `stop` isimli komudu çalıştırır:

`npm stop`

- `restart` isimli komudu çalıştırır:

`npm restart`

- `test` isimli komudu çalıştırır:

`npm test`
