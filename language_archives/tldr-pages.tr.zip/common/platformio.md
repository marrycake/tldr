# platformio

> Bu komut `pio` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr pio`
