# cola

> Bu komut `git-cola` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr git-cola`
