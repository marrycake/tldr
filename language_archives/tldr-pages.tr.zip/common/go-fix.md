# go fix

> Yeni API'ler kullanmak için paketleri güncelle.
> Daha fazla bilgi için: <https://pkg.go.dev/cmd/go#hdr-Update_packages_to_use_new_APIs>.

- Paketleri yeni API'ler kullanmak için güncelle:

`go fix {{paketler}}`
