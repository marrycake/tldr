# npm start

> Bu komut `npm run start` komutunun bir takma addır.

- Asıl komutun dökümantasyonunu görüntüleyin:

`tldr npm run`
