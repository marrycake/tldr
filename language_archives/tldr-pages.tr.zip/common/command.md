# command

> Command, kabuğu bir programı herhangi bir fonksiyon ve gömülü özelliğe ve alias'a takılmadan çalıştırmaya zorlar.
> Daha fazla bilgi için: <https://manned.org/command>.

- `ls` programını aynı isimde bir alias olsa dahi çalıştır:

`command {{ls}}`

- Alias'a atanan özel komutu veya çalıştırılabilir dosyanın yolunu göster:

`command -v {{komut_ismi}}`
