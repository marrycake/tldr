# llvm-objdump

> Bu komut `objdump` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr objdump`
