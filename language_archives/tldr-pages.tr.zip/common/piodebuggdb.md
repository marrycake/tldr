# piodebuggdb

> Bu komut `pio debug` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr pio debug`
