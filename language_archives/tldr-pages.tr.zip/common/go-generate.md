# go generate

> Kaynak dosyaları içinde komut çalıştırarak Go dosyaları oluştur.
> Daha fazla bilgi için: <https://pkg.go.dev/cmd/go#hdr-Generate_Go_files_by_processing_source>.

- Kaynak dosyaları içinde komut çalıştırarak Go dosyaları oluştur:

`go generate`
