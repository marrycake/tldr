# git stage

> Bu komut `git add` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr git add`
