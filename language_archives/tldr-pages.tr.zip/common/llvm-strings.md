# llvm-strings

> Bu komut `strings` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr strings`
