# pio init

> Bu komut `pio project` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr pio project`
