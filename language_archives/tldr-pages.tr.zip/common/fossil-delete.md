# fossil delete

> Bu komut `fossil rm` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr fossil rm`
