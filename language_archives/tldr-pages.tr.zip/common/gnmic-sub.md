# gnmic sub

> Bu komut `gnmic subscribe` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr gnmic subscribe`
