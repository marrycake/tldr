# gh cs

> Bu komut `gh codespace` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr gh codespace`
