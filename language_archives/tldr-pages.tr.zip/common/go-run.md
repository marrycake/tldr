# go run

> Binary (ikili sayı değeri) kaydetmeden Go kodunu derle ve çalıştır.
> Daha fazla bilgi için: <https://pkg.go.dev/cmd/go#hdr-Compile_and_run_Go_program>.

- Bir Go dosyası çalıştır:

`go run {{örnek/konum/dosya.go}}`

- Ana bir Go paketi çalıştır:

`go run {{örnek/konum/paket}}`
