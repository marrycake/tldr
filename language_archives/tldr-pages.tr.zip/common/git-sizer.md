# git-sizer

> Git depo boyut metriklerini hesaplar ve problem veya rahatsızlığa sebep olabilecek boyutlarda uyarı verir.
> Daha fazla bilgi için: <https://github.com/github/git-sizer>.

- 0'dan büyük önem içeren istatistikleri raporla:

`git-sizer`

- Tüm istatistikleri raporla:

`git-sizer -v`

- İlave seçenekleri gör:

`git-sizer -h`
