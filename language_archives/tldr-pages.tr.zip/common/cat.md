# cat

> Dosyaları yazdır ve birleştir.
> Daha fazla bilgi için: <https://manned.org/cat.1posix>.

- Bir dosyanın içeriğini standart çıktıya yazdır:

`cat {{dosya/yolu}}`

- Birkaç dosyayı bir çıktı dosyasında birleştir:

`cat {{dosya/yolu1 dosya/yolu2 ...}} > {{çıktı/dosyası/yolu}}`

- Birkaç dosyayı bir çıktı dosyasına ekle:

`cat {{dosya/yolu1 dosya/yolu2 ...}} >> {{çıktı/dosyası/yolu}}`
