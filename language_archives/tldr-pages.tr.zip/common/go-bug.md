# go bug

> Bug bildir.
> Daha fazla bilgi için: <https://pkg.go.dev/cmd/go#hdr-Start_a_bug_report>.

- Bug bildirisini başlatmak için bir website aç:

`go bug`
