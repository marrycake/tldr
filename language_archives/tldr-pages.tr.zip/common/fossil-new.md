# fossil new

> Bu komut `fossil init` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr fossil init`
