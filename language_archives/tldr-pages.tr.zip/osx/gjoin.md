# gjoin

> Bu komut `join` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr join`
