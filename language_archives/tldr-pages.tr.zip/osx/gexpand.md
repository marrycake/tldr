# gexpand

> Bu komut `expand` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr expand`
