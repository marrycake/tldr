# grm

> Bu komut `rm` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr rm`
