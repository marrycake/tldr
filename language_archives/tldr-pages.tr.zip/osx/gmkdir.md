# gmkdir

> Bu komut `mkdir` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr mkdir`
