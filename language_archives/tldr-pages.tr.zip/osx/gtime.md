# gtime

> Bu komut `time` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr time`
