# gtty

> Bu komut `tty` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr tty`
