# gpathchk

> Bu komut `pathchk` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr pathchk`
