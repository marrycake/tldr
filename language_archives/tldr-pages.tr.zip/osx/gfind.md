# gfind

> Bu komut `find` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr find`
