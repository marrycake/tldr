# ginstall

> Bu komut `install` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr install`
