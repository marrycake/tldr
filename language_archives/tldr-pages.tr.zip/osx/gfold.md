# gfold

> Bu komut `-p linux fold` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} linux fold`
