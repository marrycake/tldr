# gsha512sum

> Bu komut `sha512sum` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr sha512sum`
