# gchown

> Bu komut `chown` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr chown`
