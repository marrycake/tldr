# gmv

> Bu komut `mv` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr mv`
