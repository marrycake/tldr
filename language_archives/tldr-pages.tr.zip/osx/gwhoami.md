# gwhoami

> Bu komut `whoami` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr whoami`
