# gegrep

> Bu komut `egrep` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr egrep`
