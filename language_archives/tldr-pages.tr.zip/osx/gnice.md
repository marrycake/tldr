# gnice

> Bu komut `nice` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr nice`
