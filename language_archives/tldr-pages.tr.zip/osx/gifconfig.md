# gifconfig

> Bu komut `ifconfig` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr ifconfig`
