# gtruncate

> Bu komut `truncate` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr truncate`
