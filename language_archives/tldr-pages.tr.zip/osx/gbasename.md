# gbasename

> Bu komut `basename` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr basename`
