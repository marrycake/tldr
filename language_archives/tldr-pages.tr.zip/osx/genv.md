# genv

> Bu komut `env` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr env`
