# gsha224sum

> Bu komut `sha224sum` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr sha224sum`
