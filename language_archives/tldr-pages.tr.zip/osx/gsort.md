# gsort

> Bu komut `sort` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr sort`
