# gls

> Bu komut `ls` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr ls`
