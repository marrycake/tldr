# gtraceroute

> Bu komut `traceroute` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr traceroute`
