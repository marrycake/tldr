# ghostname

> Bu komut `hostname` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr hostname`
