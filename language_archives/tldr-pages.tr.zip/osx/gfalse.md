# gfalse

> Bu komut `false` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr false`
