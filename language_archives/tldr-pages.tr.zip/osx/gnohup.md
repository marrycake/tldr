# gnohup

> Bu komut `nohup` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr nohup`
