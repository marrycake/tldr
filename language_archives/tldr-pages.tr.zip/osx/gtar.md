# gtar

> Bu komut `tar` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr tar`
