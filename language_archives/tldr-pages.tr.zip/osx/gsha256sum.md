# gsha256sum

> Bu komut `sha256sum` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr sha256sum`
