# gsha384sum

> Bu komut `sha384sum` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr sha384sum`
