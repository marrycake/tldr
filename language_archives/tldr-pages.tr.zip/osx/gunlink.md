# gunlink

> Bu komut `unlink` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr unlink`
