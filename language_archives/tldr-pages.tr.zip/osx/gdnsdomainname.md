# gdnsdomainname

> Bu komut `-p linux dnsdomainname` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} linux dnsdomainname`
