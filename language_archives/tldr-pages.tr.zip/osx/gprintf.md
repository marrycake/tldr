# gprintf

> Bu komut `printf` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr printf`
