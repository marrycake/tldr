# glogger

> Bu komut `-p linux logger` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} linux logger`
