# gsleep

> Bu komut `-p linux sleep` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} linux sleep`
