# gunexpand

> Bu komut `unexpand` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr unexpand`
