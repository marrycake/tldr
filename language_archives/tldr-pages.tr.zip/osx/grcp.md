# grcp

> Bu komut `-p linux rcp` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} linux rcp`
