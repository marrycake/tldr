# gprintenv

> Bu komut `printenv` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr printenv`
