# gxargs

> Bu komut `xargs` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr xargs`
