# gpinky

> Bu komut `pinky` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr pinky`
