# gfmt

> Bu komut `fmt` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr fmt`
