# gruncon

> Bu komut `-p linux runcon` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} linux runcon`
