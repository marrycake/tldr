# gtest

> Bu komut `test` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr test`
