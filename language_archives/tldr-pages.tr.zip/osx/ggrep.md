# ggrep

> Bu komut `grep` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr grep`
