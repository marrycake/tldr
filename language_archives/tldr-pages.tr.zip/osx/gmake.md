# gmake

> Bu komut `make` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr make`
