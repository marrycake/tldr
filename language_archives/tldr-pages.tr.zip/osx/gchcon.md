# gchcon

> Bu komut `-p linux chcon` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} linux chcon`
