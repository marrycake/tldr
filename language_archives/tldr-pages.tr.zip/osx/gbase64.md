# gbase64

> Bu komut `base64` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} common base64`
