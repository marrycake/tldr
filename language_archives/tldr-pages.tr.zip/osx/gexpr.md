# gexpr

> Bu komut `expr` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr expr`
