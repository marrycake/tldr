# guniq

> Bu komut `uniq` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr uniq`
