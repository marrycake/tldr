# gwho

> Bu komut `who` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr who`
