# gtimeout

> Bu komut `timeout` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr timeout`
