# gcomm

> Bu komut `comm` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr comm`
