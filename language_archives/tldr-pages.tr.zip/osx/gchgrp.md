# gchgrp

> Bu komut `chgrp` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr chgrp`
