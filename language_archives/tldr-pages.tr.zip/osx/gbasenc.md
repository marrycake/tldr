# gbasenc

> Bu komut `basenc` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr basenc`
