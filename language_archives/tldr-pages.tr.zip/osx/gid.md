# gid

> Bu komut `id` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr id`
