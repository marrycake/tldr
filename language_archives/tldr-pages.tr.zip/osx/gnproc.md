# gnproc

> Bu komut `nproc` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr nproc`
