# gpr

> Bu komut `pr` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr pr`
