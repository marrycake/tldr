# gtr

> Bu komut `tr` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr tr`
