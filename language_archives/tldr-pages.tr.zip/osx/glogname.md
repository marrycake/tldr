# glogname

> Bu komut `logname` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr logname`
