# gmd5sum

> Bu komut `md5sum` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr md5sum`
