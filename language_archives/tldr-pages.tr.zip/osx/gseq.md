# gseq

> Bu komut `seq` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr seq`
