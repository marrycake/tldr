# gyes

> Bu komut `yes` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr yes`
