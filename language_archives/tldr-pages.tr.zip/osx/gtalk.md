# gtalk

> Bu komut `-p linux talk` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} linux talk`
