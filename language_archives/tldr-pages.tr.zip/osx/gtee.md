# gtee

> Bu komut `tee` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr tee`
