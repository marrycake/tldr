# gstty

> Bu komut `stty` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr stty`
