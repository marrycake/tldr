# gcksum

> Bu komut `cksum` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr cksum`
