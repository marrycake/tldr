# gsync

> Bu komut `sync` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr sync`
