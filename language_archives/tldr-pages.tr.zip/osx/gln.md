# gln

> Bu komut `ln` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr ln`
