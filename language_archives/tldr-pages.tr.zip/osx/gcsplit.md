# gcsplit

> Bu komut `-p linux csplit` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} linux csplit`
