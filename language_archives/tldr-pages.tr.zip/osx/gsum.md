# gsum

> Bu komut `sum` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr sum`
