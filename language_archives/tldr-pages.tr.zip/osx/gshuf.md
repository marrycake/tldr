# gshuf

> Bu komut `shuf` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} coomon shuf`
