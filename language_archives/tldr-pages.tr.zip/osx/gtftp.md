# gtftp

> Bu komut `-p linux tftp` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} linux tftp`
