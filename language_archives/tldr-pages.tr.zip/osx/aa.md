# aa

> Bu komut `yaa` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr yaa`
