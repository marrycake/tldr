# gchroot

> Bu komut `chroot` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr chroot`
