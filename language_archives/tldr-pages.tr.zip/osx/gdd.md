# gdd

> Bu komut `-p linux dd` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} linux dd`
