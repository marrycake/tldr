# gb2sum

> Bu komut `b2sum` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr b2sum`
