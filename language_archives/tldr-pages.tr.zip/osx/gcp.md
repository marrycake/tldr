# gcp

> Bu komut `cp` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr cp`
