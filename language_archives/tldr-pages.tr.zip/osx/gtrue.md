# gtrue

> Bu komut `true` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr true`
