# gtsort

> Bu komut `tsort` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr tsort`
