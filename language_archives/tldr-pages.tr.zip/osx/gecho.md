# gecho

> Bu komut `echo` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr echo`
