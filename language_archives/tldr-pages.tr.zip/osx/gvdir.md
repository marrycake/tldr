# gvdir

> Bu komut `vdir` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr vdir`
