# gunits

> Bu komut `units` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr units`
