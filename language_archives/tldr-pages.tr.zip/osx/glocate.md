# glocate

> Bu komut `-p linux locate` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} linux locate`
