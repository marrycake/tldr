# ged

> Bu komut `ed` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr ed`
