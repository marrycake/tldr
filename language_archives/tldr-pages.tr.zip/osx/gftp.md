# gftp

> Bu komut `ftp` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr ftp`
