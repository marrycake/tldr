# gping6

> Bu komut `ping6` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr ping6`
