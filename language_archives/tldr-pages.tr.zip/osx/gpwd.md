# gpwd

> Bu komut `pwd` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr pwd`
