# gnumfmt

> Bu komut `numfmt` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr numfmt`
