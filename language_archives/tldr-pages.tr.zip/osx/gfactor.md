# gfactor

> Bu komut `factor` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr factor`
