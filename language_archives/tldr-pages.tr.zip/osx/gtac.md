# gtac

> Bu komut `tac` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr tac`
