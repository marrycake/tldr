# gmkfifo

> Bu komut `mkfifo` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr mkfifo`
