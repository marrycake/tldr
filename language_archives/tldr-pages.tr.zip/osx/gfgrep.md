# gfgrep

> Bu komut `fgrep` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr fgrep`
