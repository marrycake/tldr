# gwhich

> Bu komut `which` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr which`
