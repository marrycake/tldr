# gstdbuf

> Bu komut `stdbuf` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr stdbuf`
