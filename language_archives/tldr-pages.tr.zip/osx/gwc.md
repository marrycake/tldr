# gwc

> Bu komut `wc` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} common wc`
