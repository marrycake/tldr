# gbase32

> Bu komut `base32` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr base32`
