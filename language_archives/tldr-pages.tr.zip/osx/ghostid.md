# ghostid

> Bu komut `hostid` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr hostid`
