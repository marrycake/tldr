# gdirname

> Bu komut `dirname` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr dirname`
