# gpaste

> Bu komut `paste` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr paste`
