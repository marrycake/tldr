# guptime

> Bu komut `uptime` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} common uptime`
