# glibtool

> Bu komut `-p linux libtool` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr {{[-p|--platform]}} linux libtool`
