# cuninst

> Bu komut `choco uninstall` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr choco uninstall`
