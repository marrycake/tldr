# chrome

> Bu komut `chromium` için bir takma addır.
> Daha fazla bilgi için: <https://chrome.google.com>.

- Asıl komutun belgelerini görüntüleyin:

`tldr chromium`
