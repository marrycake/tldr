# cpush

> Bu komut `choco push` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr choco push`
