# pwsh where

> Bu komut `Where-Object` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr Where-Object`
