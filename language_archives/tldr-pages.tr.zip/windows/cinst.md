# cinst

> Bu komut `choco install` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr choco install`
