# iwr

> Bu komut `invoke-webrequest` için bir takma addır.

- Asıl komutun belgelerini görüntüleyin:

`tldr invoke-webrequest`
