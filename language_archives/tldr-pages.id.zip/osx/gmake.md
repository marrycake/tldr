# gmake

> Perintah ini merupakan alias dari `make`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr make`
