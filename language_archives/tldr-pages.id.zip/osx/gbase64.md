# gbase64

> Perintah ini merupakan alias dari `base64`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr {{[-p|--platform]}} common base64`
