# gls

> Perintah ini merupakan alias dari `ls`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr ls`
