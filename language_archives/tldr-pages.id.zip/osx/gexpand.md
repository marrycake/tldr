# gexpand

> Perintah ini merupakan alias dari `expand`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr expand`
