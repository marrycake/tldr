# gfactor

> Perintah ini merupakan alias dari `factor`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr factor`
