# gchgrp

> Perintah ini merupakan alias dari `chgrp`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr chgrp`
