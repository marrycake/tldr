# gfgrep

> Perintah ini merupakan alias dari `fgrep`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr fgrep`
