# ggroups

> Perintah ini merupakan alias dari `groups`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr groups`
