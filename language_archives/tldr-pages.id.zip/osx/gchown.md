# gchown

> Perintah ini merupakan alias dari `chown`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr chown`
