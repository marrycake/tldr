# gcsplit

> Perintah ini merupakan alias dari `-p linux csplit`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr {{[-p|--platform]}} linux csplit`
