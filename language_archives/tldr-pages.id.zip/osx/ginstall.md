# ginstall

> Perintah ini merupakan alias dari `install`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr install`
