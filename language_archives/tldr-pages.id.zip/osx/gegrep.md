# gegrep

> Perintah ini merupakan alias dari `egrep`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr egrep`
