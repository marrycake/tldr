# gmktemp

> Perintah ini merupakan alias dari `-p linux mktemp`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr {{[-p|--platform]}} linux mktemp`
