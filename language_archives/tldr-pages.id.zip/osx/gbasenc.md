# gbasenc

> Perintah ini merupakan alias dari `basenc`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr basenc`
