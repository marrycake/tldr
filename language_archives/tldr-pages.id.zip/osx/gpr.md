# gpr

> Perintah ini merupakan alias dari `pr`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr pr`
