# ggrep

> Perintah ini merupakan alias dari `grep`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr grep`
