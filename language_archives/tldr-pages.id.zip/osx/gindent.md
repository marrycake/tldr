# gindent

> Perintah ini merupakan alias dari `indent`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr {{[-p|--platform]}} common indent`
