# glink

> Perintah ini merupakan alias dari `link`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr link`
