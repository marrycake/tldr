# gcp

> Perintah ini merupakan alias dari `cp`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr cp`
