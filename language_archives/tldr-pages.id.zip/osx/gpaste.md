# gpaste

> Perintah ini merupakan alias dari `paste`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr paste`
