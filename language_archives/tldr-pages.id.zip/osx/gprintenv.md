# gprintenv

> Perintah ini merupakan alias dari `printenv`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr printenv`
