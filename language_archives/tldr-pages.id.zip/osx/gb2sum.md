# gb2sum

> Perintah ini merupakan alias dari `b2sum`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr b2sum`
