# gmkdir

> Perintah ini merupakan alias dari `mkdir`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr mkdir`
