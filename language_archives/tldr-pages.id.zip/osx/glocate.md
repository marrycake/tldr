# glocate

> Perintah ini merupakan alias dari `-p linux locate`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr {{[-p|--platform]}} linux locate`
