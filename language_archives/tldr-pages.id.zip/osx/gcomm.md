# gcomm

> Perintah ini merupakan alias dari `comm`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr comm`
