# gln

> Perintah ini merupakan alias dari `ln`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr ln`
