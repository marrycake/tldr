# gchroot

> Perintah ini merupakan alias dari `chroot`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr chroot`
