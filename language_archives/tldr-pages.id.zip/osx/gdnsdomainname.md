# gdnsdomainname

> Perintah ini merupakan alias dari `-p linux dnsdomainname`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr {{[-p|--platform]}} linux dnsdomainname`
