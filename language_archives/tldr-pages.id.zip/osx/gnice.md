# gnice

> Perintah ini merupakan alias dari `nice`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr nice`
