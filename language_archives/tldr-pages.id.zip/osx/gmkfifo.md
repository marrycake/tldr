# gmkfifo

> Perintah ini merupakan alias dari `mkfifo`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr mkfifo`
