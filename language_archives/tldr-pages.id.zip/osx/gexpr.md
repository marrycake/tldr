# gexpr

> Perintah ini merupakan alias dari `expr`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr expr`
