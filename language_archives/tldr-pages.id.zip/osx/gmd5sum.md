# gmd5sum

> Perintah ini merupakan alias dari `md5sum`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr md5sum`
