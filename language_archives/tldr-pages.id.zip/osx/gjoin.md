# gjoin

> Perintah ini merupakan alias dari `join`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr join`
