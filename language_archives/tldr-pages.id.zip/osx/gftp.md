# gftp

> Perintah ini merupakan alias dari `ftp`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr ftp`
