# gnl

> Perintah ini merupakan alias dari `-p linux nl`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr {{[-p|--platform]}} linux nl`
