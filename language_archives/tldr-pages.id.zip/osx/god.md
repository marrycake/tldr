# god

> Perintah ini merupakan alias dari `od`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr od`
