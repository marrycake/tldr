# gping

> Perintah ini merupakan alias dari `ping`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr {{[-p|--platform]}} common ping`
