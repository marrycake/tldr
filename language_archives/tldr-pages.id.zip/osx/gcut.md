# gcut

> Perintah ini merupakan alias dari `cut`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr {{[-p|--platform]}} common cut`
