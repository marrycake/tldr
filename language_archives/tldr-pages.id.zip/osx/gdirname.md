# gdirname

> Perintah ini merupakan alias dari `dirname`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr dirname`
