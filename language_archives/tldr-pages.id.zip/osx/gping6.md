# gping6

> Perintah ini merupakan alias dari `ping6`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr ping6`
