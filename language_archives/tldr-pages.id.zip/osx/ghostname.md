# ghostname

> Perintah ini merupakan alias dari `hostname`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr hostname`
