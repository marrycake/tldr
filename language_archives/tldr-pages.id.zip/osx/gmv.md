# gmv

> Perintah ini merupakan alias dari `mv`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr mv`
