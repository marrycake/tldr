# gfind

> Perintah ini merupakan alias dari `find`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr find`
