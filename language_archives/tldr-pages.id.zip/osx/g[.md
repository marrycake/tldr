# g[

> Perintah ini merupakan alias dari `[`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr [`
