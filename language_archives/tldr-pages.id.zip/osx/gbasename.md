# gbasename

> Perintah ini merupakan alias dari `basename`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr basename`
