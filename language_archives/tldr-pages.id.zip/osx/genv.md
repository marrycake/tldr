# genv

> Perintah ini merupakan alias dari `env`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr env`
