# gchmod

> Perintah ini merupakan alias dari `chmod`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr chmod`
