# gnumfmt

> Perintah ini merupakan alias dari `numfmt`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr numfmt`
