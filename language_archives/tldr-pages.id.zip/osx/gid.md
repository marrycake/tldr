# gid

> Perintah ini merupakan alias dari `id`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr id`
