# gcksum

> Perintah ini merupakan alias dari `cksum`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr cksum`
