# gfalse

> Perintah ini merupakan alias dari `false`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr false`
