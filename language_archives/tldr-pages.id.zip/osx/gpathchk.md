# gpathchk

> Perintah ini merupakan alias dari `pathchk`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr pathchk`
