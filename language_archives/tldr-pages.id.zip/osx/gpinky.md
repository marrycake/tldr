# gpinky

> Perintah ini merupakan alias dari `pinky`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr pinky`
