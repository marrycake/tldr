# gdate

> Perintah ini merupakan alias dari `date`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr {{[-p|--platform]}} common date`
