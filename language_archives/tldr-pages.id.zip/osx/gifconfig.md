# gifconfig

> Perintah ini merupakan alias dari `ifconfig`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr ifconfig`
