# gnohup

> Perintah ini merupakan alias dari `nohup`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr nohup`
