# glogname

> Perintah ini merupakan alias dari `logname`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr logname`
