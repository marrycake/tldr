# ghostid

> Perintah ini merupakan alias dari `hostid`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr hostid`
