# gdircolors

> Perintah ini merupakan alias dari `dircolors`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr dircolors`
