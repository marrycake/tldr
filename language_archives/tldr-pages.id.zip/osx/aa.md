# aa

> Perintah ini merupakan alias dari `yaa`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr yaa`
