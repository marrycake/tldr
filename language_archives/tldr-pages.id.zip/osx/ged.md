# ged

> Perintah ini merupakan alias dari `ed`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr ed`
