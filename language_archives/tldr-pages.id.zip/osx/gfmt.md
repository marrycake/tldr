# gfmt

> Perintah ini merupakan alias dari `fmt`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr fmt`
