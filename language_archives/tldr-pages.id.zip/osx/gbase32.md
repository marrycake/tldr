# gbase32

> Perintah ini merupakan alias dari `base32`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr base32`
