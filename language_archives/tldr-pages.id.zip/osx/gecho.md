# gecho

> Perintah ini merupakan alias dari `echo`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr echo`
