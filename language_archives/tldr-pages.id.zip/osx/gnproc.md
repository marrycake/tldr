# gnproc

> Perintah ini merupakan alias dari `nproc`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr nproc`
