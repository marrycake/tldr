# gprintf

> Perintah ini merupakan alias dari `printf`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr printf`
