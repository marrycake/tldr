# brave

> Perintah ini merupakan alias dari `chromium`.
> Informasi lebih lanjut: <https://support.brave.com/hc/en-us/articles/360044860011-How-Do-I-Use-Command-Line-Flags-in-Brave>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr chromium`
