# git archive-file

> Ekspor seluruh file pada cabang Git saat ini menjadi sebuah file arsip zip.
> Bagian dari `git-extras`.
> Informasi lebih lanjut: <https://github.com/tj/git-extras/blob/master/Commands.md#git-archive-file>.

- Masukkan seluruh file pada komit yang sedang diperiksa ke dalam suatu file arsip zip:

`git archive-file`
