# vue

> CLI serba guna untuk Vue.js.
> Beberapa subperintah seperti `build` mempunyai dokumentasi terpisah.
> Informasi lebih lanjut: <https://cli.vuejs.org/guide/>.

- Buat proyek vue baru secara interaktif:

`vue create {{nama_proyek}}`

- Buat proyek baru dengan antar muka web:

`vue ui`
