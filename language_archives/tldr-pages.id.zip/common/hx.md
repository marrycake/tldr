# hx

> Perintah ini merupakan alias dari `helix`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr helix`
