# pio init

> Perintah ini merupakan alias dari `pio project`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr pio project`
