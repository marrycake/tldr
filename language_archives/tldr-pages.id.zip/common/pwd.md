# pwd

> Mencetak nama dari direktori saat ini/kerja.
> Informasi lebih lanjut: <https://www.gnu.org/software/coreutils/manual/html_node/pwd-invocation.html>.

- Mencetak direktori saat ini:

`pwd`

- Mencetak direktori saat ini, dan menjelaskan semua tautan simbolis (dengan kata lain menampilkan alamat fisik):

`pwd {{[-P|--physical]}}`
