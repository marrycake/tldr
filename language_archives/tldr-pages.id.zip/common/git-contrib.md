# git contrib

> Tampilkan daftar komit yang ditulis oleh penulis tertentu.
> Bagian dari `git extras`.
> Informasi lebih lanjut: <https://github.com/tj/git-extras/blob/master/Commands.md#git-contrib>.

- Tampilkan daftar seluruh komit, beserta kode hash dan pesan, dari suatu penulis:

`git contrib {{penulis}}`
