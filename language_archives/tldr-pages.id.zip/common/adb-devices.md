# adb devices

> Tampilkan daftar perangkat Android yang terhubung.
> Informasi lebih lanjut: <https://manned.org/adb>.

- Tampilkan daftar seluruh perangkat yang terhubung:

`adb devices`

- Tampilkan pula informasi sistem bagi setiap perangkat terhubung:

`adb devices -l`
