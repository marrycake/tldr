# afconvert

> Ubah format file antara AFF dan file baku/raw.
> Informasi lebih lanjut: <https://manned.org/afconvert.1>.

- Pakai nama ekstensi output (default: `aff`):

`afconvert -a {{ekstensi}} {{jalan/menuju/file_input}} {{jalan/menuju/file_output1 jalan/menuju/file_output2 ...}}`

- Gunakan tingkat kompresi file (default: `7`):

`afconvert -X{{0..7}} {{jalan/menuju/file_input}} {{jalan/menuju/file_output1 jalan/menuju/file_output2 ...}}`
