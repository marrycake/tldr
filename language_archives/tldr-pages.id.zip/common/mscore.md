# mscore

> Perintah ini merupakan alias dari `musescore`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr musescore`
