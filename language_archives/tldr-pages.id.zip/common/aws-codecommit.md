# aws codecommit

> Layanan kontrol sumber terkelola yang menghosting repositori Git pribadi.
> Informasi lebih lanjut: <https://docs.aws.amazon.com/cli/latest/reference/codecommit/>.

- Tampilkan bantuan umum:

`aws codecommit help`

- Tampilkan bantuan bagi suatu perintah:

`aws codecommit {{perintah}} help`
