# fossil ci

> Perintah ini merupakan alias dari `fossil commit`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr fossil commit`
