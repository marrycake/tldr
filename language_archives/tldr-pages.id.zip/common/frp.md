# frp

> Fast Reverse Proxy: atur kanal terowongan jaringan komputer untuk dapat mengekspos sebagian layanan komputer peladen menuju Internet atau jaringan komputer lainnya.
> Informasi lebih lanjut: <https://github.com/fatedier/frp>.

- Lihat dokumentasi untuk `frpc`, program klien untuk jaringan `frp`:

`tldr frpc`

- Lihat dokumentasi untuk `frps`, program peladen/server jaringan `frp`:

`tldr frps`
