# ClamAV

> Program antivirus bersumber terbuka (open-source).
> Program ClamAV memiliki beberapa perintah, dan `clamav` bukanlah nama perintah.
> Informasi lebih lanjut: <https://www.clamav.net>.

- Tampilkan dokumentasi perintah untuk memindai file menggunakan daemon ClamAV (`clamd`):

`tldr clamdscan`

- Tampilkan dokumentasi perintah untuk memindai file tanpa menggunakan daemon:

`tldr clamscan`

- Tampilkan dokumentasi perintah untuk memutakhirkan basis data (database) definisi virus:

`tldr freshclam`
