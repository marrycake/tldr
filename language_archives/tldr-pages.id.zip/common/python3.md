# python3

> Perintah ini merupakan alias dari `python`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr python`
