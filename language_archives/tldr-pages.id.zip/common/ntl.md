# ntl

> Perintah ini merupakan alias dari `netlify`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr netlify`
