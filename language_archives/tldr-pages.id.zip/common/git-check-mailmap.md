# git check-mailmap

> Tampilkan nama kanonikal dan alamat surel/email dalam kontak yang disimpan dalam Git.
> Informasi lebih lanjut: <https://git-scm.com/docs/git-check-mailmap>.

- Temukan nama kanonikal dari alamat surel/email yang dimasukkan:

`git check-mailmap "<{{email@example.com}}>"`
