# anytopnm

> Ubah format gambar apapun menuju format gambar umum.
> Informasi lebih lanjut: <https://netpbm.sourceforge.net/doc/anytopnm.html>.

- Ubah suatu gambar dari format apapun menuju format PBM, PGM, atau PPM:

`anytopnm {{jalan/menuju/input}} > {{jalan/menuju/output.pnm}}`

- Tampilkan informasi versi:

`anytopnm -version`
