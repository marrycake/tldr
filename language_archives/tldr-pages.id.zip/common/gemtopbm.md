# gemtopbm

> Perintah ini telah digantikan oleh `gemtopnm`.
> Informasi lebih lanjut: <https://netpbm.sourceforge.net/doc/gemtopbm.html>.

- Lihat dokumentasi untuk perintah terkini:

`tldr gemtopnm`
