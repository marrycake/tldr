# amass

> Alat Pemetaan Permukaan Serangan dan Penemuan Aset yang mendalam.
> Beberapa subperintah seperti `amass intel` mempunyai dokumentasi terpisah.
> Informasi lebih lanjut: <https://github.com/owasp-amass/amass>.

- Jalankan suatu subperintah Amass:

`amass {{intel|enum}} {{opsi}}`

- Tampilkan informasi bantuan umum:

`amass -help`

- Tampilkan informasi bantuan untuk subperintah Amass:

`amass {{intel|enum}} -help`

- Tampilkan informasi versi:

`amass -version`
