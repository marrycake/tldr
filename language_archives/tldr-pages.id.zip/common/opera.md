# opera

> Perintah ini merupakan alias dari `chromium`.
> Informasi lebih lanjut: <https://opera.com>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr chromium`
