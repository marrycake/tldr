# git clear-soft

> Hapus direktori kerja Git tidak termasuk file di `.gitignore`, seolah-olah baru saja dikloning dengan cabang saat ini.
> Bagian dari `git-extras`.
> Informasi lebih lanjut: <https://github.com/tj/git-extras/blob/master/Commands.md#git-clear-soft>.

- Reset semua file yang terlacak dan hapus semua file yang tidak terlacak:

`git clear-soft`
