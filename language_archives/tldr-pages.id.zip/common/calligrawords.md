# calligrawords

> Aplikasi pengolah dokumen teks, bagian dari Calligra.
> Lihat juga: `calligraflow`, `calligrastage`, `calligrasheets`.
> Informasi lebih lanjut: <https://manned.org/calligrawords>.

- Buka aplikasi pengolah dokumen teks:

`calligrawords`

- Buka suatu berkas:

`calligrawords {{jalan/menuju/berkas}}`

- Tampilkan informasi bantuan atau versi aplikasi:

`calligrawords --{{help|version}}`
