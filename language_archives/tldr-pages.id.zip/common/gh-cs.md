# gh cs

> Perintah ini merupakan alias dari `gh codespace`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr gh codespace`
