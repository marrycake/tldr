# git brv

> Tampilkan daftar cabang yang diurutkan berdasarkan tanggal komit terkini.
> Bagian dari `git-extras`.
> Informasi lebih lanjut: <https://github.com/tj/git-extras/blob/master/Commands.md#git-brv>.

- Tampilkan dan urutkan setiap cabang, beserta informasi tanggal, kode hash, dan pesan komit terakhir:

`git brv`
