# msedge

> Perintah Microsoft Edge tersedia sebagai `msedge` untuk platform Windows dan `microsoft-edge` untuk platform lainnya.
> Informasi lebih lanjut: <https://microsoft.com/edge>.

- Lihat dokumentasi untuk perintah Microsoft Edge untuk Windows:

`tldr {{[-p|--platform]}} windows msedge`

- Lihat dokumentasi untuk perintah Microsoft Edge untuk perangkat lainnya:

`tldr {{[-p|--platform]}} common microsoft-edge`
