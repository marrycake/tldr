# brew outdated

> Tampilkan daftar cask dan formula yang dapat diperbarui.
> Untuk memutakhirkan seluruh cask dan formula, gunakan `brew upgrade`.
> Informasi lebih lanjut: <https://docs.brew.sh/Manpage#outdated-options-formulacask->.

- Tampilkan daftar seluruh cask dan formula yang dapat diperbarui:

`brew outdated`

- Hanya tampilkan daftar formula yang dapat diperbarui:

`brew outdated --formula`

- Hanya tampilkan daftar cask yang dapat diperbarui:

`brew outdated --cask`
