# vivaldi

> Perintah ini merupakan alias dari `chromium`.
> Informasi lebih lanjut: <https://vivaldi.com>.

- Tampilkan dokumentasi untuk perintah asli:

`tldr chromium`
