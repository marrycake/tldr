# fuck

> Koreksi perintah konsol sebelumnya.
> Informasi lebih lanjut: <https://github.com/nvbn/thefuck>.

- Pasang alias `fuck` ke alat `thefuck`:

`eval "$(thefuck --alias)"`

- Coba cocokkan aturan untuk perintah sebelumnya:

`fuck`

- Pilih pilihan pertama secara langsung (argumen yang benar tergantung dari tingkat kejengkelan):

`fuck --{{yes|yeah|hard}}`
