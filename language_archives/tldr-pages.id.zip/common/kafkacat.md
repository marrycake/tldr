# kafkacat

> Perintah ini merupakan alias dari `kcat`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr kcat`
