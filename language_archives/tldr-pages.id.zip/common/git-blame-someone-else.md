# git blame-someone-else

> Salahkan orang lain karena kode buruk Anda.
> Informasi lebih lanjut: <https://github.com/jayphelps/git-blame-someone-else>.

- Ubah nama penulis dan pelaku komit:

`git blame-someone-else "{{pelaku <someone@example.com>}}" {{komit}}`
