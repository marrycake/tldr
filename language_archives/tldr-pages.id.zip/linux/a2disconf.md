# a2disconf

> Matikan suatu konfigurasi piranti peladen Apache yang diatur oleh suatu berkas dalam sistem operasi berbasis Debian.
> Informasi lebih lanjut: <https://manned.org/a2disconf.8>.

- Matikan konfigurasi yang diatur dalam suatu berkas:

`sudo a2disconf {{berkas_konfigurasi}}`

- Jangan menampilkan pesan-pesan informatif selama melakukan operasi:

`sudo a2disconf --quiet {{berkas_konfigurasi}}`
