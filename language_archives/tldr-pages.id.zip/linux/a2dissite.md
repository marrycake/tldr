# a2dissite

> Matikan fungsi peladenan suatu host maya (virtual host) pada piranti peladen Apache dalam sistem operasi berbasis Debian.
> Informasi lebih lanjut: <https://manned.org/a2dissite.8>.

- Matikan suatu host maya:

`sudo a2dissite {{host_maya}}`

- Jangan menampilkan pesan-pesan informatif selama melakukan operasi:

`sudo a2dissite --quiet {{host_maya}}`
