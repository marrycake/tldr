# ubuntu-bug

> Perintah ini merupakan alias dari `apport-bug`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr apport-bug`
