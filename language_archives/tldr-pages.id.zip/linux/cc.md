# cc

> Perintah ini merupakan alias dari `gcc`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr gcc`
