# a2dismod

> Matikan suatu modul piranti peladen Apache dalam sistem operasi berbasis Debian.
> Informasi lebih lanjut: <https://manned.org/a2dismod.8>.

- Matikan suatu modul:

`sudo a2dismod {{modul}}`

- Jangan menampilkan pesan-pesan informatif selama melakukan operasi:

`sudo a2dismod --quiet {{modul}}`
