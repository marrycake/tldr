# megadl

> Perintah ini merupakan alias dari `megatools-dl`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr megatools-dl`
