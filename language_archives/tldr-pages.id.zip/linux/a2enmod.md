# a2enmod

> Nyalakan suatu modul piranti peladen Apache dalam sistem operasi berbasis Debian.
> Informasi lebih lanjut: <https://manned.org/a2enmod.8>.

- Nyalakan suatu modul:

`sudo a2enmod {{modul}}`

- Jangan menampilkan pesan-pesan informatif selama melakukan operasi:

`sudo a2enmod --quiet {{modul}}`
