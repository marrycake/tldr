# free

> Menampilkan jumlah memori kosong/tersedia dan memori yang digunakan dalam sistem.
> Informasi lebih lanjut: <https://manned.org/free>.

- Tampilkan memori sistem:

`free`

- Tampilkan memori dalam Bytes/KB/MB/GB:

`free -{{b|k|m|g}}`

- Tampilkan memori dalam unit yang dapat dibaca manusia:

`free {{[-h|--human]}}`

- Tampilkan output setiap 2 detik:

`free {{[-s|--seconds]}} {{2}}`
