# batcat

> Perintah ini merupakan alias dari `bat`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr bat`
