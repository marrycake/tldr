# a2ensite

> Nyalakan fungsi peladenan suatu host maya (virtual host) pada piranti peladen Apache dalam sistem operasi berbasis Debian.
> Informasi lebih lanjut: <https://manned.org/a2ensite.8>.

- Nyalakan suatu host maya:

`sudo a2ensite {{host_maya}}`

- Jangan menampilkan pesan-pesan informatif selama melakukan operasi:

`sudo a2ensite --quiet {{host_maya}}`
