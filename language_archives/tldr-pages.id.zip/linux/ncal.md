# ncal

> Perintah ini merupakan alias dari `cal`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr cal`
