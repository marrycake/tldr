# alternatives

> Perintah ini merupakan alias dari `update-alternatives`.

- Tampilkan dokumentasi untuk perintah asli:

`tldr update-alternatives`
