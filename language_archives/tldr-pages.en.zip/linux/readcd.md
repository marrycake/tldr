# readcd

> Read or write Compact Disc media data.
> More information: <https://manned.org/readcd>.

- Read a cd and copy it to a file:

`readcd dev={{/dev/srX}} f={{path/to/file.iso}}`
