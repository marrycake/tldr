# gprintf

> This command is an alias of GNU `printf`.

- View documentation for the original command:

`tldr -p linux printf`
