# uuidgen

> Generate new UUID (Universally Unique IDentifier) strings.
> More information: <https://keith.github.io/xcode-man-pages/uuidgen.1.html>.

- Generate a UUID string:

`uuidgen`
