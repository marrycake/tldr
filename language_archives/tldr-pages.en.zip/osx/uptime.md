# uptime

> Tell how long the system has been running and other information.
> More information: <https://keith.github.io/xcode-man-pages/uptime.1.html>.

- Print current time, uptime, number of logged-in users and other information:

`uptime`
