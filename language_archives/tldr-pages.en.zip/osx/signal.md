# signal

> Simplified software signal facilities.
> More information: <https://developer.apple.com/library/archive/documentation/System/Conceptual/ManPages_iPhoneOS/man3/signal.3.html>.

- View documentation for signals in macOS:

`man signal`
