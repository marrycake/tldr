# mkdir

> Kreira direktorijum.
> Više informacija na: <https://www.gnu.org/software/coreutils/manual/html_node/mkdir-invocation.html>.

- Kreira direktorijum u trenutnom direktorijumu ili zadatoj lokaciji:

`mkdir {{direktorijum}}`

- Kreira direktorijum koristeći rekurziju:

`mkdir {{[-p|--parents]}} {{putanja/do/direktorijuma1 putanja/do/direktorijuma2 ...}}`
