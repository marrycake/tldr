# cuninst

> Ця команда є псевдонімом для `choco uninstall`.

- Дивись документацію для оригінальної команди:

`tldr choco uninstall`
