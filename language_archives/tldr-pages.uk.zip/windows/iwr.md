# iwr

> Ця команда є псевдонімом для `invoke-webrequest`.

- Дивись документацію для оригінальної команди:

`tldr invoke-webrequest`
