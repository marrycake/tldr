# cmd

> Менеджер сервісів Android.
> Більше інформації: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/cmd/>.

- Вивести всі запущені девайси:

`cmd -l`

- Викликати конкретний сервіс:

`cmd {{сервіс}}`

- Викликати сервіс з заданими аргументами:

`cmd {{сервіс}} {{аргумент1 аргумент2 ...}}`
