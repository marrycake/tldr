# tlmgr arch

> Ця команда є псевдонімом для `tlmgr platform`.

- Дивись документацію для оригінальної команди:

`tldr tlmgr platform`
