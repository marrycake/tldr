# fossil ci

> Ця команда є псевдонімом для `fossil commit`.

- Дивись документацію для оригінальної команди:

`tldr fossil commit`
