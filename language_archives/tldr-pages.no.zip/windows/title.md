# title

> Setter tittelen på Ledetekst vindu.
> Mer informasjon: <https://learn.microsoft.com/windows-server/administration/windows-commands/title>.

- Setter tittelen på Ledetekst vindu:

`title {{ny_tittel}}`
