# pwsh where

> Denne kommandoen er et alias for `Where-Object`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr Where-Object`
