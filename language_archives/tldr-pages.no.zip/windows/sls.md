# sls

> Denne kommandoen er et alias for `Select-String`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr select-string`
