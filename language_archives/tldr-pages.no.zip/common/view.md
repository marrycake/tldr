# view

> En skrivebeskytter vesjon av `vim`.
> Dette tilsvarer `vim -R`.
> Mer informasjon: <https://www.vim.org>.

- Åpne en fil:

`view {{fil}}`
