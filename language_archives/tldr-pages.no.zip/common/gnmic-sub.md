# gnmic sub

> Denne kommandoen er et alias for `gnmic subscribe`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr gnmic subscribe`
