# logname

> Viser brukerens login navn.
> Mer informasjon: <https://www.gnu.org/software/coreutils/manual/html_node/logname-invocation.html>.

- Vis brukerens nåværende innloggings navn:

`logname`
