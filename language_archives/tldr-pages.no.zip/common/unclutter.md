# unclutter

> Gjemmer musepekeren.
> Mer informasjon: <https://manned.org/unclutter.1x>.

- Gjem musepekeren etter 3 sekunder:

`unclutter -idle {{3}}`
