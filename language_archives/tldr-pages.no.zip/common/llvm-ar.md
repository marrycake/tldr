# llvm-ar

> Denne kommandoen er et alias for `ar`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr ar`
