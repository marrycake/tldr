# platformio

> Denne kommandoen er et alias for `pio`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr pio`
