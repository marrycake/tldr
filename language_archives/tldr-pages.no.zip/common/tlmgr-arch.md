# tlmgr arch

> Denne kommandoen er et alias for `tlmgr platform`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr tlmgr platform`
