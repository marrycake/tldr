# zless

> Vis komprimerte filer.
> Mer informasjon: <https://manned.org/zless>.

- Bla gjennom et komprimert arkiv med `less`:

`zless {{fil.txt.gz}}`
