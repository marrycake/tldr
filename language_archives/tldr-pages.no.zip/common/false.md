# false

> Returner en utgangskode på 1.
> Mer informasjon: <https://www.gnu.org/software/coreutils/manual/html_node/false-invocation.html>.

- Returner en utgangskode på 1:

`false`
