# piodebuggdb

> Denne kommandoen er et alias for `pio debug`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr pio debug`
