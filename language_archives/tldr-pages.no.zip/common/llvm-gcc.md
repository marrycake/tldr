# llvm-gcc

> Denne kommandoen er et alias for `clang`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr clang`
